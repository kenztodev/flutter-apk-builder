// ignore_for_file: use_build_context_synchronously
import 'dart:convert';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'package:flutter/material.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'package:flutter/services.dart'; // Ditambahkan untuk fitur Copy Clipboard & Full Screen System UI

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'package:shared_preferences/shared_preferences.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'package:device_info_plus/device_info_plus.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'package:web_socket_channel/web_socket_channel.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'package:web_socket_channel/status.dart' as status;

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'package:url_launcher/url_launcher.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'package:video_player/video_player.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'package:http/http.dart' as http;

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'dart:ui';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);

import 'telegram.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'admin_page.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'home_page.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'seller_page.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'change_password_page.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'ddos_page.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'chat_page.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'login_page.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'custom_bug.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'bug_group.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'ddos_panel.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'sender_page.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
// Import halaman baru
import 'spams_page.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'public_page.dart';

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);
import 'device_dashboard.dart'; // --- MODIFIKASI: Mengarah langsung ke Dashboard Device

// MANTA'X COLORS
const Color _primaryGreen = Color(0xFF00FF88);
const Color _secondaryCyan = Color(0xFF00FFFF);
const Color _accentMagenta = Color(0xFFFF00FF);
const Color _darkBg = Color(0xFF050505);

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final List<Map<String, dynamic>> listDDoS;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
    required this.listDDoS,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  // --- NEW: Controller untuk Video Background ---
  VideoPlayerController? _videoController;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listPayload;
  late List<Map<String, dynamic>> listDDoS;
  late List<dynamic> newsList;
  String androidId = "unknown";

  int _selectedIndex = 0;
  Widget _selectedPage = const Placeholder();

  // Global key untuk mendapatkan posisi tombol Bug
  final GlobalKey _bugButtonKey = GlobalKey();
  // Global key untuk Scaffold agar bisa membuka drawer tanpa AppBar standar
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  // Controller for news page view
  final PageController _pageController = PageController(viewportFraction: 0.92);
  int _currentNewsIndex = 0;

  // Activity log state
  List<Map<String, dynamic>> _activityLogs = [];
  bool _isLoadingActivityLogs = false;
  bool _hasActivityLogsError = false;

  // --- Posisi & State Assistive Touch ---
  Offset _assistiveTouchPosition = const Offset(20, 150);
  bool _isAssistiveMenuOpen = false;
  
  // --- State untuk expandable Bug Tools Menu dan Active Page ---
  bool _isBugToolsExpanded = false;
  String _activePage = 'home'; // Default page aktif

  // --- State untuk Floating Navigation Menu ---
  bool _isNavMenuOpen = false;
  OverlayEntry? _overlayEntry;

  @override
  void initState() {
    super.initState();
    
    // --- FITUR BARU: Membuat Aplikasi Full Screen Menutupi Status Bar ---
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listPayload = widget.listPayload;
    listDDoS = widget.listDDoS;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _selectedPage = _buildNewsPage();

    _initAndroidIdAndConnect();

    // Fetch activity logs when the page is first loaded
    _fetchActivityLogs();

    // --- NEW: Inisialisasi Video Background ---
    _initVideoBackground();
  }

  Future<void> _initVideoBackground() async {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
        ..initialize().then((_) {
          _videoController?.setLooping(true);
          _videoController?.setVolume(0.0);
          _videoController?.play();
          if (mounted) setState(() {});
        }).catchError((e) {
          debugPrint("Gagal memuat video background: $e");
        });
    } catch (e) {
       debugPrint("Exception saat memuat video: $e");
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    // SetState dipanggil agar UI (seperti Account Stats Card) langsung menampilkan Device ID
    if(mounted) {
      setState(() {
        androidId = deviceInfo.id;
      });
    }
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('http://37.114.55.23:3507'));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));

    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);

      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }
    });
  }

  // Fetch activity logs from API
  Future<void> _fetchActivityLogs() async {
    if(!mounted) return;
    setState(() {
      _isLoadingActivityLogs = true;
      _hasActivityLogsError = false;
    });

    try {
      final response = await http.get(
        Uri.parse('http://37.114.55.23:3507/api/user/getActivityLogs?key=$sessionKey'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && data['logs'] != null) {
          if(mounted) {
             setState(() {
              _activityLogs = List<Map<String, dynamic>>.from(data['logs']);
              _isLoadingActivityLogs = false;
            });
          }
        } else {
          if(mounted) {
             setState(() {
              _isLoadingActivityLogs = false;
              _hasActivityLogsError = true;
            });
          }
        }
      } else {
         if(mounted) {
            setState(() {
              _isLoadingActivityLogs = false;
              _hasActivityLogsError = true;
            });
         }
      }
    } catch (e) {
      print('Error fetching activity logs: $e');
      if(mounted) {
        setState(() {
          _isLoadingActivityLogs = false;
          _hasActivityLogsError = true;
        });
      }
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: const Color(0xFFE0E0E0).withOpacity(0.3), width: 1), // Gray
        ),
        title: const Text("⚠️ Session Expired", style: TextStyle(color: Colors.white, fontFamily: "Orbitron")),
        content: Text(message, style: const TextStyle(color: Colors.white70, fontFamily: "ShareTechMono")),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
              );
            },
            child: const Text("OK", style: TextStyle(color: Color(0xFFE0E0E0))), // Gray
          ),
        ],
      ),
    );
  }

  void _selectFromDrawer(String page) {
    // --- FITUR BARU: Buka Account Menu dari Assistive Touch ---
    if (page == 'account') {
      setState(() {
        _isAssistiveMenuOpen = false; // Tutup menu melayang
        _isBugToolsExpanded = false;
      });
      _showAccountMenu(); // Panggil fungsi modal tanpa merubah halaman yang aktif
      return;
    }

    // === MODIFIKASI BARU: PERSISTENT SHELL UNTUK SEMUA HALAMAN ===
    if (page == 'rat') {
      // Daftar role yang diizinkan
      List<String> allowedRoles = ['dev', 'high admin', 'admin', 'high owner', 'owner'];
      
      if (allowedRoles.contains(role.toLowerCase())) {
        setState(() {
          _isAssistiveMenuOpen = false;
          _isBugToolsExpanded = false;
          _activePage = 'rat';
          _selectedPage = const DeviceDashboardPage(); // Ganti konten secara live
        });
        _controller.reset();
        _controller.forward();
        
        /* --- KODE LAMA DIBIKIN COMMENT ---
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => const DeviceDashboardPage(),
          ),
        );
        */
        return; 
      } else {
        // Jika bukan role yang diizinkan, tutup menu dan tidak lakukan apa-apa
        setState(() {
          _isAssistiveMenuOpen = false;
        });
        return;
      }
    }

    setState(() {
      _isAssistiveMenuOpen = false; // Tutup floating menu
      _activePage = page; // Set active page untuk styling navigasi bar
    });

    Widget nextWidget = _buildNewsPage(); // Default fallback
    
    // Switch halaman tujuan berdasarkan 'page' ke dalam '_selectedPage'
    if (page == 'home') {
      _selectedIndex = 0;
      nextWidget = _buildNewsPage();
    } else if (page == 'bug') {
      nextWidget = AttackPage(
        username: username,
        password: password,
        listBug: listBug,
        role: role,
        expiredDate: expiredDate,
        sessionKey: sessionKey,
      );
    } else if (page == 'custom_bug') {
      nextWidget = CustomAttackPage(
        username: username,
        password: password,
        listPayload: listPayload,
        role: role,
        expiredDate: expiredDate,
        sessionKey: sessionKey,
      );
    } else if (page == 'group_bug') {
      nextWidget = GroupBugPage(
        username: username,
        password: password,
        role: role,
        expiredDate: expiredDate,
        sessionKey: sessionKey,
      );
    } else if (page == 'telegram') {
      nextWidget = TelegramSpamPage(sessionKey: sessionKey);
    } else if (page == 'ddos') {
      nextWidget = AttackPanel(sessionKey: sessionKey, listDDoS: listDDoS);
    } else if (page == 'tools') {
      nextWidget = ToolsPage(sessionKey: sessionKey, userRole: role);
    } else if (page == 'reseller') {
      nextWidget = SellerPage(keyToken: sessionKey);
    } else if (page == 'admin') {
      nextWidget = AdminPage(sessionKey: sessionKey);
    } else if (page == 'sender') {
      nextWidget = SenderPage(sessionKey: sessionKey);
    }

    // Eksekusi pergantian konten dengan animasi FadeTransition
    setState(() {
      _selectedPage = nextWidget;
      _controller.reset();
      _controller.forward();
    });

    /* --- KODE NAVIGASI LAMA DIBIKIN COMMENT AGAR TIDAK DIHAPUS ---
    if (page == 'home') {
      setState(() {
        _selectedIndex = 0;
        _selectedPage = _buildNewsPage();
        _controller.reset();
        _controller.forward();
      });
    } else if (page == 'bug') {
      Navigator.push(context, MaterialPageRoute(builder: (context) => AttackPage( ... )));
    } ...
    */
  }

  // --- Fungsi untuk menampilkan menu navigasi floating seperti di foto ---
  void _toggleNavMenu() {
    if (_isNavMenuOpen) {
      _removeNavMenu();
    } else {
      _showNavMenu();
    }
  }

  void _showNavMenu() {
    _overlayEntry = _createOverlayEntry();
    Overlay.of(context).insert(_overlayEntry!);
    setState(() {
      _isNavMenuOpen = true;
    });
  }

  void _removeNavMenu() {
    _overlayEntry?.remove();
    _overlayEntry = null;
    setState(() {
      _isNavMenuOpen = false;
    });
  }

  OverlayEntry _createOverlayEntry() {
    return OverlayEntry(
      builder: (context) => Positioned(
        bottom: 100,
        right: 20,
        child: Material(
          color: Colors.transparent,
          child: Container(
            width: 200,
            decoration: BoxDecoration(
              color: const Color(0xFF0A0D0B).withOpacity(0.95),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: const Color(0xFF25D366).withOpacity(0.3),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.5),
                  blurRadius: 10,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header Menu - Sama persis seperti di foto
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        color: Colors.white.withOpacity(0.1),
                        width: 1,
                      ),
                    ),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.menu, color: Color(0xFF25D366), size: 18),
                      SizedBox(width: 8),
                      Text(
                        "NAVIGATION",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: "Orbitron",
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
                
                // Menu Items - Sama persis urutannya seperti di foto
                _buildNavMenuItem(
                  icon: Icons.home,
                  label: "Home",
                  page: 'home',
                ),
                
                // Bug Menu dengan Submenu - Seperti di foto
                _buildBugNavMenu(),
                
                _buildNavMenuItem(
                  icon: FontAwesomeIcons.telegram,
                  label: "Spam",
                  page: 'telegram',
                ),
                
                _buildNavMenuItem(
                  icon: Icons.phone_android,
                  label: "RAT",
                  page: 'rat',
                ),
                
                _buildNavMenuItem(
                  icon: Icons.more_horiz,
                  label: "More",
                  page: 'more',
                  onTap: () {
                    _removeNavMenu();
                    // More tidak melakukan apa-apa
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavMenuItem({
    required IconData icon,
    required String label,
    required String page,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap ?? () {
        _removeNavMenu();
        _selectFromDrawer(page);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: Colors.white.withOpacity(0.05),
              width: 1,
            ),
          ),
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.white70, size: 18),
            const SizedBox(width: 12),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontFamily: "ShareTechMono",
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBugNavMenu() {
    final String currentRole = role.toLowerCase();
    final bool canAccessAllBugs = ['dev', 'high admin', 'admin', 'high owner', 'owner'].contains(currentRole);
    final bool canAccessResellerBugs = ['reseller'].contains(currentRole);
    
    return StatefulBuilder(
      builder: (context, setState) {
        bool isBugExpanded = false;
        
        return Column(
          children: [
            InkWell(
              onTap: () {
                setState(() {
                  isBugExpanded = !isBugExpanded;
                });
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(
                      color: Colors.white.withOpacity(0.05),
                      width: 1,
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    const Icon(FontAwesomeIcons.whatsapp, color: Colors.white70, size: 18),
                    const SizedBox(width: 12),
                    const Text(
                      "Bug",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontFamily: "ShareTechMono",
                      ),
                    ),
                    const Spacer(),
                    Icon(
                      isBugExpanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                      color: Colors.white54,
                      size: 18,
                    ),
                  ],
                ),
              ),
            ),
            
            if (isBugExpanded)
              Container(
                color: Colors.black.withOpacity(0.3),
                child: Column(
                  children: [
                    // Normal Bug
                    _buildSubMenuItem(
                      icon: Icons.bolt,
                      label: "Normal Bug",
                      page: 'bug',
                    ),
                    
                    // Bug Group (untuk role tertentu)
                    if (canAccessAllBugs || canAccessResellerBugs)
                      _buildSubMenuItem(
                        icon: FontAwesomeIcons.usersSlash,
                        label: "Bug Group",
                        page: 'group_bug',
                      ),
                    
                    // Custom Bug (untuk role tertentu)
                    if (canAccessAllBugs)
                      _buildSubMenuItem(
                        icon: Icons.terminal,
                        label: "Custom Bug",
                        page: 'custom_bug',
                      ),
                  ],
                ),
              ),
          ],
        );
      },
    );
  }

  Widget _buildSubMenuItem({
    required IconData icon,
    required String label,
    required String page,
  }) {
    return InkWell(
      onTap: () {
        _removeNavMenu();
        _selectFromDrawer(page);
      },
      child: Container(
        padding: const EdgeInsets.only(left: 40, right: 16, top: 8, bottom: 8),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: Colors.white.withOpacity(0.05),
              width: 1,
            ),
          ),
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.white54, size: 16),
            const SizedBox(width: 12),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 13,
                fontFamily: "ShareTechMono",
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --- HEADER BARU SEPERTI DI FOTO (PPL V2.0) ---
  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      // SafeArea digunakan agar padding atas sesuai dengan status bar device
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 12, 
        bottom: 12, 
        left: 16, 
        right: 16
      ),
      decoration: BoxDecoration(
        color: Colors.transparent, // --- MODIFIKASI: Dibuat Transparan ---
        border: Border(
          bottom: BorderSide(
            color: const Color(0xFF25D366).withOpacity(0.3),
            width: 1,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Logo di kiri (assets/images/logo.png)
          GestureDetector(
            onTap: () {
              // Navigasi ke home jika logo diklik
              _selectFromDrawer('home');
            },
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: const Color(0xFF25D366).withOpacity(0.5),
                  width: 1.5,
                ),
              ),
              child: ClipOval(
                child: Image.asset(
                  'assets/images/logo.png',
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return Container(
                      color: Colors.grey[900],
                      child: const Icon(
                        Icons.bug_report,
                        color: Color(0xFF25D366),
                        size: 20,
                      ),
                    );
                  },
                ),
              ),
            ),
          ),

          // Text "PARAPAM" dan username
          Row(
            children: [
              const Text(
                "PARAPAM",
                style: TextStyle(
                  color: Color(0xFF25D366),
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: "Orbitron",
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF102016),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: const Color(0xFF25D366).withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: Text(
                  username, // Menggunakan username user
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontFamily: "ShareTechMono",
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),

          // Icon profile dan titik tiga
          Row(
            children: [
              // Icon Profile (membuka account menu)
              GestureDetector(
                onTap: _showAccountMenu,
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: const Color(0xFF25D366).withOpacity(0.5),
                      width: 1.5,
                    ),
                  ),
                  child: ClipOval(
                    child: Container(
                      color: Colors.grey[900],
                      child: const Icon(
                        Icons.person,
                        color: Color(0xFF25D366),
                        size: 20,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              
              // Titik tiga (tidak melakukan apa-apa)
              GestureDetector(
                onTap: () {
                  // Tidak melakukan apa-apa
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Menu coming soon', style: TextStyle(fontFamily: "ShareTechMono")),
                      backgroundColor: Color(0xFF25D366),
                      duration: Duration(seconds: 1),
                    ),
                  );
                },
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: const Color(0xFF25D366).withOpacity(0.5),
                      width: 1.5,
                    ),
                  ),
                  child: const Icon(
                    Icons.more_vert,
                    color: Color(0xFF25D366),
                    size: 20,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // --- WIDGETS TAMPILAN ---

  /* --- ORIGINAL ACCOUNT STATS CARD DIBIKIN COMMENT AGAR TIDAK DIHAPUS ---
  Widget _buildAccountStatsCardOriginal() {
    return Container(
      ... // Tampilan lama dengan background gelap dan device id
    );
  }
  */

  // --- NEW: ACCOUNT STATS CARD (Desain Baru Sesuai Referensi Foto Mizuki) ---
  Widget _buildAccountStatsCard() {
    const pinkColor = Color(0xFFFF1493); // Warna pink menyala

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20), // Margin sedikit lebih ke dalam
      height: 160, // Tidak terlalu panjang (tinggi disesuaikan)
      decoration: BoxDecoration(
        color: Colors.transparent, // Background transparan
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: pinkColor.withOpacity(0.8), // Border pink menyala
          width: 2.0,
        ),
        boxShadow: [
          // Efek glow di sekitar border
          BoxShadow(
            color: pinkColor.withOpacity(0.2),
            blurRadius: 15,
            spreadRadius: 2,
          )
        ],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Background blur halus untuk kesan glass (opsional, karena transparan)
          ClipRRect(
            borderRadius: BorderRadius.circular(22),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
              child: Container(
                color: Colors.black.withOpacity(0.4), // Sedikit gelap agar teks terbaca di atas video
              ),
            ),
          ),
          
          // --- KONTEN UTAMA ---
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween, // Pisah Kiri - Tengah - Kanan
              children: [
                // BAGIAN KIRI: Username & Role
                Expanded(
                  flex: 1,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Icon Orang + Username
                      Row(
                        children: [
                          const Icon(Icons.person, color: pinkColor, size: 18),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              username.toLowerCase(), // Disesuaikan dengan gaya foto (huruf kecil)
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                fontFamily: "Orbitron", // Font tebal modern
                                letterSpacing: 1.5,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      
                      // Role Badge (Kotak dengan border pink)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: pinkColor.withOpacity(0.1), // Transparan pink
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: pinkColor.withOpacity(0.5), width: 1),
                        ),
                        child: Text(
                          role.toUpperCase(),
                          style: const TextStyle(
                            color: pinkColor,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: "ShareTechMono",
                            letterSpacing: 1.0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // BAGIAN TENGAH: Avatar Bulat Menyala
                Container(
                  width: 90,
                  height: 90,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: pinkColor, // Border pink solid
                      width: 3.0,
                    ),
                    boxShadow: const [
                      // Efek glow pada foto profil
                      BoxShadow(
                        color: pinkColor,
                        blurRadius: 15,
                        spreadRadius: 1,
                      ),
                    ],
                    image: const DecorationImage(
                      image: NetworkImage("https://e.top4top.io/p_36970lnj11.jpg"), // Link foto sesuai permintaan
                      fit: BoxFit.cover,
                    ),
                  ),
                ),

                // BAGIAN KANAN: Expired Date
                Expanded(
                  flex: 1,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Judul "EXPIRED" dengan icon kalender
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Icon(Icons.calendar_today_outlined, color: Colors.white.withOpacity(0.8), size: 14),
                          const SizedBox(width: 6),
                          Text(
                            "EXPIRED",
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.8),
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              fontFamily: "Orbitron",
                              letterSpacing: 1.0,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      
                      // Tanggal Expired warna pink
                      Text(
                        expiredDate.split(' ').first, // Hanya mengambil tanggalnya saja
                        style: const TextStyle(
                          color: pinkColor,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: "ShareTechMono",
                          letterSpacing: 2.0,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // --- WIDGET HALAMAN UTAMA ---
  Widget _buildNewsPage() {
    return RefreshIndicator(
      color: const Color(0xFFE0E0E0), // Gray
      onRefresh: () async {
        await _fetchActivityLogs();
        await Future.delayed(const Duration(seconds: 1));
        setState(() {});
      },
      child: CustomScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
          // Padding di atas untuk menggantikan Header yang dipindah
          SliverToBoxAdapter(
            child: SizedBox(height: MediaQuery.of(context).padding.top + 70), // 70 adalah perkiraan tinggi header
          ),
          
          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 10),

                // 2. ACCOUNT STATS CARD (Tampilan baru sesuai foto referensi Mizuki)
                _buildAccountStatsCard(),

                const SizedBox(height: 25),

                // 3. News Carousel (DIUPDATE SESUAI REFERENSI FOTO PPL)
                _buildNewsCarousel(),

                const SizedBox(height: 10),

                // 5. Recent Activity
                _buildRecentActivity(),

                // Ditambahkan padding besar di bawah agar list tidak tertutup menu navigasi baru
                const SizedBox(height: 120),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _getRoleColor() {
    switch (role.toLowerCase()) {
      case 'owner':
        return Colors.red;
      case 'dev':
        return Colors.red;
      case 'high owner':
        return Colors.red;
      case 'vip':
        return _secondaryCyan;
      case 'reseller':
        return Colors.blue;
      default:
        return const Color(0xFFE0E0E0); // Gray
    }
  }

  // Fungsi Pembantu untuk Top Menu di dalam News Carousel (Tetap ada di original jika ingin dipakai)
  Widget _buildFeatureIcon({required IconData icon, required String title, required String subtitle}) {
    return Expanded(
      child: Column(
        children: [
          Icon(icon, color: const Color(0xFFE0E0E0), size: 26), // Abu-abu menyala
          const SizedBox(height: 10),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 13,
              fontWeight: FontWeight.bold,
              fontFamily: 'ShareTechMono',
              letterSpacing: 1.0,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: const TextStyle(
              color: Colors.white54,
              fontSize: 10,
              fontFamily: 'ShareTechMono',
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  /* --- ORIGINAL NEWS CAROUSEL DIBIKIN COMMENT AGAR TIDAK DIHAPUS (SESUAI PERMINTAAN) ---
  Widget _buildNewsCarouselOriginal() {
    if (newsList.isEmpty) { ... }
    return Container(
      ... // Tampilan lama dengan Icon Pedang, Tengkorak, dll
    );
  }
  */

  // --- NEW: NEWS CAROUSEL CARD TAMPILAN BARU SESUAI FOTO PPL ---
  Widget _buildNewsCarousel() {
    if (newsList.isEmpty) {
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        height: 180,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.black.withOpacity(0.3),
          border: Border.all(color: const Color(0xFFE0E0E0).withOpacity(0.2)),
        ),
        child: const Center(child: Text("No news available", style: TextStyle(color: Colors.white54))),
      );
    }

    return Column(
      children: [
        // IMAGE CAROUSEL DENGAN TAMPILAN CARD BARU
        SizedBox(
          height: 280, // Tinggi diperbesar untuk memuat teks di bawah gambar dalam satu card
          child: PageView.builder(
            controller: _pageController,
            itemCount: newsList.length,
            onPageChanged: (index) {
              setState(() {
                _currentNewsIndex = index;
              });
            },
            itemBuilder: (context, index) {
              final item = newsList[index];
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFF101412), // Background gelap solid seperti di foto
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.08), width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.5),
                      blurRadius: 10,
                      spreadRadius: 2,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // --- BAGIAN ATAS: GAMBAR MEDIA ---
                    Expanded(
                      flex: 6, // 60% proporsi untuk gambar
                      child: ClipRRect(
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(14.5)),
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            if (item['image'] != null && item['image'].toString().isNotEmpty)
                              NewsMedia(url: item['image'])
                            else
                              Container(color: Colors.black26),
                              
                            // Efek gradient gelap halus di bawah gambar (opsional agar ngeblend)
                            Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Colors.black.withOpacity(0.4),
                                    Colors.transparent,
                                  ],
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.center,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    
                    // --- BAGIAN BAWAH: ICON + JUDUL + DESKRIPSI ---
                    Expanded(
                      flex: 4, // 40% proporsi untuk teks info
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            // ROW ICON KORAN & TITILE ("PPL Team")
                            Row(
                              children: [
                                const Icon(
                                  Icons.newspaper_outlined, // Icon koran sesuai foto
                                  color: Color(0xFF25D366), // Warna hijau terang
                                  size: 22,
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    item['title'] ?? "PPL Team", // Title (fallback sesuai foto)
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: "Orbitron", // Font kotak modern
                                      letterSpacing: 1.0,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                            
                            const SizedBox(height: 10),
                            
                            // TEKS DESKRIPSI ("Admin Bukan Pedofil Yak.")
                            Text(
                              item['desc'] ?? "Admin Bukan Pedofil Yak.", // Desc (fallback sesuai foto)
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.7), // Sedikit pudar
                                fontSize: 13,
                                fontFamily: "ShareTechMono", // Font ala monospace (sesuai foto)
                                letterSpacing: 0.5,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
        
        // DOTS INDICATOR
        if (newsList.length > 1)
          Padding(
            padding: const EdgeInsets.only(top: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                newsList.length,
                (index) => AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  height: 6,
                  width: _currentNewsIndex == index ? 24 : 8, // Sedikit lebih memanjang jika aktif
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: _currentNewsIndex == index
                        ? const Color(0xFF25D366) // Warna aktif Hijau menyesuaikan tema baru
                        : Colors.white.withOpacity(0.2),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  // --- RECENT ACTIVITY ---
  Widget _buildRecentActivity() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // --- KODE BARU RECENT ACTIVITY (Menyerupai Foto) ---
          const Text(
            "RECENT ACTIVITY",
            style: TextStyle(
              color: Color(0xFF25D366), // Warna hijau neon ala WA
              fontSize: 14,
              fontWeight: FontWeight.w600,
              fontFamily: "Orbitron",
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 15),

          if (_isLoadingActivityLogs)
            Container(
              height: 120,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Colors.black.withOpacity(0.3),
                border: Border.all(
                  color: const Color(0xFFE0E0E0).withOpacity(0.2), // Gray
                  width: 1,
                ),
              ),
              child: const Center(
                child: CircularProgressIndicator(color: Color(0xFFE0E0E0)), // Gray
              ),
            )
          else if (_hasActivityLogsError)
            Container(
              height: 120,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Colors.black.withOpacity(0.3),
                border: Border.all(
                  color: Colors.red.withOpacity(0.2),
                  width: 1,
                ),
              ),
              child: const Center(
                child: Text(
                  "Failed to load activity logs",
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                  ),
                ),
              ),
            )
          else if (_activityLogs.isEmpty)
            Container(
              height: 120,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Colors.black.withOpacity(0.3),
                border: Border.all(
                  color: const Color(0xFFE0E0E0).withOpacity(0.2), // Gray
                  width: 1,
                ),
              ),
              child: const Center(
                child: Text(
                  "No activity logs available",
                  style: TextStyle(
                    color: Colors.white54,
                    fontSize: 14,
                  ),
                ),
              ),
            )
          else
            ..._activityLogs.take(5).map((log) { // Mengambil 5 baris agar persis gambar
              final timestamp = DateTime.tryParse(log['timestamp'] ?? '') ?? DateTime.now();
              final formattedTime = _formatDateTime(timestamp);

              String activityText = log['activity'] ?? 'Unknown Activity';
              if (log['details'] != null && log['details']['target'] != null) {
                 // Opsional jika Anda punya detail tambahan di DB 
              }

              return Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF121413), // Warna background sangat gelap (pekat)
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.05), // Garis luar sangat transparan
                      width: 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        blurRadius: 5,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.history, // Ikon history sesuai gambar
                        color: Colors.white54,
                        size: 16,
                      ),
                      const SizedBox(width: 15),
                      Expanded(
                        child: Text(
                          activityText,
                          style: const TextStyle(
                            color: Colors.white70,
                            fontFamily: "ShareTechMono",
                            fontSize: 13,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        formattedTime,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.3),
                          fontFamily: "ShareTechMono",
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
        ],
      ),
    );
  }

  Widget _buildActivityDetails(Map<String, dynamic> details) {
    return Container(
      margin: const EdgeInsets.only(top: 8, left: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: details.entries.map((entry) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("${entry.key}:", style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 12)),
                const SizedBox(width: 5),
                Expanded(child: Text(entry.value.toString(), style: const TextStyle(color: Colors.white70, fontSize: 12))),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  Color _getActivityColor(String? activity) {
    if (activity == null) return Colors.grey;
    if (activity.contains('Bug') || activity.contains('Attack') || activity.contains('Delete') || activity.contains('Failed')) {
      return Colors.red;
    } else if (activity.contains('Call')) {
      return Colors.orange;
    } else if (activity.contains('Create') || activity.contains('Add')) {
      return Colors.green;
    } else if (activity.contains('Edit') || activity.contains('Change')) {
      return Colors.blue;
    } else if (activity.contains('Cooldown')) {
      return _secondaryCyan;
    }
    return const Color(0xFFE0E0E0); // Gray
  }

  IconData _getActivityIcon(String? activity) {
    if (activity == null) return Icons.info;
    if (activity.contains('Bug') || activity.contains('Attack')) return Icons.bug_report;
    if (activity.contains('Call')) return Icons.phone;
    if (activity.contains('Create') || activity.contains('Add')) return Icons.person_add;
    if (activity.contains('Delete')) return Icons.delete;
    if (activity.contains('Edit') || activity.contains('Change')) return Icons.edit;
    if (activity.contains('Cooldown')) return Icons.timer;
    if (activity.contains('DDOS')) return Icons.flash_on;
    return Icons.info;
  }

  String _formatDateTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);
    if (difference.inDays > 0) return '${difference.inDays} day${difference.inDays > 1 ? 's' : ''} ago';
    if (difference.inHours > 0) return '${difference.inHours} hour${difference.inHours > 1 ? 's' : ''} ago';
    if (difference.inMinutes > 0) return '${difference.inMinutes} minute${difference.inMinutes > 1 ? 's' : ''} ago';
    return 'Just now';
  }

  // Glassmorphism card widget (Used by Account Menu, etc)
  Widget _glassCard({required Widget child}) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.black.withOpacity(0.2), // Lebih transparan sesuai request
        border: Border.all(
          color: const Color(0xFFE0E0E0).withOpacity(0.2), // Gray
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFE0E0E0).withOpacity(0.05), // Gray
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5), // Blur lebih halus
          child: child,
        ),
      ),
    );
  }

  // Glassmorphism button widget
  Widget _glassButton({required Icon icon, required Text label, required VoidCallback onPressed}) {
    return ElevatedButton.icon(
      icon: icon,
      label: label,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent,
        foregroundColor: const Color(0xFFE0E0E0), // Gray
        shadowColor: Colors.transparent,
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: const Color(0xFFE0E0E0).withOpacity(0.3), width: 1), // Gray
        ),
      ),
      onPressed: onPressed,
    );
  }

  // --- NEW: FUNGSI UNTUK MENAMPILKAN SHEET PILIHAN BUG KETIKA CLICK "BUG" DI NAVIGASI ---
  void _showBugOptionsSheet() {
    final String currentRole = role.toLowerCase();
    final List<String> allowedGroupRoles = ['dev', 'high admin', 'admin', 'high owner', 'owner', 'reseller', 'vip'];
    final bool canAccessGroup = allowedGroupRoles.contains(currentRole);

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: _glassCard(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text("Select Bug Type", style: TextStyle(color: Colors.white, fontSize: 20, fontFamily: "Orbitron")),
                const SizedBox(height: 20),
                
                // Bug Contact (AttackPage) - Untuk Semua Member / Semua Role
                _glassButton(
                  icon: const Icon(Icons.person_outline),
                  label: const Text("Bug Contact"),
                  onPressed: () {
                    Navigator.pop(context); // Tutup bottom sheet
                    _selectFromDrawer('bug'); // Akan membuka AttackPage (home_page.dart)
                  },
                ),
                
                // Bug Group (GroupBugPage) - Hanya Untuk Role Tertentu
                if (canAccessGroup) ...[
                  const SizedBox(height: 10),
                  _glassButton(
                    icon: const Icon(FontAwesomeIcons.usersSlash),
                    label: const Text("Bug Group"),
                    onPressed: () {
                      Navigator.pop(context); // Tutup bottom sheet
                      _selectFromDrawer('group_bug'); // Akan membuka GroupBugPage (bug_group.dart)
                    },
                  ),
                ],
                const SizedBox(height: 10),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showAccountMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: _glassCard(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text("Account Info", style: TextStyle(color: Colors.white, fontSize: 20, fontFamily: "Orbitron")),
                const SizedBox(height: 12),
                _infoCard(Icons.person, "Username", username),
                _infoCard(Icons.date_range, "Expired", expiredDate),
                _infoCard(Icons.security, "Role", role),
                const SizedBox(height: 20),
                _glassButton(
                  icon: const Icon(Icons.lock_reset),
                  label: const Text("Change Password"),
                  onPressed: () {
                    Navigator.pop(context);
                    // Modifikasi agar tetap berada dalam persistent shell
                    setState(() {
                      _activePage = 'change_password';
                      _selectedPage = ChangePasswordPage(
                        username: username,
                        sessionKey: sessionKey,
                      );
                      _controller.reset();
                      _controller.forward();
                    });
                    
                    /* --- KODE LAMA DIBIKIN COMMENT ---
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ChangePasswordPage(
                          username: username,
                          sessionKey: sessionKey,
                        ),
                      ),
                    );
                    */
                  },
                ),
                const SizedBox(height: 10),
                _glassButton(
                  icon: const Icon(Icons.logout),
                  label: const Text("Logout"),
                  onPressed: () async {
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.clear();
                    if (!mounted) return;
                    Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (_) => const LoginPage()),
                          (route) => false,
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _infoCard(IconData icon, String label, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.2),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE0E0E0).withOpacity(0.2), width: 1), // Gray
      ),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFFE0E0E0)), // Gray
          const SizedBox(width: 10),
          Text("$label:", style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
          const Spacer(),
          Text(value, style: const TextStyle(color: Colors.white, fontFamily: "ShareTechMono")),
        ],
      ),
    );
  }

  Widget _buildLogo({double height = 40}) {
    return Image.asset(
      'assets/images/title.png',
      height: height,
      fit: BoxFit.contain,
    );
  }

  // --- NEW: COMPACT ASSISTIVE MENU WIDGET (Sesuai Foto) ---
  Widget _buildAssistiveMenu() {
    final String currentRole = role.toLowerCase();
    
    // RBAC Permissions Logic
    final bool canAccessAdmin = ['dev', 'high admin', 'admin', 'high owner', 'owner'].contains(currentRole);
    final bool canAccessSeller = ['dev', 'high admin', 'admin', 'high owner', 'owner', 'reseller'].contains(currentRole);
    final bool canAccessAllBugs = ['dev', 'high admin', 'admin', 'high owner', 'owner'].contains(currentRole);
    final bool canAccessResellerBugs = ['reseller'].contains(currentRole);
    final bool isMember = !canAccessAllBugs && !canAccessResellerBugs;
    
    // Daftar role yang bisa akses RAT
    final bool canAccessRat = ['dev', 'high admin', 'admin', 'high owner', 'owner'].contains(currentRole);

    return Container(
      width: 240, // Lebar disesuaikan agar proporsional
      decoration: BoxDecoration(
        color: const Color(0xFF0A0D0B), // Sangat gelap (pekat) seperti di foto
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF25D366).withOpacity(0.2), width: 1), // Border sedikit hijau
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 15,
            spreadRadius: 2,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 8), // Sedikit jarak di atas

                // Item menu dinamis (Bisa menyala/aktif jika dipilih)
                _assistiveMenuItem(Icons.home, "Home", 'home'),
                
                // --- NEW: Expandable Bug Tools Menu (Accordion style) ---
                Theme(
                  // Menghilangkan divider line bawaan ExpansionTile
                  data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
                  child: ExpansionTile(
                    tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
                    childrenPadding: EdgeInsets.zero,
                    // Icon kiri
                    leading: const Icon(FontAwesomeIcons.whatsapp, color: Colors.white70, size: 18),
                    title: const Text("Bug Tools", style: TextStyle(color: Colors.white70, fontSize: 14, fontFamily: "ShareTechMono", letterSpacing: 1.0)),
                    // Icon kanan
                    trailing: Icon(
                      _isBugToolsExpanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down, 
                      color: Colors.white54, 
                      size: 18
                    ),
                    onExpansionChanged: (bool expanded) {
                      setState(() {
                        _isBugToolsExpanded = expanded;
                      });
                      // Jika Member biasa, jangan expand dan langsung arahkan ke Basic Bug
                      if (isMember && expanded) {
                         setState(() {
                            _isBugToolsExpanded = false;
                         });
                         _selectFromDrawer('bug');
                      }
                    },
                    children: [
                      // Hanya render tree submenu jika user bukan member biasa (punya akses custom / group)
                      if (!isMember)
                        Padding(
                          padding: const EdgeInsets.only(left: 20, top: 4, bottom: 8, right: 16),
                          child: Stack(
                            children: [
                              // Garis Vertikal penghubung (Tree line)
                              Positioned(
                                left: 7, 
                                top: 12,
                                bottom: 12,
                                child: Container(
                                  width: 1.5,
                                  color: Colors.white24,
                                ),
                              ),
                              // Daftar Sub-Item (Group, Custom, Basic)
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // Muncul untuk Owner & Reseller
                                  if (canAccessAllBugs || canAccessResellerBugs) ...[
                                    _buildTreeItem(
                                      icon: FontAwesomeIcons.usersSlash, 
                                      title: "Group Bug",
                                      page: 'group_bug',
                                    ),
                                    const SizedBox(height: 8),
                                  ],
                                  // Muncul hanya untuk Owner/Admin tier
                                  if (canAccessAllBugs) ...[
                                    _buildTreeItem(
                                      icon: Icons.terminal, 
                                      title: "Custom Bug",
                                      page: 'custom_bug',
                                    ),
                                    const SizedBox(height: 8),
                                  ],
                                  // Muncul untuk semua (di dalam menu expand bagi owner/reseller)
                                  _buildTreeItem(
                                    icon: Icons.bolt, 
                                    title: "Basic Bug",
                                    page: 'bug',
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
                
                // Sisa Menu menggunakan data statis dari screenshot
                _assistiveMenuItem(FontAwesomeIcons.paperPlane, "Spam", 'telegram'),
                if (canAccessRat) // Hanya tampil untuk role yang berhak
                  _assistiveMenuItem(Icons.phone_android, "RAT", 'rat'),
                _assistiveMenuItem(FontAwesomeIcons.screwdriverWrench, "Tools", 'tools'),
                _assistiveMenuItem(Icons.security, "DDoS Attack", 'ddos'),
                const Divider(color: Colors.white12, height: 16, thickness: 1, indent: 16, endIndent: 16),
                
                // --- NEW: Account info button agar tidak kehilangan fungsi header ---
                _assistiveMenuItem(Icons.person, "Account Info", 'account'),

                // Menu khusus Seller / Reseller panel
                if (canAccessSeller)
                  _assistiveMenuItem(Icons.store, "Seller Panel", 'reseller'),

                // Menu khusus Admin panel
                if (canAccessAdmin)
                  _assistiveMenuItem(Icons.admin_panel_settings, "Admin Panel", 'admin'),

                _assistiveMenuItem(FontAwesomeIcons.whatsapp, "Manage Sender", 'sender'),
                const SizedBox(height: 10),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // --- NEW: Item Menu Utama dengan Style Aktif Hijau ---
  Widget _assistiveMenuItem(IconData icon, String title, String page) {
    bool isActive = _activePage == page; // Cek apakah menu ini sedang dibuka

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2), // Padding luar agar border radius pas
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          splashColor: const Color(0xFF25D366).withOpacity(0.2), // Splash efek hijau ala WA saat di-klik
          highlightColor: const Color(0xFF25D366).withOpacity(0.1),
          onTap: () => _selectFromDrawer(page),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: isActive ? BoxDecoration(
              color: const Color(0xFF102016), // Background hijau gelap saat aktif
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF20402E), width: 1), // Border hijau
            ) : null, // Tidak ada background/border jika tidak aktif
            child: Row(
              children: [
                Icon(icon, color: isActive ? const Color(0xFF25D366) : Colors.white70, size: 18),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(
                    title, 
                    style: TextStyle(
                      color: isActive ? Colors.white : Colors.white70, 
                      fontSize: 14, 
                      fontFamily: "ShareTechMono", 
                      fontWeight: isActive ? FontWeight.bold : FontWeight.w500,
                      letterSpacing: 1.0
                    )
                  ),
                ),
                if (isActive) // Titik bulat hijau di ujung kanan khusus menu aktif
                  Container(
                    width: 6,
                    height: 6,
                    decoration: const BoxDecoration(
                      color: Color(0xFF25D366),
                      shape: BoxShape.circle,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // --- NEW: Helper Widget untuk sub-menu Bug Tree ---
  Widget _buildTreeItem({required IconData icon, required String title, required String page}) {
    bool isActive = _activePage == page;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        splashColor: const Color(0xFF25D366).withOpacity(0.2),
        highlightColor: const Color(0xFF25D366).withOpacity(0.1),
        onTap: () => _selectFromDrawer(page),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8), // Area klik cukup luas
          child: Row(
            children: [
              Container(
                alignment: Alignment.center,
                width: 14,
                color: const Color(0xFF0A0D0B), // Cover garis vertical di belakangnya
                child: Icon(icon, color: isActive ? const Color(0xFF25D366) : Colors.white70, size: 16),
              ),
              const SizedBox(width: 16),
              Text(
                title,
                style: TextStyle(
                  color: isActive ? const Color(0xFF25D366) : Colors.white70,
                  fontSize: 13,
                  fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                  fontFamily: "ShareTechMono",
                  letterSpacing: 1.0,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // --- NEW: FLOATING NAVIGATION BAR BAWAH ---
  Widget _buildFloatingNavBar() {
    return Positioned(
      bottom: 30, // Mengambang tidak menempel di tepi bawah
      left: 15,
      right: 15,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF0A0D0B).withOpacity(0.95), // Latar gelap
          borderRadius: BorderRadius.circular(25),
          border: Border.all(
            color: const Color(0xFFE0E0E0).withOpacity(0.3), // Abu-abu border
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFE0E0E0).withOpacity(0.15), // Efek menyala (Glow abu-abu)
              blurRadius: 20,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildFloatingNavItem(Icons.home_filled, "Home", 'home'),
            _buildFloatingNavItem(FontAwesomeIcons.whatsapp, "Bug", 'bug'),
            _buildFloatingNavItem(FontAwesomeIcons.paperPlane, "Spam", 'telegram'),
            _buildFloatingNavItem(Icons.phone_android, "RAT", 'rat'),
            _buildFloatingNavItem(Icons.more_horiz, "More", 'more'),
          ],
        ),
      ),
    );
  }

  Widget _buildFloatingNavItem(IconData icon, String label, String page) {
    // Nav icon "Bug" juga akan menyala jika yang aktif adalah 'group_bug' atau 'custom_bug'
    bool isActive = _activePage == page || (page == 'bug' && (_activePage == 'group_bug' || _activePage == 'custom_bug'));

    return GestureDetector(
      onTap: () {
        if (page == 'more') {
          // Buka assistive menu jika ditekan more
          setState(() {
            _isAssistiveMenuOpen = !_isAssistiveMenuOpen;
          });
        } else if (page == 'bug') {
          // --- LOGIKA BARU KETIKA NAV BUG DI TEKAN: TAMPILKAN SHEET PILIHAN ---
          _showBugOptionsSheet();
          
          /* --- KODE LAMA DIBIKIN COMMENT ---
          _selectFromDrawer(page);
          */
        } else {
          _selectFromDrawer(page);
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: isActive
            ? BoxDecoration(
                color: const Color(0xFFE0E0E0).withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: const Color(0xFFE0E0E0).withOpacity(0.5), // Kotak nyala abu-abu
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFE0E0E0).withOpacity(0.2),
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ],
              )
            : const BoxDecoration(), // Kosong jika tidak aktif
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isActive ? const Color(0xFFE0E0E0) : Colors.white54,
              size: 22,
            ),
            const SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(
                color: isActive ? const Color(0xFFE0E0E0) : Colors.white54,
                fontSize: 10,
                fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                fontFamily: "ShareTechMono",
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Menangkap ukuran layar untuk batasan Assistive Touch & Animasi Menu
    final screenSize = MediaQuery.of(context).size;
    final bool isRightSide = _assistiveTouchPosition.dx > (screenSize.width / 2);
    final bool isBottomSide = _assistiveTouchPosition.dy > (screenSize.height / 2);

    // Menggunakan PopScope / WillPopScope agar ketika memencet tombol 'Back' bawaan HP,
    // aplikasi akan kembali ke Home terlebih dahulu (menjaga UI cangkang/shell).
    return WillPopScope(
      onWillPop: () async {
        if (_activePage != 'home') {
          _selectFromDrawer('home');
          return false; // Mencegah keluar aplikasi
        }
        return true; // Keluar aplikasi jika sudah di home
      },
      child: Scaffold(
        key: _scaffoldKey, 
        extendBodyBehindAppBar: true,
        backgroundColor: Colors.black,
        
        body: Stack(
          children: [
            // 1. Background Video (TETAP ADA)
            SizedBox.expand(
              child: _videoController != null && _videoController!.value.isInitialized
                  ? FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _videoController!.value.size.width,
                        height: _videoController!.value.size.height,
                        child: VideoPlayer(_videoController!),
                      ),
                    )
                  : Container(color: Colors.black),
            ),
            
            // 2. Layer gelap agar teks terbaca (TETAP ADA)
            Container(color: Colors.black.withOpacity(0.6)),

            // 3. Main Content (HALAMAN AKAN DI-REPLACE DISINI, BUKAN NAVIGATOR PUSH LAGI)
            SafeArea(
              top: false, // Membiarkan konten naik ke atas layar
              bottom: false, 
              child: FadeTransition(
                opacity: _animation,
                child: _selectedPage,
              ),
            ),

            // 4. Header Statis 
            // Disembunyikan saat membuka halaman selain 'home' agar tidak bertabrakan dengan AppBar halaman lain
            if (_activePage == 'home')
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: _buildHeader(),
              ),

            // 5. Layer Transparan untuk menutup menu jika di-tap di luar area
            if (_isAssistiveMenuOpen)
              Positioned.fill(
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      _isAssistiveMenuOpen = false;
                      _isBugToolsExpanded = false; // Tutup menu expand saat menu utama ditutup
                    });
                  },
                  child: Container(
                    color: Colors.transparent, // Tak terlihat tapi menangkap ketukan
                  ),
                ),
              ),

            // 6. Animasi Menu Pop-Up
            AnimatedPositioned(
              duration: const Duration(milliseconds: 150),
              // Penentuan posisi menu (di kiri/kanan bubble, atas/bawah)
              left: isRightSide ? _assistiveTouchPosition.dx - 250 : _assistiveTouchPosition.dx + 70,
              top: isBottomSide ? _assistiveTouchPosition.dy - 350 : _assistiveTouchPosition.dy,
              child: AnimatedScale(
                scale: _isAssistiveMenuOpen ? 1.0 : 0.0,
                duration: const Duration(milliseconds: 250),
                curve: Curves.easeOutBack, // Memberikan efek memantul ringan
                alignment: isRightSide 
                    ? (isBottomSide ? Alignment.bottomRight : Alignment.topRight)
                    : (isBottomSide ? Alignment.bottomLeft : Alignment.topLeft),
                child: _buildAssistiveMenu(),
              ),
            ),

            // 7. Assistive Touch Bubble
            Positioned(
              left: _assistiveTouchPosition.dx,
              top: _assistiveTouchPosition.dy,
              child: GestureDetector(
                onPanUpdate: (details) {
                  setState(() {
                    // Jika menu terbuka lalu di-drag, otomatis tertutup
                    if (_isAssistiveMenuOpen) {
                       _isAssistiveMenuOpen = false;
                       _isBugToolsExpanded = false;
                    }

                    double newX = _assistiveTouchPosition.dx + details.delta.dx;
                    double newY = _assistiveTouchPosition.dy + details.delta.dy;
                    
                    // Mencegah bubble keluar dari batas layar
                    newX = newX.clamp(0.0, screenSize.width - 60.0);
                    newY = newY.clamp(0.0, screenSize.height - 120.0);
                    
                    _assistiveTouchPosition = Offset(newX, newY);
                  });
                },
                onTap: () {
                  setState(() {
                    _isAssistiveMenuOpen = !_isAssistiveMenuOpen;
                    if(!_isAssistiveMenuOpen) _isBugToolsExpanded = false;
                  });
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    // Ubah warna bubble menjadi lebih hijau saat ditekan/menu terbuka
                    color: _isAssistiveMenuOpen ? const Color(0xFF102016) : Colors.black.withOpacity(0.6),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _isAssistiveMenuOpen ? const Color(0xFF25D366) : const Color(0xFFE0E0E0).withOpacity(0.4),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _isAssistiveMenuOpen ? const Color(0xFF25D366).withOpacity(0.5) : Colors.black.withOpacity(0.5),
                        blurRadius: 12,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        // Menggunakan icon dari assets
                        child: Image.asset(
                          'assets/images/logo.png', 
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),

            // 8. --- NAVIGATION BAR MENGAMBANG BARU ---
            _buildFloatingNavBar(),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _overlayEntry?.remove();
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _pageController.dispose();
    _videoController?.dispose(); // Pastikan memory dibersihkan
    
    // Mengembalikan status bar seperti semula saat pindah halaman (opsional)
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    
    super.dispose();
  }
}

/// Widget Media (gambar/video dengan audio)
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(1.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) {
    return url.endsWith(".mp4") ||
        url.endsWith(".webm") ||
        url.endsWith(".mov") ||
        url.endsWith(".mkv");
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      } else {
        return const Center(
            child: CircularProgressIndicator(color: Color(0xFFE0E0E0))); // Gray
      }
    } else {
      return Image.network(
        widget.url,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(color: Colors.black26),
      );
    }
  }
}