import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeManager extends ChangeNotifier {
  static final ThemeManager _instance = ThemeManager._();
  factory ThemeManager() => _instance;
  ThemeManager._();

  static const List<Map<String, dynamic>> themes = [
    {'name': 'Cyan', 'primary': Color(0xFF00BCD4), 'dark': Color(0xFF007B8A), 'key': 'cyan'},
    {'name': 'Purple', 'primary': Color(0xFF9C27B0), 'dark': Color(0xFF6A1B9A), 'key': 'purple'},
    {'name': 'Green', 'primary': Color(0xFF4CAF50), 'dark': Color(0xFF2E7D32), 'key': 'green'},
    {'name': 'Orange', 'primary': Color(0xFFFF5722), 'dark': Color(0xFFBF360C), 'key': 'orange'},
    {'name': 'Pink', 'primary': Color(0xFFE91E63), 'dark': Color(0xFF880E4F), 'key': 'pink'},
    {'name': 'Gold', 'primary': Color(0xFFFFD700), 'dark': Color(0xFFFF8F00), 'key': 'gold'},
  ];

  Color _primary = const Color(0xFF00BCD4);
  Color _dark = const Color(0xFF007B8A);
  String _themeKey = 'cyan';

  Color get primary => _primary;
  Color get dark => _dark;
  String get themeKey => _themeKey;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final key = prefs.getString('app_theme') ?? 'cyan';
    _applyKey(key, notify: false);
  }

  void setTheme(String key) async {
    _applyKey(key);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('app_theme', key);
  }

  void _applyKey(String key, {bool notify = true}) {
    final t = themes.firstWhere((t) => t['key'] == key, orElse: () => themes[0]);
    _primary = t['primary'] as Color;
    _dark = t['dark'] as Color;
    _themeKey = key;
    if (notify) notifyListeners();
  }
}
