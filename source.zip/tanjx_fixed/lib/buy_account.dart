import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class BuyAccountPage extends StatefulWidget {
  const BuyAccountPage({super.key});

  @override
  State<BuyAccountPage> createState() => _BuyAccountPageState();
}

class _BuyAccountPageState extends State<BuyAccountPage> {
  static const String _baseUrl = 'http://olinncntk.twinofc.my.id:1202';
  static const Color _bg = Color(0xFF060B14);
  static const Color _card = Color(0xFF0D1B2A);
  static const Color _cyan = Color(0xFF00E5CC);
  static const Color _border = Color(0xFF1A2E3A);

  bool _isLoading = true;
  List<dynamic> _prices = [];
  Map<String, String> _contact = {};

  @override
  void initState() {
    super.initState();
    _fetchPrices();
  }

  Future<void> _fetchPrices() async {
    try {
      final res = await http.get(
        Uri.parse('$_baseUrl/api/user/priceList'),
      ).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        setState(() {
          _prices = data['prices'] ?? [];
          _contact = Map<String, String>.from(data['contact'] ?? {});
          _isLoading = false;
        });
        return;
      }
    } catch (_) {}
    // Fallback static data
    setState(() {
      _prices = [
        {
          'type': 'member', 'title': 'Member Account',
          'monthly': {'price': 35000, 'label': '35K IDR / Bulan'},
          'permanent': {'price': 100000, 'label': '100K IDR / Permanen'},
          'features': ['Akses semua fitur dasar', 'Cooldown 300 detik', 'Max 5 bug per kirim'],
        },
        {
          'type': 'reseller', 'title': 'Reseller Account',
          'monthly': {'price': 40000, 'label': '40K IDR / Bulan'},
          'permanent': {'price': 140000, 'label': '140K IDR / Permanen'},
          'features': ['Bisa buat akun member', 'Cooldown 240 detik', 'Max 5 bug per kirim'],
        },
        {
          'type': 'vip', 'title': 'VIP Account',
          'monthly': {'price': 60000, 'label': '60K IDR / Bulan'},
          'permanent': {'price': 200000, 'label': '200K IDR / Permanen'},
          'features': ['Akses semua fitur VIP', 'Cooldown 60 detik', 'Max 10 bug per kirim', 'Private sender', 'Group bug & custom bug'],
        },
      ];
      _contact = {'telegram': 'https://t.me/RaldzzXyzo', 'whatsapp': 'https://wa.me/6285141370204'};
      _isLoading = false;
    });
  }

  Future<void> _openContact(String url, String plan, String duration) async {
    final price = _prices.firstWhere((p) => p['title'] == plan, orElse: () => null);
    final priceLabel = price != null ? price[duration]['label'] : '';
    String finalUrl = url;
    if (url.contains('wa.me')) {
      final msg = Uri.encodeComponent('Halo min, saya ingin beli $plan ($priceLabel) untuk TANIX Apps');
      finalUrl = '$url?text=$msg';
    } else if (url.contains('t.me')) {
      // open telegram
    }
    final uri = Uri.parse(finalUrl);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  void _showOrderDialog(Map plan) {
    String selectedDuration = 'monthly';
    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => Dialog(
          backgroundColor: _card,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(plan['title'], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
              const SizedBox(height: 20),
              Row(children: ['monthly', 'permanent'].map((d) {
                final sel = d == selectedDuration;
                final label = d == 'monthly' ? 'Bulanan' : 'Permanen';
                final price = plan[d]['label'];
                return Expanded(
                  child: GestureDetector(
                    onTap: () => setS(() => selectedDuration = d),
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: sel ? _cyan.withAlpha(30) : _bg,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: sel ? _cyan : _border, width: sel ? 2 : 1),
                      ),
                      child: Column(children: [
                        Text(label, style: TextStyle(color: sel ? _cyan : Colors.white60, fontSize: 12, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        Text(price, style: TextStyle(color: sel ? Colors.white : Colors.white38, fontSize: 11)),
                      ]),
                    ),
                  ),
                );
              }).toList()),
              const SizedBox(height: 20),
              const Text('Pilih metode kontak:', style: TextStyle(color: Colors.white54, fontSize: 12)),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () { Navigator.pop(ctx); _openContact(_contact['telegram'] ?? '', plan['title'], selectedDuration); },
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0288D1), foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                    icon: const Icon(Icons.telegram, size: 18),
                    label: const Text('Telegram', style: TextStyle(fontSize: 12)),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () { Navigator.pop(ctx); _openContact(_contact['whatsapp'] ?? '', plan['title'], selectedDuration); },
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4CAF50), foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                    icon: const Icon(Icons.chat_rounded, size: 18),
                    label: const Text('WhatsApp', style: TextStyle(fontSize: 12)),
                  ),
                ),
              ]),
              const SizedBox(height: 8),
              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Tutup', style: TextStyle(color: Colors.white38))),
            ]),
          ),
        ),
      ),
    );
  }

  static const Map<String, Color> _typeColors = {
    'member': Color(0xFF00B8A9),
    'reseller': Color(0xFF9C27B0),
    'vip': Color(0xFFFFD700),
  };

  static const Map<String, IconData> _typeIcons = {
    'member': Icons.person_rounded,
    'reseller': Icons.store_rounded,
    'vip': Icons.workspace_premium_rounded,
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white), onPressed: () => Navigator.pop(context)),
        title: const Text('BELI AKUN', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 2)),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(color: _border, height: 1)),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFF00E5CC)))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF0D2A3A), Color(0xFF0D1B2A)]),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: _cyan.withAlpha(60)),
                  ),
                  child: Row(children: [
                    Container(width: 48, height: 48, decoration: BoxDecoration(color: _cyan.withAlpha(30), borderRadius: BorderRadius.circular(12)), child: Icon(Icons.shopping_cart_rounded, color: _cyan, size: 24)),
                    const SizedBox(width: 12),
                    const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('Pembelian Akun TANIX', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                      Text('Pilih paket dan hubungi admin', style: TextStyle(color: Colors.white54, fontSize: 12)),
                    ])),
                  ]),
                ),
                const SizedBox(height: 20),
                ..._prices.map((plan) {
                  final type = plan['type'] as String;
                  final color = _typeColors[type] ?? _cyan;
                  final icon = _typeIcons[type] ?? Icons.person_rounded;
                  final features = List<String>.from(plan['features'] ?? []);
                  return Container(
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                      color: _card,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: color.withAlpha(80)),
                    ),
                    child: Column(children: [
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: color.withAlpha(20),
                          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                          border: Border(bottom: BorderSide(color: color.withAlpha(40))),
                        ),
                        child: Row(children: [
                          Container(width: 44, height: 44, decoration: BoxDecoration(color: color.withAlpha(30), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: color, size: 22)),
                          const SizedBox(width: 12),
                          Expanded(child: Text(plan['title'], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16))),
                          Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: color.withAlpha(30), borderRadius: BorderRadius.circular(20), border: Border.all(color: color.withAlpha(60))),
                            child: Text(type.toUpperCase(), style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1)),
                          ),
                        ]),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Row(children: [
                            Expanded(child: _PriceBox(label: 'Bulanan', price: plan['monthly']['label'], color: color)),
                            const SizedBox(width: 10),
                            Expanded(child: _PriceBox(label: 'Permanen', price: plan['permanent']['label'], color: color)),
                          ]),
                          const SizedBox(height: 14),
                          ...features.map((f) => Padding(
                            padding: const EdgeInsets.only(bottom: 6),
                            child: Row(children: [
                              Icon(Icons.check_circle_rounded, color: color, size: 14),
                              const SizedBox(width: 8),
                              Text(f, style: const TextStyle(color: Colors.white70, fontSize: 12)),
                            ]),
                          )),
                          const SizedBox(height: 14),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: () => _showOrderDialog(plan),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: color,
                                foregroundColor: Colors.black,
                                padding: const EdgeInsets.symmetric(vertical: 12),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              ),
                              child: Text('BELI ${(plan['title'] as String).toUpperCase()}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 1)),
                            ),
                          ),
                        ]),
                      ),
                    ]),
                  );
                }),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: Colors.orange.withAlpha(15), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.orange.withAlpha(40))),
                  child: const Row(children: [
                    Icon(Icons.info_outline_rounded, color: Colors.orange, size: 18),
                    SizedBox(width: 10),
                    Expanded(child: Text('Pembayaran dikonfirmasi manual oleh admin. Akun aktif dalam 1×24 jam setelah konfirmasi.', style: TextStyle(color: Colors.orange, fontSize: 12))),
                  ]),
                ),
                const SizedBox(height: 20),
              ]),
            ),
    );
  }
}

class _PriceBox extends StatelessWidget {
  final String label;
  final String price;
  final Color color;
  const _PriceBox({required this.label, required this.price, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFF060B14), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFF1A2E3A))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(color: Colors.white38, fontSize: 10, letterSpacing: 1)),
        const SizedBox(height: 4),
        Text(price, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 13)),
      ]),
    );
  }
}
