import 'package:flutter/material.dart';
import 'ddos_panel.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class DDoSMenuPage extends StatelessWidget {
  final String sessionKey;
  final List<Map<String, dynamic>> listDDoS;
  const DDoSMenuPage({super.key, required this.sessionKey, required this.listDDoS});

  @override
  Widget build(BuildContext context) {
    return AttackPanel(sessionKey: sessionKey, listDDoS: listDDoS);
  }
}
