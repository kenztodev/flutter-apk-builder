import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class TesFuncPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  const TesFuncPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<TesFuncPage> createState() => _TesFuncPageState();
}

class _TesFuncPageState extends State<TesFuncPage> {
  static const String baseUrl = "http://olinncntk.twinofc.my.id:1202";
  static const Color _teal = Color(0xFF00E5CC);
  static const Color _bg   = Color(0xFF0A0E1A);
  static const Color _card = Color(0xFF111827);
  static const Color _red  = Color(0xFFE53935);

  final _targetCtrl  = TextEditingController();
  final _funcCtrl    = TextEditingController();
  final _delayCtrl   = TextEditingController(text: '1000');
  final _loopsCtrl   = TextEditingController(text: '1');

  bool _isSending = false;
  String? _fileName;
  List<Map<String, dynamic>> _history = [];

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  @override
  void dispose() {
    _targetCtrl.dispose();
    _funcCtrl.dispose();
    _delayCtrl.dispose();
    _loopsCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('tes_func_history') ?? '[]';
    setState(() => _history = List<Map<String, dynamic>>.from(jsonDecode(raw)));
  }

  Future<void> _saveHistory(Map<String, dynamic> entry) async {
    final prefs = await SharedPreferences.getInstance();
    _history.insert(0, entry);
    if (_history.length > 20) _history = _history.sublist(0, 20);
    await prefs.setString('tes_func_history', jsonEncode(_history));
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['js', 'txt'],
    );
    if (result != null && result.files.single.path != null) {
      final file = File(result.files.single.path!);
      final content = await file.readAsString();
      setState(() {
        _funcCtrl.text = content;
        _fileName = result.files.single.name;
      });
    }
  }

  Future<void> _sendFunction() async {
    final target = _targetCtrl.text.trim();
    final func   = _funcCtrl.text.trim();
    final delay  = int.tryParse(_delayCtrl.text) ?? 1000;
    final loops  = int.tryParse(_loopsCtrl.text) ?? 1;

    if (target.isEmpty) {
      _snack('Nomor target wajib diisi!', Colors.red);
      return;
    }
    if (func.isEmpty) {
      _snack('Function / Message kosong!', Colors.red);
      return;
    }

    setState(() => _isSending = true);

    int success = 0;
    int fail = 0;

    for (int i = 0; i < loops; i++) {
      try {
        final res = await http.post(
          Uri.parse('$baseUrl/api/whatsapp/execute'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'key': widget.sessionKey,
            'target': target,
            'message': func,
            'delay': delay,
            'amount': 1,
          }),
        );
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          if (data['cooldown'] == true) {
            final wait = data['wait'] ?? 0;
            _snack('Cooldown! Tunggu $wait detik', Colors.orange);
            setState(() => _isSending = false);
            return;
          }
          if (data['sended'] == true || data['valid'] == true) {
            success++;
          } else {
            fail++;
          }
        } else {
          fail++;
        }
      } catch (_) {
        fail++;
      }
      if (i < loops - 1) {
        await Future.delayed(Duration(milliseconds: delay));
      }
    }

    await _saveHistory({
      'target': target,
      'func': func.length > 50 ? '${func.substring(0, 50)}...' : func,
      'loops': loops,
      'delay': delay,
      'success': success,
      'fail': fail,
      'time': DateTime.now().toIso8601String(),
    });

    setState(() => _isSending = false);
    _snack('Selesai! ✅ $success berhasil, ❌ $fail gagal',
      success > 0 ? Colors.green : Colors.red);
    await _loadHistory();
  }

  void _snack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono')),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  void _showHistory() {
    showModalBottomSheet(
      context: context,
      backgroundColor: _card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Column(
        children: [
          const SizedBox(height: 12),
          Container(width: 40, height: 4,
            decoration: BoxDecoration(color: Colors.white24,
              borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 12),
          const Text('RIWAYAT', style: TextStyle(color: Colors.white,
            fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Expanded(
            child: _history.isEmpty
              ? const Center(child: Text('Belum ada riwayat',
                  style: TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono')))
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: _history.length,
                  itemBuilder: (ctx, i) {
                    final h = _history[i];
                    final dt = DateTime.tryParse(h['time'] ?? '') ?? DateTime.now();
                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.white.withOpacity(0.08)),
                      ),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                          Text('→ ${h['target']}', style: const TextStyle(
                            color: _teal, fontFamily: 'ShareTechMono', fontSize: 13)),
                          Text('${dt.day}/${dt.month} ${dt.hour}:${dt.minute.toString().padLeft(2,"0")}',
                            style: const TextStyle(color: Colors.white38, fontSize: 11)),
                        ]),
                        const SizedBox(height: 4),
                        Text('${h['func']}', style: const TextStyle(
                          color: Colors.white54, fontSize: 12), maxLines: 1, overflow: TextOverflow.ellipsis),
                        const SizedBox(height: 4),
                        Row(children: [
                          Icon(Icons.check_circle_rounded, color: Colors.green, size: 14),
                          const SizedBox(width: 4),
                          Text('${h['success']}', style: const TextStyle(color: Colors.green, fontSize: 12)),
                          const SizedBox(width: 12),
                          Icon(Icons.cancel_rounded, color: _red, size: 14),
                          const SizedBox(width: 4),
                          Text('${h['fail']}', style: const TextStyle(color: Colors.red, fontSize: 12)),
                          const Spacer(),
                          Text('${h['loops']}x loop / ${h['delay']}ms',
                            style: const TextStyle(color: Colors.white38, fontSize: 11)),
                        ]),
                      ]),
                    );
                  },
                ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        backgroundColor: _bg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded, color: Colors.white70),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('TES FUNC', style: TextStyle(
          color: Colors.white, fontFamily: 'Orbitron',
          fontWeight: FontWeight.bold, letterSpacing: 2)),
        actions: [
          IconButton(
            icon: const Icon(Icons.history_rounded, color: Colors.white54),
            onPressed: _showHistory,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // ─── Header Card ───
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _card,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _teal.withOpacity(0.3)),
            ),
            child: Row(children: [
              Container(
                width: 52, height: 52,
                decoration: BoxDecoration(
                  color: _teal.withOpacity(0.15),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.code_rounded, color: _teal, size: 28),
              ),
              const SizedBox(width: 14),
              const Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Test Function', style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                  SizedBox(height: 4),
                  Text('Kirim function custom dengan delay & loops',
                    style: TextStyle(color: Colors.white54, fontSize: 12)),
                ],
              )),
            ]),
          ),
          const SizedBox(height: 20),

          // ─── Nomor Target ───
          const Text('Nomor Target', style: TextStyle(
            color: Colors.white70, fontFamily: 'ShareTechMono', fontSize: 13)),
          const SizedBox(height: 8),
          _inputField('62xxx (contoh: 6281234567890)', _targetCtrl,
            Icons.phone_rounded, keyboardType: TextInputType.phone),
          const SizedBox(height: 16),

          // ─── Function / Message ───
          const Text('Function / Message', style: TextStyle(
            color: Colors.white70, fontFamily: 'ShareTechMono', fontSize: 13)),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(
              color: _card,
              borderRadius: BorderRadius.circular(13),
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: TextField(
              controller: _funcCtrl,
              maxLines: 8,
              style: const TextStyle(color: Colors.white, fontSize: 13,
                fontFamily: 'ShareTechMono'),
              cursorColor: _teal,
              decoration: InputDecoration(
                hintText: 'Paste function atau message di sini...',
                hintStyle: TextStyle(color: Colors.white.withOpacity(0.25),
                  fontSize: 13),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.all(14),
              ),
            ),
          ),
          const SizedBox(height: 12),

          // ─── File Picker + Clear ───
          Row(children: [
            Expanded(
              child: GestureDetector(
                onTap: _pickFile,
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    color: _teal.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(13),
                    border: Border.all(color: _teal.withOpacity(0.4)),
                  ),
                  child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    const Icon(Icons.upload_file_rounded, color: _teal, size: 18),
                    const SizedBox(width: 8),
                    Text(_fileName ?? 'Pilih File .js',
                      style: const TextStyle(color: _teal,
                        fontFamily: 'ShareTechMono', fontSize: 13),
                      overflow: TextOverflow.ellipsis),
                  ]),
                ),
              ),
            ),
            const SizedBox(width: 10),
            GestureDetector(
              onTap: () => setState(() {
                _funcCtrl.clear();
                _fileName = null;
              }),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                decoration: BoxDecoration(
                  color: _red.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(13),
                  border: Border.all(color: _red.withOpacity(0.4)),
                ),
                child: Row(children: [
                  Icon(Icons.close_rounded, color: _red, size: 18),
                  const SizedBox(width: 6),
                  Text('Clear', style: TextStyle(color: _red,
                    fontFamily: 'ShareTechMono', fontSize: 13)),
                ]),
              ),
            ),
          ]),
          const SizedBox(height: 16),

          // ─── Delay + Loops ───
          Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Delay (ms)', style: TextStyle(
                color: Colors.white70, fontFamily: 'ShareTechMono', fontSize: 13)),
              const SizedBox(height: 8),
              Container(
                decoration: BoxDecoration(
                  color: _card,
                  borderRadius: BorderRadius.circular(13),
                  border: Border.all(color: Colors.white.withOpacity(0.08)),
                ),
                child: TextField(
                  controller: _delayCtrl,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(color: Colors.white),
                  cursorColor: _teal,
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.timer_rounded,
                      color: _teal.withOpacity(0.7), size: 20),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(
                      vertical: 14, horizontal: 16),
                  ),
                ),
              ),
            ])),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Jumlah Loops', style: TextStyle(
                color: Colors.white70, fontFamily: 'ShareTechMono', fontSize: 13)),
              const SizedBox(height: 8),
              Container(
                decoration: BoxDecoration(
                  color: _card,
                  borderRadius: BorderRadius.circular(13),
                  border: Border.all(color: Colors.white.withOpacity(0.08)),
                ),
                child: TextField(
                  controller: _loopsCtrl,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(color: Colors.white),
                  cursorColor: _teal,
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.loop_rounded,
                      color: _teal.withOpacity(0.7), size: 20),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(
                      vertical: 14, horizontal: 16),
                  ),
                ),
              ),
            ])),
          ]),
          const SizedBox(height: 20),

          // ─── KIRIM FUNCTION + Reset ───
          Row(children: [
            Expanded(
              child: GestureDetector(
                onTap: _isSending ? null : _sendFunction,
                child: Container(
                  height: 54,
                  decoration: BoxDecoration(
                    color: _teal,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Center(
                    child: _isSending
                      ? const SizedBox(width: 22, height: 22,
                          child: CircularProgressIndicator(
                            color: Colors.black, strokeWidth: 2.5))
                      : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(Icons.send_rounded, color: Colors.black, size: 20),
                          SizedBox(width: 10),
                          Text('KIRIM FUNCTION', style: TextStyle(
                            color: Colors.black, fontFamily: 'Orbitron',
                            fontWeight: FontWeight.bold, letterSpacing: 1.5,
                            fontSize: 14)),
                        ]),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            GestureDetector(
              onTap: () {
                _targetCtrl.clear();
                _funcCtrl.clear();
                _delayCtrl.text = '1000';
                _loopsCtrl.text = '1';
                setState(() => _fileName = null);
              },
              child: Container(
                width: 54, height: 54,
                decoration: BoxDecoration(
                  color: _red.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _red.withOpacity(0.4)),
                ),
                child: Icon(Icons.refresh_rounded, color: _red),
              ),
            ),
          ]),
          const SizedBox(height: 20),

          // ─── Informasi ───
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _card,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.white.withOpacity(0.07)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Icon(Icons.info_outline_rounded, color: _teal, size: 18),
                const SizedBox(width: 8),
                const Text('informasi', style: TextStyle(
                  color: Colors.white70, fontSize: 14)),
              ]),
              const SizedBox(height: 10),
              ...[
                'Gunakan format nomor internasional (62xxx)',
                'File .js akan dibaca sebagai plain text',
                'Delay dalam milidetik (ms)',
                'Loops menentukan jumlah pengiriman',
                'Function akan dikirim sebagai payload',
              ].map((t) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text('• $t', style: const TextStyle(
                  color: Colors.white38, fontSize: 12,
                  fontFamily: 'ShareTechMono')),
              )),
            ]),
          ),
          const SizedBox(height: 32),
        ]),
      ),
    );
  }

  Widget _inputField(String hint, TextEditingController ctrl, IconData icon,
      {TextInputType keyboardType = TextInputType.text}) {
    return Container(
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: TextField(
        controller: ctrl,
        keyboardType: keyboardType,
        style: const TextStyle(color: Colors.white),
        cursorColor: _teal,
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: Colors.white38, size: 20),
          hintText: hint,
          hintStyle: const TextStyle(color: Colors.white24, fontSize: 13),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        ),
      ),
    );
  }
}
