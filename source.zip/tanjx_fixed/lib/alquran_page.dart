import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AlquranPage extends StatefulWidget {
  const AlquranPage({super.key});
  @override
  State<AlquranPage> createState() => _AlquranPageState();
}

class _AlquranPageState extends State<AlquranPage> with SingleTickerProviderStateMixin {
  static const Color _teal = Color(0xFF00E5CC);
  static const Color _bg   = Color(0xFF0A0E1A);
  static const Color _card = Color(0xFF111827);

  List<dynamic> _surahs = [];
  bool _loading = true;
  String _search = '';
  final _searchCtrl = TextEditingController();
  late AnimationController _animCtrl;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _fadeAnim = CurvedAnimation(parent: _animCtrl, curve: Curves.easeOut);
    _animCtrl.forward();
    _fetchSurahs();
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _fetchSurahs() async {
    try {
      final res = await http.get(Uri.parse('https://api.alquran.cloud/v1/surah'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        setState(() { _surahs = data['data']; _loading = false; });
      }
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  List<dynamic> get _filtered => _surahs.where((s) {
    final q = _search.toLowerCase();
    return s['englishName'].toString().toLowerCase().contains(q) ||
           s['name'].toString().contains(q) ||
           s['number'].toString().contains(q);
  }).toList();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: FadeTransition(
        opacity: _fadeAnim,
        child: CustomScrollView(slivers: [
          SliverAppBar(
            backgroundColor: _bg,
            pinned: true,
            elevation: 0,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios_rounded, color: Colors.white70),
              onPressed: () => Navigator.pop(context),
            ),
            title: const Text('Al-Quran',
                style: TextStyle(color: Colors.white, fontFamily: 'Orbitron',
                    fontSize: 16, fontWeight: FontWeight.bold)),
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(60),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                child: Container(
                  decoration: BoxDecoration(
                    color: _card,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _teal.withOpacity(0.25)),
                  ),
                  child: TextField(
                    controller: _searchCtrl,
                    style: const TextStyle(color: Colors.white),
                    cursorColor: _teal,
                    onChanged: (v) => setState(() => _search = v),
                    decoration: InputDecoration(
                      prefixIcon: const Icon(Icons.search_rounded, color: Colors.white38, size: 20),
                      hintText: 'Cari surah...',
                      hintStyle: const TextStyle(color: Colors.white30),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(vertical: 14),
                      suffixIcon: _search.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.clear, color: Colors.white30, size: 18),
                              onPressed: () { _searchCtrl.clear(); setState(() => _search = ''); })
                          : null,
                    ),
                  ),
                ),
              ),
            ),
          ),
          if (_loading)
            const SliverFillRemaining(
              child: Center(child: CircularProgressIndicator(color: _teal, strokeWidth: 2)),
            )
          else if (_filtered.isEmpty)
            const SliverFillRemaining(
              child: Center(child: Text('Surah tidak ditemukan',
                  style: TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono'))),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 100),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (ctx, i) {
                    final s = _filtered[i];
                    return GestureDetector(
                      onTap: () => Navigator.push(context,
                          MaterialPageRoute(builder: (_) => AyatPage(surah: s))),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        decoration: BoxDecoration(
                          color: _card,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: Colors.white.withOpacity(0.06)),
                        ),
                        child: Row(children: [
                          Container(
                            width: 42, height: 42,
                            decoration: BoxDecoration(
                              border: Border.all(color: _teal.withOpacity(0.4)),
                              borderRadius: BorderRadius.circular(10),
                              color: _teal.withOpacity(0.08),
                            ),
                            child: Center(
                              child: Text('${s['number']}',
                                  style: const TextStyle(color: _teal,
                                      fontFamily: 'Orbitron', fontSize: 13,
                                      fontWeight: FontWeight.bold)),
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(s['englishName'],
                                  style: const TextStyle(color: Colors.white,
                                      fontSize: 15, fontWeight: FontWeight.w600)),
                              const SizedBox(height: 3),
                              Text('${s['englishNameTranslation']}  •  ${s['numberOfAyahs']} ayat',
                                  style: TextStyle(color: Colors.white.withOpacity(0.4),
                                      fontSize: 12, fontFamily: 'ShareTechMono')),
                            ],
                          )),
                          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                            Text(s['name'],
                                style: const TextStyle(color: _teal, fontSize: 18,
                                    fontFamily: null)),
                            const SizedBox(height: 4),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: _teal.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(s['revelationType'],
                                  style: const TextStyle(color: _teal, fontSize: 10,
                                      fontFamily: 'ShareTechMono')),
                            ),
                          ]),
                        ]),
                      ),
                    );
                  },
                  childCount: _filtered.length,
                ),
              ),
            ),
        ]),
      ),
    );
  }
}

// ─────────────────────────────────────────
//  Ayat Page
// ─────────────────────────────────────────
class AyatPage extends StatefulWidget {
  final dynamic surah;
  const AyatPage({super.key, required this.surah});
  @override
  State<AyatPage> createState() => _AyatPageState();
}

class _AyatPageState extends State<AyatPage> {
  static const Color _teal = Color(0xFF00E5CC);
  static const Color _bg   = Color(0xFF0A0E1A);
  static const Color _card = Color(0xFF111827);

  List<dynamic> _ayahs = [];
  bool _loading = true;
  bool _showTranslation = true;

  @override
  void initState() {
    super.initState();
    _fetchAyahs();
  }

  Future<void> _fetchAyahs() async {
    try {
      // Ambil Arab + terjemahan Indonesia
      final arabRes = await http.get(Uri.parse(
          'https://api.alquran.cloud/v1/surah/${widget.surah['number']}'));
      final idRes = await http.get(Uri.parse(
          'https://api.alquran.cloud/v1/surah/${widget.surah['number']}/id.indonesian'));

      if (arabRes.statusCode == 200 && idRes.statusCode == 200) {
        final arab = jsonDecode(arabRes.body)['data']['ayahs'] as List;
        final id   = jsonDecode(idRes.body)['data']['ayahs'] as List;
        final merged = List.generate(arab.length, (i) => {
          'number': arab[i]['numberInSurah'],
          'arab': arab[i]['text'],
          'id': id[i]['text'],
        });
        setState(() { _ayahs = merged; _loading = false; });
      }
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded, color: Colors.white70),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(widget.surah['englishName'],
              style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron',
                  fontSize: 14, fontWeight: FontWeight.bold)),
          Text('${widget.surah['numberOfAyahs']} ayat  •  ${widget.surah['revelationType']}',
              style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 11,
                  fontFamily: 'ShareTechMono')),
        ]),
        actions: [
          IconButton(
            icon: Icon(_showTranslation ? Icons.translate : Icons.translate_outlined,
                color: _showTranslation ? _teal : Colors.white38),
            onPressed: () => setState(() => _showTranslation = !_showTranslation),
            tooltip: 'Toggle Terjemahan',
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _teal, strokeWidth: 2))
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 80),
              itemCount: _ayahs.length,
              itemBuilder: (ctx, i) {
                final a = _ayahs[i];
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _card,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white.withOpacity(0.06)),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    // ─── Nomor ayat ───
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      Container(
                        width: 32, height: 32,
                        decoration: BoxDecoration(
                          color: _teal.withOpacity(0.12),
                          shape: BoxShape.circle,
                          border: Border.all(color: _teal.withOpacity(0.3)),
                        ),
                        child: Center(
                          child: Text('${a['number']}',
                              style: const TextStyle(color: _teal,
                                  fontSize: 11, fontFamily: 'Orbitron')),
                        ),
                      ),
                      const Icon(Icons.bookmark_border_rounded, color: Colors.white24, size: 18),
                    ]),
                    const SizedBox(height: 14),
                    // ─── Teks Arab ───
                    Text(a['arab'],
                        textAlign: TextAlign.right,
                        style: const TextStyle(color: Colors.white,
                            fontSize: 24, height: 2.0, fontFamily: null)),
                    // ─── Terjemahan ───
                    if (_showTranslation) ...[
                      const SizedBox(height: 10),
                      Divider(color: Colors.white.withOpacity(0.08)),
                      const SizedBox(height: 8),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(a['id'],
                            textAlign: TextAlign.left,
                            style: TextStyle(color: Colors.white.withOpacity(0.55),
                                fontSize: 13, height: 1.6, fontStyle: FontStyle.italic)),
                      ),
                    ],
                  ]),
                );
              },
            ),
    );
  }
}
