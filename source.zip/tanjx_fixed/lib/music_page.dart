import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MusicPage extends StatefulWidget {
  const MusicPage({super.key});
  @override
  State<MusicPage> createState() => _MusicPageState();
}

class _MusicPageState extends State<MusicPage> with TickerProviderStateMixin {
  static const Color _bg = Color(0xFF050505);
  static const Color _card = Color(0xFF111111);
  static const Color _green = Color(0xFF1DB954);
  static const Color _border = Color(0xFF1E1E1E);
  static const Color _text2 = Color(0xFF888888);

  int _tabIndex = 0;
  final TextEditingController _searchCtrl = TextEditingController();
  bool _isSearching = false;
  List<dynamic> _searchResults = [];
  List<Map<String, dynamic>> _favorites = [];
  List<Map<String, dynamic>> _history = [];
  List<Map<String, dynamic>> _playlist = [];
  Map<String, dynamic>? _nowPlaying;
  bool _isPlaying = false;

  late TabController _tabController;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _tabController.addListener(() => setState(() => _tabIndex = _tabController.index));
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.8, end: 1.0).animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _loadLocalData();
  }

  Future<void> _loadLocalData() async {
    final prefs = await SharedPreferences.getInstance();
    final favJson = prefs.getStringList('music_favorites') ?? [];
    final histJson = prefs.getStringList('music_history') ?? [];
    final plJson = prefs.getStringList('music_playlist') ?? [];
    setState(() {
      _favorites = favJson.map((s) => Map<String, dynamic>.from(jsonDecode(s))).toList();
      _history = histJson.map((s) => Map<String, dynamic>.from(jsonDecode(s))).toList();
      _playlist = plJson.map((s) => Map<String, dynamic>.from(jsonDecode(s))).toList();
    });
  }

  Future<void> _saveData(String key, List<Map<String, dynamic>> list) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(key, list.map((m) => jsonEncode(m)).toList());
  }

  Future<void> _searchMusic(String query) async {
    if (query.trim().isEmpty) return;
    setState(() { _isSearching = true; _searchResults = []; });
    try {
      final res = await http.get(Uri.parse('https://api.deezer.com/search?q=${Uri.encodeComponent(query)}&limit=20'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        setState(() { _searchResults = data['data'] ?? []; _isSearching = false; });
      } else {
        setState(() => _isSearching = false);
      }
    } catch (_) {
      setState(() => _isSearching = false);
    }
  }

  void _playSong(Map<String, dynamic> song) async {
    setState(() { _nowPlaying = song; _isPlaying = true; });
    final track = {'id': song['id'].toString(), 'title': song['title'] ?? '', 'artist': song['artist']?['name'] ?? '', 'cover': song['album']?['cover_medium'] ?? ''};
    if (!_history.any((h) => h['id'] == track['id'])) {
      _history.insert(0, track);
      if (_history.length > 50) _history.removeLast();
      _saveData('music_history', _history);
    }
    final previewUrl = song['preview'];
    if (previewUrl != null && previewUrl.toString().isNotEmpty) {
      launchUrl(Uri.parse(previewUrl.toString()), mode: LaunchMode.externalApplication);
    }
  }

  void _toggleFavorite(Map<String, dynamic> song) async {
    final track = {'id': song['id'].toString(), 'title': song['title'] ?? '', 'artist': song['artist']?['name'] ?? '', 'cover': song['album']?['cover_medium'] ?? ''};
    setState(() {
      if (_favorites.any((f) => f['id'] == track['id'])) {
        _favorites.removeWhere((f) => f['id'] == track['id']);
      } else {
        _favorites.add(track);
      }
    });
    _saveData('music_favorites', _favorites);
  }

  void _addToPlaylist(Map<String, dynamic> song) async {
    final track = {'id': song['id'].toString(), 'title': song['title'] ?? '', 'artist': song['artist']?['name'] ?? '', 'cover': song['album']?['cover_medium'] ?? ''};
    if (!_playlist.any((p) => p['id'] == track['id'])) {
      setState(() => _playlist.add(track));
      _saveData('music_playlist', _playlist);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: _green, content: Text("${track['title']} ditambahkan ke playlist", style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold))));
    }
  }

  bool _isFav(dynamic song) => _favorites.any((f) => f['id'] == song['id'].toString());

  @override
  void dispose() {
    _tabController.dispose();
    _searchCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: Column(
        children: [
          _buildHeader(),
          _buildSearchBar(),
          _buildTabBar(),
          Expanded(child: _buildTabContent()),
          if (_nowPlaying != null) _buildMiniPlayer(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 12, left: 16, right: 16, bottom: 12),
      color: _bg,
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 38, height: 38,
              decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10), border: Border.all(color: _border)),
              child: const Icon(Icons.arrow_back_rounded, color: Colors.white, size: 18),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(color: _green, borderRadius: BorderRadius.circular(10)),
            child: const Icon(Icons.music_note_rounded, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 10),
          const Text("MANTA Music", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
          const Spacer(),
          GestureDetector(
            onTap: () {},
            child: Container(
              width: 38, height: 38,
              decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10), border: Border.all(color: _border)),
              child: const Icon(Icons.history_rounded, color: Colors.white60, size: 20),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () {},
            child: Container(
              width: 38, height: 38,
              decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10), border: Border.all(color: _border)),
              child: const Icon(Icons.queue_music_rounded, color: Colors.white60, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Container(
        decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(30), border: Border.all(color: _border)),
        child: TextField(
          controller: _searchCtrl,
          style: const TextStyle(color: Colors.white, fontSize: 14),
          onSubmitted: _searchMusic,
          decoration: InputDecoration(
            hintText: "Search songs, artists...",
            hintStyle: const TextStyle(color: Colors.white30, fontSize: 14),
            prefixIcon: const Icon(Icons.search_rounded, color: Colors.white38, size: 20),
            suffixIcon: _searchCtrl.text.isNotEmpty
                ? GestureDetector(
                    onTap: () { _searchCtrl.clear(); setState(() => _searchResults = []); },
                    child: const Icon(Icons.close_rounded, color: Colors.white38, size: 18),
                  )
                : null,
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          ),
          onChanged: (v) => setState(() {}),
        ),
      ),
    );
  }

  Widget _buildTabBar() {
    final tabs = [
      {'icon': Icons.search_rounded, 'label': 'Search'},
      {'icon': Icons.queue_music_rounded, 'label': 'Playlist'},
      {'icon': Icons.favorite_rounded, 'label': 'Favorites'},
      {'icon': Icons.download_rounded, 'label': 'Downloads'},
    ];
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(14), border: Border.all(color: _border)),
      child: Row(
        children: List.generate(tabs.length, (i) {
          final sel = _tabIndex == i;
          return Expanded(
            child: GestureDetector(
              onTap: () { _tabController.animateTo(i); setState(() => _tabIndex = i); },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: sel ? _green.withOpacity(0.15) : Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(tabs[i]['icon'] as IconData, color: sel ? _green : Colors.white38, size: 20),
                    const SizedBox(height: 3),
                    Text(tabs[i]['label'] as String, style: TextStyle(color: sel ? _green : Colors.white38, fontSize: 10, fontWeight: sel ? FontWeight.bold : FontWeight.normal)),
                    if (sel) Container(margin: const EdgeInsets.only(top: 4), width: 16, height: 2, decoration: BoxDecoration(color: _green, borderRadius: BorderRadius.circular(2))),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildTabContent() {
    return TabBarView(
      controller: _tabController,
      physics: const NeverScrollableScrollPhysics(),
      children: [_buildSearchTab(), _buildPlaylistTab(), _buildFavoritesTab(), _buildDownloadsTab()],
    );
  }

  Widget _buildSearchTab() {
    if (_searchResults.isEmpty && !_isSearching) {
      return Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.search_rounded, color: Colors.white12, size: 72),
          const SizedBox(height: 16),
          const Text("Search for music", style: TextStyle(color: Colors.white70, fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          const Text("Find songs, artists, or albums", style: TextStyle(color: Colors.white30, fontSize: 13)),
        ]),
      );
    }
    if (_isSearching) {
      return const Center(child: CircularProgressIndicator(color: Color(0xFF1DB954)));
    }
    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: _searchResults.length,
      itemBuilder: (ctx, i) => _buildSongTile(_searchResults[i]),
    );
  }

  Widget _buildSongTile(dynamic song, {bool isLocal = false}) {
    final cover = isLocal ? (song['cover'] ?? '') : (song['album']?['cover_medium'] ?? '');
    final title = isLocal ? (song['title'] ?? '') : (song['title'] ?? '');
    final artist = isLocal ? (song['artist'] ?? '') : (song['artist']?['name'] ?? '');
    final isFav = isLocal ? false : _isFav(song);
    final isNow = _nowPlaying != null && _nowPlaying!['id'].toString() == song['id'].toString();

    return GestureDetector(
      onTap: () => isLocal ? null : _playSong(song),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: isNow ? _green.withOpacity(0.1) : _card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: isNow ? _green.withOpacity(0.3) : _border),
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: cover.isNotEmpty
                  ? Image.network(cover, width: 48, height: 48, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _albumPlaceholder())
                  : _albumPlaceholder(),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: isNow ? _green : Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                const SizedBox(height: 3),
                Text(artist, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white38, fontSize: 11)),
              ]),
            ),
            if (!isLocal) ...[
              GestureDetector(
                onTap: () => _toggleFavorite(song),
                child: Icon(isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: isFav ? Colors.redAccent : Colors.white30, size: 20),
              ),
              const SizedBox(width: 10),
              GestureDetector(
                onTap: () => _addToPlaylist(song),
                child: const Icon(Icons.playlist_add_rounded, color: Colors.white30, size: 22),
              ),
            ],
            if (isNow)
              Padding(
                padding: const EdgeInsets.only(left: 8),
                child: ScaleTransition(scale: _pulseAnim, child: Icon(Icons.equalizer_rounded, color: _green, size: 22)),
              ),
          ],
        ),
      ),
    );
  }

  Widget _albumPlaceholder() => Container(
    width: 48, height: 48,
    decoration: BoxDecoration(color: const Color(0xFF1E1E1E), borderRadius: BorderRadius.circular(10)),
    child: const Icon(Icons.music_note_rounded, color: Colors.white24, size: 22),
  );

  Widget _buildPlaylistTab() {
    if (_playlist.isEmpty) return _buildEmptyTab(Icons.queue_music_rounded, "Playlist kosong", "Tambahkan lagu dari hasil pencarian");
    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: _playlist.length,
      itemBuilder: (ctx, i) {
        final t = _playlist[i];
        return GestureDetector(
          onLongPress: () {
            setState(() { _playlist.removeAt(i); _saveData('music_playlist', _playlist); });
          },
          child: _buildSongTile(t, isLocal: true),
        );
      },
    );
  }

  Widget _buildFavoritesTab() {
    if (_favorites.isEmpty) return _buildEmptyTab(Icons.favorite_border_rounded, "Belum ada favorit", "Tap ikon hati saat mencari lagu");
    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: _favorites.length,
      itemBuilder: (ctx, i) => _buildSongTile(_favorites[i], isLocal: true),
    );
  }

  Widget _buildDownloadsTab() {
    return _buildEmptyTab(Icons.download_rounded, "Belum ada unduhan", "Fitur download segera hadir");
  }

  Widget _buildEmptyTab(IconData icon, String title, String subtitle) {
    return Center(
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: Colors.white12, size: 72),
        const SizedBox(height: 16),
        Text(title, style: const TextStyle(color: Colors.white70, fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text(subtitle, style: const TextStyle(color: Colors.white30, fontSize: 12)),
      ]),
    );
  }

  Widget _buildMiniPlayer() {
    final cover = _nowPlaying!['album']?['cover_medium'] ?? _nowPlaying!['cover'] ?? '';
    final title = _nowPlaying!['title'] ?? '';
    final artist = _nowPlaying!['artist']?['name'] ?? _nowPlaying!['artist'] ?? '';
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF1A3020), Color(0xFF0D1F14)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _green.withOpacity(0.3)),
        boxShadow: [BoxShadow(color: _green.withOpacity(0.15), blurRadius: 20, offset: const Offset(0, 5))],
      ),
      child: Row(
        children: [
          ScaleTransition(
            scale: _pulseAnim,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: cover.isNotEmpty
                  ? Image.network(cover, width: 46, height: 46, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _albumPlaceholder())
                  : _albumPlaceholder(),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
              Text(artist, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11)),
            ]),
          ),
          GestureDetector(
            onTap: () => setState(() => _isPlaying = !_isPlaying),
            child: Container(
              width: 40, height: 40,
              decoration: BoxDecoration(color: _green, borderRadius: BorderRadius.circular(12)),
              child: Icon(_isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.white, size: 22),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () => setState(() { _nowPlaying = null; _isPlaying = false; }),
            child: const Icon(Icons.close_rounded, color: Colors.white38, size: 20),
          ),
        ],
      ),
    );
  }
}
