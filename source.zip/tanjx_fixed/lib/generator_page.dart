import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class GeneratorPage extends StatefulWidget {
  final String sessionKey;
  final String initialType;
  const GeneratorPage({super.key, required this.sessionKey, this.initialType = 'Quote'});

  @override
  State<GeneratorPage> createState() => _GeneratorPageState();
}

class _GeneratorPageState extends State<GeneratorPage> {
  static const Color _bg = Color(0xFF060B14);
  static const Color _card = Color(0xFF0D1B2A);
  static const Color _purple = Color(0xFF9C27B0);
  static const Color _cyan = Color(0xFF00E5CC);
  static const Color _border = Color(0xFF1A2E3A);

  late String _selectedType;
  final _types = ['Quote', 'Fake Story', 'Fake Tweet', 'Caption', 'To Url'];

  @override
  void initState() {
    super.initState();
    _selectedType = widget.initialType;
  }
  final _topicController = TextEditingController();
  bool _isLoading = false;
  String? _result;

  final _exampleTopics = {'Quote': 'motivasi, cinta, kehidupan', 'Fake Story': 'artis ketahuan selingkuh, viral tiktok', 'Caption': 'foto pantai, selfie aesthetic'};

  Future<void> _generate() async {
    setState(() { _isLoading = true; _result = null; });
    await Future.delayed(const Duration(seconds: 1));
    final topic = _topicController.text.trim().isEmpty ? 'random' : _topicController.text.trim();
    final results = {
      'Quote': [
        '"Hidup bukan tentang siapa yang paling cepat, tapi siapa yang paling kuat bertahan." — Mantax',
        '"Jangan takut gagal, takutlah tidak pernah mencoba sama sekali." — Unknown',
        '"Kesuksesanmu adalah cerminan dari perjuanganmu yang tidak terlihat orang lain." — Mantax',
      ],
      'Fake Story': [
        '🔴 BREAKING: Selebgram $topic kedapatan melakukan hal mengejutkan di tempat umum! Netizen langsung bereaksi keras di kolom komentar. Pihak manajemen belum memberikan komentar resmi hingga berita ini diturunkan.',
        '🔥 VIRAL: Video $topic tersebar luas di media sosial! Dalam hitungan jam sudah ditonton jutaan kali. Banyak yang tidak menyangka hal ini bisa terjadi.',
      ],
      'Caption': [
        '✨ "$topic vibes today 🌊"\n—\nLifestyle | Travel | Aesthetic\n.\n.\n#aesthetic #vibes #explore #fyp',
        '🌅 "Kadang diam adalah jawaban terbaik untuk semua kebisingan."\n—\n#quotes #caption #mood #viral',
      ],
    };
    final list = results[_selectedType]!;
    setState(() { _result = list[DateTime.now().second % list.length]; _isLoading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white), onPressed: () => Navigator.pop(context)),
        title: const Text('GENERATOR', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 2)),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(color: _border, height: 1)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _purple.withAlpha(80))),
            child: Row(children: [
              Container(width: 48, height: 48, decoration: BoxDecoration(color: _purple.withAlpha(30), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.auto_fix_high_rounded, color: _purple, size: 24)),
              const SizedBox(width: 12),
              const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Generator', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                Text('Buat quote, fake story & caption', style: TextStyle(color: Colors.white54, fontSize: 12)),
              ]),
            ]),
          ),
          const SizedBox(height: 24),
          const Text('Tipe Konten', style: TextStyle(color: Colors.white70, fontSize: 13, letterSpacing: 1)),
          const SizedBox(height: 8),
          Wrap(spacing: 8, children: _types.map((t) {
            final sel = t == _selectedType;
            return GestureDetector(
              onTap: () => setState(() { _selectedType = t; _result = null; }),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(color: sel ? _purple : _card, borderRadius: BorderRadius.circular(30), border: Border.all(color: sel ? _purple : _border)),
                child: Text(t, style: TextStyle(color: sel ? Colors.white : Colors.white60, fontWeight: FontWeight.bold, fontSize: 12)),
              ),
            );
          }).toList()),
          const SizedBox(height: 20),
          Text('Topik (opsional)', style: const TextStyle(color: Colors.white70, fontSize: 13, letterSpacing: 1)),
          const SizedBox(height: 4),
          Text('Contoh: ${_exampleTopics[_selectedType]}', style: const TextStyle(color: Colors.white30, fontSize: 11)),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(12), border: Border.all(color: _border)),
            child: TextField(
              controller: _topicController,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                hintText: 'Ketik topik atau kosongkan untuk random...',
                hintStyle: TextStyle(color: Colors.white38),
                prefixIcon: Icon(Icons.lightbulb_rounded, color: Colors.white38),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              ),
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _isLoading ? null : _generate,
              style: ElevatedButton.styleFrom(backgroundColor: _purple, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              icon: _isLoading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.auto_awesome_rounded),
              label: Text(_isLoading ? 'Generating...' : 'GENERATE', style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2)),
            ),
          ),
          if (_result != null) ...[
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _cyan.withAlpha(80))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('Hasil $_selectedType', style: const TextStyle(color: Colors.white70, fontSize: 12, letterSpacing: 1)),
                  GestureDetector(
                    onTap: () { Clipboard.setData(ClipboardData(text: _result!)); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Disalin!'))); },
                    child: Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: _cyan.withAlpha(20), borderRadius: BorderRadius.circular(20), border: Border.all(color: _cyan.withAlpha(60))),
                      child: Row(children: [Icon(Icons.copy_rounded, color: _cyan, size: 13), const SizedBox(width: 4), Text('Copy', style: TextStyle(color: _cyan, fontSize: 11, fontWeight: FontWeight.bold))]),
                    ),
                  ),
                ]),
                const SizedBox(height: 12),
                Text(_result!, style: const TextStyle(color: Colors.white, fontSize: 14, height: 1.6)),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: TextButton.icon(
                    onPressed: _generate,
                    icon: const Icon(Icons.refresh_rounded, size: 16),
                    label: const Text('Generate Lagi'),
                    style: TextButton.styleFrom(foregroundColor: _purple),
                  ),
                ),
              ]),
            ),
          ],
        ]),
      ),
    );
  }
}
