import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:url_launcher/url_launcher.dart';

class ApkBuilderPage extends StatefulWidget {
  final String sessionKey;
  const ApkBuilderPage({super.key, required this.sessionKey});
  @override
  State<ApkBuilderPage> createState() => _ApkBuilderPageState();
}

class _ApkBuilderPageState extends State<ApkBuilderPage> {
  static const Color _bg    = Color(0xFF060B14);
  static const Color _card  = Color(0xFF0D1B2A);
  static const Color _cyan  = Color(0xFF00E5CC);
  static const Color _border = Color(0xFF1A2E3A);
  static const String _apiBase = 'http://olinncntk.twinofc.my.id:1202';

  final _appNameCtrl = TextEditingController(text: 'My App');
  final _packageCtrl = TextEditingController(text: 'com.tanix.app');
  final _urlCtrl     = TextEditingController(text: 'https://www.google.com');
  File? _iconFile;
  String? _iconName;
  String? _iconBase64;

  bool _building = false;
  bool _done = false;
  String? _downloadUrl;
  List<String> _logs = [];
  StreamSubscription? _logSub;
  final _scrollCtrl = ScrollController();

  @override
  void dispose() {
    _logSub?.cancel();
    _appNameCtrl.dispose();
    _packageCtrl.dispose();
    _urlCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickIcon() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (picked == null) return;
    final file = File(picked.path);
    final bytes = await file.readAsBytes();
    setState(() {
      _iconFile = file;
      _iconName = picked.name;
      _iconBase64 = base64Encode(bytes);
    });
  }

  void _addLog(String msg) {
    if (!mounted) return;
    setState(() => _logs.add(msg));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) _scrollCtrl.animateTo(
        _scrollCtrl.position.maxScrollExtent,
        duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
    });
  }

  Future<void> _buildApk() async {
    if (_building) return;
    final url = _urlCtrl.text.trim();
    final appName = _appNameCtrl.text.trim();
    final pkg = _packageCtrl.text.trim();
    if (url.isEmpty || appName.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Isi semua field!")));
      return;
    }
    setState(() { _building = true; _done = false; _downloadUrl = null; _logs = []; });

    _addLog("⏳ Menghubungkan ke server builder...");
    await Future.delayed(const Duration(milliseconds: 800));
    _addLog("📦 Mengupload konfigurasi...");

    try {
      final body = <String, dynamic>{
        'key': widget.sessionKey,
        'app_name': appName,
        'package': pkg,
        'url': url,
        if (_iconBase64 != null) 'icon_base64': _iconBase64,
        if (_iconName != null) 'icon_name': _iconName,
      };

      if (_iconBase64 != null) _addLog("🖼  Icon berhasil diupload");
      _addLog("🔨 Server sedang mengkompilasi APK...");

      final res = await http.post(
        Uri.parse('$_apiBase/api/builder/build'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      ).timeout(const Duration(seconds: 30));

      final data = jsonDecode(res.body);
      if (data['status'] == true || data['valid'] == true) {
        final buildId = data['build_id'] as String?;
        final isBuilding = data['building'] == true;
        
        if (isBuilding && buildId != null) {
          _addLog("⚙️  Server mengkompilasi... harap tunggu");
          // Poll for completion
          for (int i = 0; i < 30; i++) {
            await Future.delayed(const Duration(seconds: 6));
            if (!mounted) return;
            _addLog("⏳ Checking... (${(i+1)*6}s)");
            try {
              final poll = await http.get(Uri.parse('$_apiBase/api/builder/status/$buildId'))
                  .timeout(const Duration(seconds: 8));
              final pdata = jsonDecode(poll.body);
              if (pdata['done'] == true) {
                _addLog("✅ APK berhasil dikompilasi!");
                _addLog("🎉 Siap untuk didownload.");
                setState(() { _downloadUrl = pdata['download_url']; _done = true; });
                break;
              }
            } catch (_) {}
          }
          if (!_done) {
            _addLog("✅ Config APK tersimpan! Gunakan link download.");
            setState(() { _downloadUrl = data['download_url']; _done = true; });
          }
        } else {
          _addLog("✅ APK berhasil dibuat!");
          _addLog("🎉 Siap untuk didownload.");
          setState(() { _downloadUrl = data['download_url']; _done = true; });
        }
      } else {
        _addLog("❌ Gagal: ${data['message'] ?? 'Unknown error'}");
      }
    } catch (e) {
      _addLog("❌ Error: $e");
    }
    setState(() => _building = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _card,
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white), onPressed: () => Navigator.pop(context)),
        title: Row(children: [
          Container(width: 36, height: 36, decoration: BoxDecoration(color: const Color(0xFF00BCD4).withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
            child: const Icon(Icons.build_circle_rounded, color: Color(0xFF00BCD4), size: 20)),
          const SizedBox(width: 10),
          const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text("AUTO MODIFIKASI", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 1)),
            Text("Build APK dari URL", style: TextStyle(color: Colors.white38, fontSize: 10)),
          ]),
        ]),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(color: _border, height: 1)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // App Name
          _sectionCard(Icons.app_registration_rounded, "Nama Aplikasi",
            TextField(controller: _appNameCtrl, style: const TextStyle(color: Colors.white),
              decoration: _inputDeco("Contoh: My Cool App"))),
          const SizedBox(height: 12),
          // Package
          _sectionCard(Icons.inventory_2_rounded, "Package Name",
            TextField(controller: _packageCtrl, style: const TextStyle(color: Colors.white, fontFamily: 'monospace', fontSize: 13),
              decoration: _inputDeco("com.example.app"))),
          const SizedBox(height: 12),
          // URL
          _sectionCard(Icons.link_rounded, "URL WebView Target",
            Column(children: [
              TextField(controller: _urlCtrl, style: const TextStyle(color: Colors.white),
                decoration: _inputDeco("https://www.google.com", icon: Icons.public_rounded)),
              const SizedBox(height: 6),
              Row(children: [
                const Icon(Icons.lightbulb_rounded, color: Color(0xFF00E5CC), size: 13),
                const SizedBox(width: 4),
                const Text("URL ini akan dimuat saat APK dibuka oleh target", style: TextStyle(color: Colors.white30, fontSize: 11)),
              ]),
            ])),
          const SizedBox(height: 12),
          // Icon
          _sectionCard(Icons.image_rounded, "Ikon Aplikasi",
            Row(children: [
              if (_iconFile != null) ...[
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.file(_iconFile!, width: 70, height: 70, fit: BoxFit.cover),
                ),
                const SizedBox(width: 14),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Row(children: [
                    Icon(Icons.check_box_rounded, color: Colors.green, size: 16),
                    SizedBox(width: 4),
                    Text("icon dipilih", style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold)),
                  ]),
                  const SizedBox(height: 4),
                  Text(_iconName ?? '', style: const TextStyle(color: Colors.white38, fontSize: 11)),
                  const SizedBox(height: 6),
                  GestureDetector(
                    onTap: () => setState(() { _iconFile = null; _iconName = null; _iconBase64 = null; }),
                    child: const Text("Hapus icon", style: TextStyle(color: Colors.red, fontSize: 11)),
                  ),
                ]),
              ] else
                GestureDetector(
                  onTap: _pickIcon,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    decoration: BoxDecoration(color: _cyan.withOpacity(0.1), borderRadius: BorderRadius.circular(12), border: Border.all(color: _cyan.withOpacity(0.3))),
                    child: Row(children: [
                      Icon(Icons.add_photo_alternate_rounded, color: _cyan, size: 18),
                      const SizedBox(width: 8),
                      Text("Pilih Ikon", style: TextStyle(color: _cyan, fontWeight: FontWeight.bold)),
                    ]),
                  ),
                ),
            ])),
          const SizedBox(height: 16),
          // Build Log
          if (_logs.isNotEmpty) ...[
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(14), border: Border.all(color: _border)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Container(width: 8, height: 8, decoration: BoxDecoration(
                    color: _building ? Colors.orange : (_done ? Colors.green : Colors.white24), shape: BoxShape.circle)),
                  const SizedBox(width: 8),
                  const Text("Build Log", style: TextStyle(color: Colors.white60, fontSize: 12, fontFamily: 'monospace')),
                ]),
                const SizedBox(height: 10),
                SizedBox(
                  height: 140,
                  child: ListView.builder(
                    controller: _scrollCtrl,
                    itemCount: _logs.length,
                    itemBuilder: (_, i) => Text(_logs[i], style: const TextStyle(color: Colors.white70, fontSize: 12, fontFamily: 'monospace', height: 1.8)),
                  ),
                ),
              ]),
            ),
            const SizedBox(height: 12),
          ],
          // Download button
          if (_done && _downloadUrl != null) ...[
            GestureDetector(
              onTap: () async {
                final uri = Uri.parse(_downloadUrl!);
                if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
              },
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.green.withOpacity(0.4)),
                ),
                child: Row(children: [
                  Container(width: 40, height: 40, decoration: BoxDecoration(color: Colors.green.withOpacity(0.2), shape: BoxShape.circle),
                    child: const Icon(Icons.download_rounded, color: Colors.green, size: 22)),
                  const SizedBox(width: 12),
                  const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text("APK Siap Didownload!", style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 14)),
                    Text("Tap untuk membuka link download", style: TextStyle(color: Colors.white38, fontSize: 11)),
                  ])),
                  const Icon(Icons.arrow_forward_ios_rounded, color: Colors.green, size: 14),
                ]),
              ),
            ),
            const SizedBox(height: 12),
          ],
          // Build button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _building ? null : _buildApk,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                backgroundColor: Colors.transparent,
                foregroundColor: Colors.white,
                shadowColor: Colors.transparent,
              ).copyWith(
                backgroundColor: WidgetStateProperty.resolveWith((s) => Colors.transparent),
              ),
              icon: _building
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Icon(Icons.rocket_launch_rounded, size: 20),
              label: Text(_building ? "BUILDING..." : "BUILD APK SEKARANG",
                style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2, fontSize: 14)),
            ),
          ),
          // Gradient build button overlay
          if (!_building) Container(
            margin: const EdgeInsets.only(bottom: 0),
            height: 52,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF00E5CC), Color(0xFF9C27B0)]),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: _building ? null : _buildApk,
                child: const Center(child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 20),
                  SizedBox(width: 10),
                  Text("BUILD APK SEKARANG", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 2, fontSize: 14)),
                ])),
              ),
            ),
          ),
          const SizedBox(height: 24),
        ]),
      ),
    );
  }

  Widget _sectionCard(IconData icon, String title, Widget child) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(14), border: Border.all(color: _border)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 32, height: 32, decoration: BoxDecoration(color: _cyan.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
            child: Icon(icon, color: _cyan, size: 16)),
          const SizedBox(width: 10),
          Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
        ]),
        const SizedBox(height: 12),
        child,
      ]),
    );
  }

  InputDecoration _inputDeco(String hint, {IconData? icon}) => InputDecoration(
    hintText: hint,
    hintStyle: const TextStyle(color: Colors.white24),
    prefixIcon: icon != null ? Icon(icon, color: Colors.white24, size: 18) : null,
    filled: true,
    fillColor: const Color(0xFF0A1520),
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFF1A2E3A))),
    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFF1A2E3A))),
    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFF00E5CC))),
    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
  );
}
