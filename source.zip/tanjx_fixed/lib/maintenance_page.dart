import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// ─────────────────────────────────────────
//  Maintenance Page
// ─────────────────────────────────────────
class MaintenancePage extends StatefulWidget {
  final String message;
  final String estimatedTime;
  final VoidCallback onRetry;

  const MaintenancePage({
    super.key,
    required this.message,
    required this.estimatedTime,
    required this.onRetry,
  });

  @override
  State<MaintenancePage> createState() => _MaintenancePageState();
}

class _MaintenancePageState extends State<MaintenancePage>
    with TickerProviderStateMixin {
  static const Color _teal = Color(0xFF00E5CC);
  static const Color _bg = Color(0xFF0A0E1A);

  late AnimationController _pulseCtrl;
  late AnimationController _fadeCtrl;
  late Animation<double> _pulseAnim;
  late Animation<double> _fadeAnim;

  Timer? _retryTimer;
  int _countdown = 30;
  bool _isRetrying = false;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _pulseAnim = Tween<double>(begin: 0.9, end: 1.1).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);

    _startRetryCountdown();
  }

  void _startRetryCountdown() {
    _countdown = 30;
    _retryTimer?.cancel();
    _retryTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) { t.cancel(); return; }
      setState(() => _countdown--);
      if (_countdown <= 0) {
        t.cancel();
        _doRetry();
      }
    });
  }

  Future<void> _doRetry() async {
    if (_isRetrying) return;
    setState(() { _isRetrying = true; });
    await Future.delayed(const Duration(milliseconds: 500));
    widget.onRetry();
    if (mounted) {
      setState(() { _isRetrying = false; });
      _startRetryCountdown();
    }
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _fadeCtrl.dispose();
    _retryTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: Stack(
        children: [
          // ─── BACKGROUND GLOW ───
          Positioned(top: -100, left: -100,
            child: Container(width: 350, height: 350,
              decoration: BoxDecoration(shape: BoxShape.circle,
                gradient: RadialGradient(colors: [
                  Colors.orange.withOpacity(0.06), Colors.transparent])))),
          Positioned(bottom: -100, right: -100,
            child: Container(width: 350, height: 350,
              decoration: BoxDecoration(shape: BoxShape.circle,
                gradient: RadialGradient(colors: [
                  _teal.withOpacity(0.05), Colors.transparent])))),

          // ─── CONTENT ───
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 28),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // ─── ANIMATED ICON ───
                      ScaleTransition(
                        scale: _pulseAnim,
                        child: Container(
                          width: 120, height: 120,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.orange.withOpacity(0.1),
                            border: Border.all(
                              color: Colors.orange.withOpacity(0.4), width: 2),
                            boxShadow: [BoxShadow(
                              color: Colors.orange.withOpacity(0.2),
                              blurRadius: 30, spreadRadius: 5)],
                          ),
                          child: const Icon(Icons.construction_rounded,
                            color: Colors.orange, size: 56),
                        ),
                      ),
                      const SizedBox(height: 32),

                      // ─── TITLE ───
                      ShaderMask(
                        shaderCallback: (bounds) => const LinearGradient(
                          colors: [Colors.orange, Color(0xFFFFCC02)],
                        ).createShader(bounds),
                        child: const Text('MAINTENANCE',
                          style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.bold,
                            fontSize: 28,
                            letterSpacing: 3,
                          )),
                      ),
                      const SizedBox(height: 8),
                      Text('TANIX SEDANG DALAM PERBAIKAN',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.4),
                          fontFamily: 'ShareTechMono',
                          fontSize: 12, letterSpacing: 2)),
                      const SizedBox(height: 32),

                      // ─── MESSAGE CARD ───
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.orange.withOpacity(0.06),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: Colors.orange.withOpacity(0.25)),
                        ),
                        child: Column(children: [
                          Row(children: [
                            Icon(Icons.info_outline_rounded,
                              color: Colors.orange, size: 18),
                            const SizedBox(width: 8),
                            const Text('PESAN DARI ADMIN',
                              style: TextStyle(
                                color: Colors.orange,
                                fontFamily: 'Orbitron',
                                fontSize: 11, fontWeight: FontWeight.bold,
                                letterSpacing: 1)),
                          ]),
                          const SizedBox(height: 12),
                          Text(
                            widget.message.isNotEmpty
                              ? widget.message
                              : 'Sistem sedang dalam perbaikan.\nMohon tunggu sebentar.',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.7),
                              fontSize: 14, height: 1.6),
                            textAlign: TextAlign.center),
                          if (widget.estimatedTime.isNotEmpty) ...[
                            const SizedBox(height: 16),
                            Divider(color: Colors.white.withOpacity(0.08)),
                            const SizedBox(height: 12),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.timer_outlined,
                                  color: _teal, size: 16),
                                const SizedBox(width: 8),
                                Text('Estimasi selesai: ',
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.4),
                                    fontSize: 13)),
                                Text(widget.estimatedTime,
                                  style: const TextStyle(
                                    color: _teal,
                                    fontFamily: 'ShareTechMono',
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13)),
                              ],
                            ),
                          ],
                        ]),
                      ),
                      const SizedBox(height: 28),

                      // ─── AUTO RETRY COUNTDOWN ───
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 14),
                        decoration: BoxDecoration(
                          color: _teal.withOpacity(0.06),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: _teal.withOpacity(0.2)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 20, height: 20,
                              child: CircularProgressIndicator(
                                value: _countdown / 30,
                                strokeWidth: 2,
                                color: _teal,
                                backgroundColor: _teal.withOpacity(0.2),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Text('Auto retry dalam $_countdown detik',
                              style: TextStyle(
                                color: _teal,
                                fontFamily: 'ShareTechMono',
                                fontSize: 13)),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // ─── MANUAL RETRY BUTTON ───
                      GestureDetector(
                        onTap: _isRetrying ? null : _doRetry,
                        child: Container(
                          width: double.infinity, height: 52,
                          decoration: BoxDecoration(
                            color: _isRetrying
                              ? Colors.white.withOpacity(0.05)
                              : Colors.white.withOpacity(0.08),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.15)),
                          ),
                          child: Center(child: _isRetrying
                            ? const SizedBox(width: 20, height: 20,
                                child: CircularProgressIndicator(
                                  color: Colors.white54, strokeWidth: 2))
                            : Row(mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.refresh_rounded,
                                    color: Colors.white54, size: 18),
                                  const SizedBox(width: 8),
                                  Text('Coba Sekarang',
                                    style: TextStyle(
                                      color: Colors.white54,
                                      fontFamily: 'ShareTechMono')),
                                ])),
                        ),
                      ),
                      const SizedBox(height: 40),

                      // ─── FOOTER ───
                      Text('TANIX V3.0 | © 2026',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.2),
                          fontSize: 11, fontFamily: 'ShareTechMono',
                          letterSpacing: 2)),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────
//  Maintenance Checker - cek status sebelum masuk app
// ─────────────────────────────────────────
class MaintenanceChecker {
  static const String baseUrl = "http://olinncntk.twinofc.my.id:1202";

  static Future<Map<String, dynamic>> check() async {
    try {
      final res = await http.get(
        Uri.parse("$baseUrl/maintenance"),
      ).timeout(const Duration(seconds: 8));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        return {
          'isMaintenance': data['maintenance'] == true,
          'message': data['message'] ?? '',
          'estimatedTime': data['estimatedTime'] ?? '',
        };
      }
    } catch (_) {}
    // Jika tidak bisa connect ke server, biarkan masuk
    return {'isMaintenance': false, 'message': '', 'estimatedTime': ''};
  }
}
