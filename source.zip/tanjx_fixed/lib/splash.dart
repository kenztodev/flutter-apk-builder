import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

import 'loader_page.dart';

class SplashPage extends StatefulWidget {
  final Map<String, dynamic> data;
  const SplashPage({super.key, required this.data});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage>
    with SingleTickerProviderStateMixin {
  late VideoPlayerController _controller;
  bool _isInitialized = false;

  // ─── FITUR BARU: Loading Progress Animation ───
  late AnimationController _progressController;
  late Animation<double> _progressAnimation;
  double _loadingProgress = 0.0;
  String _loadingText = "Initializing...";

  final List<String> _loadingTexts = [
    "Connecting to TANIX...",
    "Loading modules...",
    "Fetching data...",
    "Almost ready...",
    "Welcome to TANIX!",
  ];

  @override
  void initState() {
    super.initState();

    _progressController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    );
    _progressAnimation =
        Tween<double>(begin: 0, end: 1).animate(_progressController);
    _progressController.addListener(() {
      if (mounted) {
        setState(() {
          _loadingProgress = _progressAnimation.value;
          int idx = (_loadingProgress * (_loadingTexts.length - 1)).toInt();
          _loadingText = _loadingTexts[idx.clamp(0, _loadingTexts.length - 1)];
        });
      }
    });
    _progressController.forward();

    _initializeVideo();
  }

  void _initializeVideo() {
    _controller = VideoPlayerController.asset('assets/videos/load.mp4')
      ..initialize().then((_) {
        SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersive);
        setState(() => _isInitialized = true);
        _controller.play();
        _controller.setVolume(1.0);
      });

    _controller.addListener(() {
      if (_controller.value.isInitialized &&
          _controller.value.position >= _controller.value.duration) {
        _navigateToDashboard();
      }
    });
  }

  void _navigateToDashboard() {
    _controller.pause();
    _progressController.stop();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) => DashboardPage(
            username: widget.data['username'] ?? '',
            password: widget.data['password'] ?? '',
            role: widget.data['role'] ?? 'user',
            expiredDate: widget.data['expiredDate'] ?? '-',
            sessionKey: widget.data['key'] ?? '',
            listBug: List<Map<String, dynamic>>.from(
                widget.data['listBug'] ?? []),
            listPayload: List<Map<String, dynamic>>.from(
                widget.data['listPayload'] ?? []),
            listDDoS: List<Map<String, dynamic>>.from(
                widget.data['listDDoS'] ?? []),
            news: List<Map<String, dynamic>>.from(
                widget.data['news'] ?? []),
          ),
        ),
      );
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _progressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ─── VIDEO LAYER ───
          if (_isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _controller.value.size.width,
                  height: _controller.value.size.height,
                  child: VideoPlayer(_controller),
                ),
              ),
            )
          else
            Container(
              color: const Color(0xFF0A0E1A),
              child: const Center(
                child: CircularProgressIndicator(
                    color: Color(0xFF00E5CC), strokeWidth: 2),
              ),
            ),

          // ─── DARK OVERLAY ───
          Container(color: Colors.black.withOpacity(0.4)),

          // ─── BRAND TEXT ───
          Positioned(
            bottom: 100,
            left: 0,
            right: 0,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "TANIX",
                  style: TextStyle(
                    fontFamily: 'Orbitron',
                    fontSize: 42,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: 4.0,
                    shadows: [
                      Shadow(
                        blurRadius: 20.0,
                        color: const Color(0xFF00E5CC).withOpacity(0.8),
                        offset: const Offset(0, 0),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  "TANIX EDITION V3.0",
                  style: TextStyle(
                    fontFamily: 'ShareTechMono',
                    fontSize: 12,
                    color: const Color(0xFF00E5CC).withOpacity(0.8),
                    letterSpacing: 5.0,
                  ),
                ),
              ],
            ),
          ),

          // ─── FITUR BARU: Loading Progress Bar ───
          Positioned(
            bottom: 50,
            left: 40,
            right: 40,
            child: Column(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: _loadingProgress,
                    backgroundColor: Colors.white.withOpacity(0.1),
                    valueColor: const AlwaysStoppedAnimation<Color>(
                        Color(0xFF00E5CC)),
                    minHeight: 3,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  _loadingText,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.5),
                    fontSize: 11,
                    fontFamily: 'ShareTechMono',
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),

          // ─── SKIP BUTTON ───
          Positioned(
            top: 50,
            right: 25,
            child: GestureDetector(
              onTap: _navigateToDashboard,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(30),
                  border:
                      Border.all(color: Colors.white.withOpacity(0.3)),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      "SKIP",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                        letterSpacing: 1.5,
                      ),
                    ),
                    SizedBox(width: 5),
                    Icon(Icons.arrow_forward_ios_rounded,
                        color: Colors.white, size: 12),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
