import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class PublicChatPage extends StatefulWidget {
  final String username;
  const PublicChatPage({super.key, required this.username});
  @override
  State<PublicChatPage> createState() => _PublicChatPageState();
}

class _PublicChatPageState extends State<PublicChatPage> {
  static const Color _bg    = Color(0xFF090E1A);
  static const Color _card  = Color(0xFF111827);
  static const Color _blue  = Color(0xFF2196F3);

  final String _baseUrl = "http://olinncntk.twinofc.my.id:1202";
  final _msgCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  List<dynamic> _messages = [];
  Timer? _refreshTimer;
  bool _isSending = false;

  @override
  void initState() {
    super.initState();
    _fetchMessages();
    _refreshTimer = Timer.periodic(const Duration(seconds: 2), (_) => _fetchMessages());
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  Future<void> _fetchMessages() async {
    try {
      final res = await http.post(
        Uri.parse("$_baseUrl/api/public/get-public-chat"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"room": "public"}),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final msgs = data['messages'] ?? data['chats'] ?? [];
        if (mounted) setState(() => _messages = msgs);
        _scrollToBottom();
      }
    } catch (_) {}
  }

  Future<void> _sendMessage() async {
    final msg = _msgCtrl.text.trim();
    if (msg.isEmpty || _isSending) return;
    setState(() => _isSending = true);
    _msgCtrl.clear();
    try {
      await http.post(
        Uri.parse("$_baseUrl/api/public/send-public-chat"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "username": widget.username,
          "message": msg,
          "room": "public",
        }),
      );
      await _fetchMessages();
    } catch (_) {}
    if (mounted) setState(() => _isSending = false);
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  String _formatTime(String? dateStr) {
    if (dateStr == null) return '';
    try {
      final dt = DateTime.parse(dateStr).toLocal();
      final h = dt.hour.toString().padLeft(2, "0");
      final m = dt.minute.toString().padLeft(2, "0");
      final period = dt.hour < 12 ? 'AM' : 'PM';
      final hour12 = dt.hour % 12 == 0 ? 12 : dt.hour % 12;
      return '$hour12:$m $period';
    } catch (_) { return ''; }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      resizeToAvoidBottomInset: true,
      body: Column(children: [
        // ─── APP BAR ───
        Container(
          padding: EdgeInsets.only(
            top: MediaQuery.of(context).padding.top + 10,
            left: 16, right: 16, bottom: 12),
          decoration: BoxDecoration(
            color: const Color(0xFF0D1525),
            border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.06)))),
          child: Row(children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.arrow_back_ios_rounded,
                  color: Colors.white70, size: 16))),
            const SizedBox(width: 12),
            Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                color: _blue.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _blue.withOpacity(0.3))),
              child: const Icon(Icons.forum_rounded, color: _blue, size: 22)),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Room Nongkrong', style: TextStyle(
                color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
              Text('Halo, ${widget.username}!',
                style: const TextStyle(color: _blue, fontSize: 12,
                  fontFamily: 'ShareTechMono')),
            ])),
            IconButton(
              icon: const Icon(Icons.info_outline_rounded, color: Colors.white38),
              onPressed: () {}),
          ]),
        ),

        // ─── MESSAGES ───
        Expanded(
          child: _messages.isEmpty
            ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.chat_bubble_outline_rounded, color: Colors.white12, size: 60),
                SizedBox(height: 12),
                Text('Belum ada pesan', style: TextStyle(
                  color: Colors.white24, fontFamily: 'ShareTechMono')),
              ]))
            : ListView.builder(
                controller: _scrollCtrl,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                itemCount: _messages.length,
                itemBuilder: (ctx, i) {
                  final msg = _messages[i];
                  final isMe = msg['username'] == widget.username;
                  final username = msg['username'] ?? 'Unknown';
                  final text = msg['message'] ?? '';
                  final time = _formatTime(msg['createdAt'] ?? msg['time']);
                  final initial = username.isNotEmpty
                    ? username[0].toUpperCase() : '?';

                  if (isMe) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Container(
                            constraints: BoxConstraints(
                              maxWidth: MediaQuery.of(context).size.width * 0.7),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 12),
                            decoration: BoxDecoration(
                              color: _blue,
                              borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(18),
                                topRight: Radius.circular(18),
                                bottomLeft: Radius.circular(18),
                                bottomRight: Radius.circular(4)),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(text, style: const TextStyle(
                                  color: Colors.white, fontSize: 14, height: 1.4)),
                                const SizedBox(height: 4),
                                Row(mainAxisSize: MainAxisSize.min, children: [
                                  Icon(Icons.reply_rounded, color: Colors.white54, size: 13),
                                  const SizedBox(width: 4),
                                  Text(time, style: const TextStyle(
                                    color: Colors.white54, fontSize: 11,
                                    fontFamily: 'ShareTechMono')),
                                ]),
                              ]),
                          ),
                        ],
                      ),
                    );
                  }

                  return Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 36, height: 36,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(10)),
                          child: Center(child: Text(initial,
                            style: const TextStyle(color: Colors.white,
                              fontWeight: FontWeight.bold))),
                        ),
                        const SizedBox(width: 10),
                        Expanded(child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(username, style: TextStyle(
                              color: Colors.white.withOpacity(0.5),
                              fontSize: 12, fontFamily: 'ShareTechMono')),
                            const SizedBox(height: 4),
                            Container(
                              constraints: BoxConstraints(
                                maxWidth: MediaQuery.of(context).size.width * 0.7),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 10),
                              decoration: BoxDecoration(
                                color: const Color(0xFF1A2030),
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(4),
                                  topRight: Radius.circular(18),
                                  bottomLeft: Radius.circular(18),
                                  bottomRight: Radius.circular(18)),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(text, style: const TextStyle(
                                    color: Colors.white, fontSize: 14, height: 1.4)),
                                  const SizedBox(height: 4),
                                  Row(children: [
                                    const Icon(Icons.reply_rounded,
                                      color: Colors.white30, size: 13),
                                    const SizedBox(width: 4),
                                    Text(time, style: const TextStyle(
                                      color: Colors.white30, fontSize: 11,
                                      fontFamily: 'ShareTechMono')),
                                  ]),
                                ]),
                            ),
                          ]),
                        ),
                      ],
                    ),
                  );
                },
              ),
        ),

        // ─── INPUT BAR ───
        Container(
          padding: EdgeInsets.only(
            left: 12, right: 12, top: 10,
            bottom: MediaQuery.of(context).viewInsets.bottom > 0
              ? MediaQuery.of(context).viewInsets.bottom + 10 : 16),
          decoration: BoxDecoration(
            color: const Color(0xFF0D1525),
            border: Border(top: BorderSide(color: Colors.white.withOpacity(0.06)))),
          child: Row(children: [
            // Emoji
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                shape: BoxShape.circle),
              child: const Icon(Icons.emoji_emotions_outlined,
                color: Colors.white38, size: 18)),
            const SizedBox(width: 8),
            // Image
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                shape: BoxShape.circle),
              child: const Icon(Icons.image_outlined,
                color: Colors.white38, size: 18)),
            const SizedBox(width: 8),
            // Input
            Expanded(child: Container(
              height: 40,
              decoration: BoxDecoration(
                color: const Color(0xFF1A2030),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white.withOpacity(0.08))),
              child: TextField(
                controller: _msgCtrl,
                style: const TextStyle(color: Colors.white, fontSize: 14),
                cursorColor: _blue,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _sendMessage(),
                decoration: const InputDecoration(
                  hintText: 'Kirim Pesan....',
                  hintStyle: TextStyle(color: Colors.white24, fontSize: 14),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 10)),
              ))),
            const SizedBox(width: 8),
            // Send Button
            GestureDetector(
              onTap: _isSending ? null : _sendMessage,
              child: Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  color: _blue,
                  shape: BoxShape.circle,
                  boxShadow: [BoxShadow(
                    color: _blue.withOpacity(0.4), blurRadius: 8)]),
                child: const Icon(Icons.mic_rounded, color: Colors.white, size: 18)),
            ),
          ]),
        ),
      ]),
    );
  }
}
