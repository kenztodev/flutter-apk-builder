import 'package:flutter/material.dart';
import 'home_page.dart';
import 'custom_bug.dart';
import 'bug_group.dart';
import 'spams_page.dart';

class BugMenuPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final String role;
  final String expiredDate;

  const BugMenuPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.listPayload,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<BugMenuPage> createState() => _BugMenuPageState();
}

class _BugMenuPageState extends State<BugMenuPage>
    with SingleTickerProviderStateMixin {
  static const Color _teal = Color(0xFF00E5CC);
  static const Color _bg   = Color(0xFF0A0E1A);
  static const Color _card = Color(0xFF0D1525);

  int _selectedIndex = 0;
  late PageController _pageCtrl;
  late AnimationController _animCtrl;
  late Animation<double> _fadeAnim;

  final List<Map<String, dynamic>> _menus = [
    {
      'title': 'TANIX BUG',
      'subtitle': 'Bug tanpa custom',
      'desc': 'Gunakan langsung tanpa custom delay dan loops',
      'badge': 'RECOMMENDED',
      'badgeColor': const Color(0xFF00E5CC),
      'icon': Icons.bug_report_rounded,
      'features': ['Mudah digunakan', 'Function terbaru'],
      'gradient': [Color(0xFF0D2137), Color(0xFF0A3D2E)],
      'route': 'bug',
    },
    {
      'title': 'CUSTOM BUG',
      'subtitle': 'Menu custom bug',
      'desc': 'Buat menu bug, delay pengiriman dan loops',
      'badge': 'CUSTOM',
      'badgeColor': Color(0xFF00E5CC),
      'icon': Icons.settings_rounded,
      'features': ['Pengaturan Mudah', 'Support Multi Bug'],
      'gradient': [Color(0xFF0D1F37), Color(0xFF0A2A3D)],
      'route': 'custom_bug',
    },
    {
      'title': 'SPAM PAIR',
      'subtitle': 'Menu Spam Pairing',
      'desc': 'Pairing Whatsapp dan OTP Telegram',
      'badge': 'SPAM',
      'badgeColor': Color(0xFF00E5CC),
      'icon': Icons.email_rounded,
      'features': ['Mudah Digunakan', 'Anti Gimmick'],
      'gradient': [Color(0xFF0D1F37), Color(0xFF0A2A3D)],
      'route': 'report_wa',
    },
    {
      'title': 'GROUP BUG',
      'subtitle': 'Bug ke grup WA',
      'desc': 'Kirim bug ke grup WhatsApp target',
      'badge': 'GROUP',
      'badgeColor': Color(0xFFFF6B35),
      'icon': Icons.group_rounded,
      'features': ['Multi Target', 'Group Support'],
      'gradient': [Color(0xFF1F0D37), Color(0xFF2A0A3D)],
      'route': 'group_bug',
    },
  ];

  @override
  void initState() {
    super.initState();
    _pageCtrl = PageController(viewportFraction: 0.85);
    _animCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 500));
    _fadeAnim = CurvedAnimation(parent: _animCtrl, curve: Curves.easeOut);
    _animCtrl.forward();
  }

  @override
  void dispose() {
    _pageCtrl.dispose();
    _animCtrl.dispose();
    super.dispose();
  }

  void _navigateTo(String route) {
    if (!mounted) return;
    Widget? page;

    switch (route) {
      case 'bug':
        page = AttackPage(
          username: widget.username,
          password: widget.password,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          role: widget.role,
          expiredDate: widget.expiredDate,
        );
        break;
      case 'custom_bug':
        page = CustomAttackPage(
          username: widget.username,
          password: widget.password,
          sessionKey: widget.sessionKey,
          listPayload: widget.listPayload,
          role: widget.role,
          expiredDate: widget.expiredDate,
        );
        break;
      case 'group_bug':
        page = GroupBugPage(
          username: widget.username,
          password: widget.password,
          sessionKey: widget.sessionKey,
          role: widget.role,
          expiredDate: widget.expiredDate,
        );
        break;
      case 'report_wa':
        page = ReportWaPage(
          sessionKey: widget.sessionKey,
          username: widget.username,
          role: widget.role,
        );
        break;
    }

    if (page != null) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => page!));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: FadeTransition(
        opacity: _fadeAnim,
        child: Column(
          children: [
            // ─── HEADER ───
            _buildHeader(),

            // ─── PAGE VIEW CARDS ───
            Expanded(
              child: Column(
                children: [
                  const SizedBox(height: 16),
                  Expanded(
                    child: PageView.builder(
                      controller: _pageCtrl,
                      itemCount: _menus.length,
                      onPageChanged: (i) => setState(() => _selectedIndex = i),
                      itemBuilder: (ctx, i) => _buildMenuCard(_menus[i], i),
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Dots indicator
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(_menus.length, (i) => AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      width: _selectedIndex == i ? 24 : 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: _selectedIndex == i ? _teal : Colors.white24,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    )),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 12,
        left: 20, right: 20, bottom: 16,
      ),
      decoration: BoxDecoration(
        color: const Color(0xFF080E1C),
        border: Border(
          bottom: BorderSide(color: _teal.withOpacity(0.3), width: 1),
        ),
      ),
      child: Row(
        children: [
          // Logo
          Container(
            width: 52, height: 52,
            decoration: BoxDecoration(
              color: const Color(0xFF111827),
              shape: BoxShape.circle,
              border: Border.all(color: _teal.withOpacity(0.3)),
            ),
            child: ClipOval(
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Image.asset('assets/images/logo.png', fit: BoxFit.contain),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('BUG MENU', style: TextStyle(
                color: Colors.white,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                fontSize: 20,
                letterSpacing: 1,
              )),
              const SizedBox(height: 6),
              Row(children: [
                _headerBadge('ONLINE v2.0', Colors.green),
                const SizedBox(width: 8),
                _headerBadge('Elegant Edition', _teal),
              ]),
              const SizedBox(height: 4),
              const Text('Pilih menu yang tersedia bosque!',
                style: TextStyle(color: Colors.white38, fontSize: 12,
                  fontFamily: 'ShareTechMono')),
            ],
          )),
        ],
      ),
    );
  }

  Widget _headerBadge(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.5)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 6, height: 6,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
        const SizedBox(width: 5),
        Text(label, style: TextStyle(color: color, fontSize: 11,
          fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)),
      ]),
    );
  }

  Widget _buildMenuCard(Map<String, dynamic> menu, int index) {
    final isActive = _selectedIndex == index;
    final gradients = menu['gradient'] as List<Color>;

    return AnimatedScale(
      scale: isActive ? 1.0 : 0.92,
      duration: const Duration(milliseconds: 300),
      child: GestureDetector(
        onTap: () {
          setState(() => _selectedIndex = index);
          // Navigate setelah select
          Future.delayed(const Duration(milliseconds: 200), () {
            _navigateTo(menu['route'] as String);
          });
        },
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: gradients,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: isActive ? _teal.withOpacity(0.5) : Colors.white.withOpacity(0.08),
              width: isActive ? 1.5 : 1,
            ),
            boxShadow: isActive ? [
              BoxShadow(color: _teal.withOpacity(0.2), blurRadius: 20, spreadRadius: 2)
            ] : [],
          ),
          child: Stack(
            children: [
              // Background pattern
              Positioned(
                right: -20, bottom: -20,
                child: Container(
                  width: 150, height: 150,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _teal.withOpacity(0.03),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Top row: icon + badge
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          width: 56, height: 56,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.08),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Icon(menu['icon'] as IconData,
                            color: Colors.white70, size: 28),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 7),
                          decoration: BoxDecoration(
                            color: Colors.transparent,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: (menu['badgeColor'] as Color).withOpacity(0.7)),
                          ),
                          child: Text(menu['badge'] as String,
                            style: TextStyle(
                              color: menu['badgeColor'] as Color,
                              fontSize: 11,
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                            )),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),

                    // Title
                    Text(menu['title'] as String, style: const TextStyle(
                      color: Colors.white,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      fontSize: 22,
                      letterSpacing: 1,
                    )),
                    const SizedBox(height: 4),
                    Text(menu['subtitle'] as String, style: TextStyle(
                      color: Colors.white.withOpacity(0.5),
                      fontSize: 13,
                    )),
                    const SizedBox(height: 12),
                    Divider(color: Colors.white.withOpacity(0.1)),
                    const SizedBox(height: 12),

                    // Description
                    Text(menu['desc'] as String, style: TextStyle(
                      color: Colors.white.withOpacity(0.6),
                      fontSize: 13, height: 1.5,
                    )),
                    const SizedBox(height: 16),

                    // Feature chips
                    Wrap(spacing: 8, runSpacing: 8,
                      children: (menu['features'] as List<String>).map((f) =>
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.07),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.15)),
                          ),
                          child: Row(mainAxisSize: MainAxisSize.min, children: [
                            Icon(Icons.star_rounded,
                              color: _teal, size: 13),
                            const SizedBox(width: 5),
                            Text(f, style: TextStyle(
                              color: Colors.white.withOpacity(0.8),
                              fontSize: 12,
                              fontFamily: 'ShareTechMono',
                            )),
                          ]),
                        ),
                      ).toList(),
                    ),

                    const Spacer(),

                    // Tap button
                    Align(
                      alignment: Alignment.centerRight,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: _teal.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: _teal.withOpacity(0.4)),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Text('Tap', style: TextStyle(
                            color: _teal, fontSize: 12,
                            fontFamily: 'ShareTechMono')),
                          const SizedBox(width: 4),
                          Icon(Icons.arrow_forward_rounded,
                            color: _teal, size: 14),
                        ]),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
