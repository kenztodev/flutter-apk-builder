// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'dart:ui';
import 'dart:math' as math;

import 'telegram.dart';
import 'admin_page.dart';
import 'spam_ngl.dart';
import 'wifi_external.dart';
import 'tabungan_page.dart';
import 'tes_func_page.dart';
import 'alquran_page.dart';
import 'chat_user_page.dart';
import 'theme_manager.dart';
import 'buy_account.dart';
import 'wifi_internal.dart';
import 'nik_parse.dart';
import 'spams_page.dart';
import 'home_page.dart';
import 'bug_menu_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'ddos_page.dart';
import 'chat_page.dart';
import 'login_page.dart';
import 'custom_bug.dart';
import 'bug_group.dart';
import 'ddos_panel.dart';
import 'sender_page.dart';
import 'public_page.dart';
import 'music_page.dart';
import 'device_dashboard.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final List<Map<String, dynamic>> listDDoS;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
    required this.listDDoS,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  late WebSocketChannel channel;

  VideoPlayerController? _videoController;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listPayload;
  late List<Map<String, dynamic>> listDDoS;
  late List<dynamic> newsList;
  String androidId = "unknown";

  int _selectedNavIndex = 0;
  Widget _selectedPage = const SizedBox();

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final PageController _newsPageController = PageController(viewportFraction: 0.88);
  int _currentNewsIndex = 0;

  List<Map<String, dynamic>> _activityLogs = [];
  bool _isLoadingActivityLogs = false;
  bool _hasActivityLogsError = false;

  String _activePage = 'home';

  // ─── QUICK ACTIONS STATE ───
  bool _quickActionsEnabled = true;
  int _tabunganKuBalance = 0;

  // ─── FITUR BARU: Stats ───
  int _totalSent = 0;

  // ─── PRAYER TIME STATE ───
  Map<String, String> _prayerTimes = {
    'SUBUH': '--:--', 'DZUHUR': '--:--',
    'ASHAR': '--:--', 'MAGHRIB': '--:--', 'ISYA': '--:--',
  };
  String _nextPrayerName = '';
  String _countdownStr = '--:--:--';
  int _activePrayerIndex = 0;
  String _selectedCity = 'Jakarta';
  Timer? _prayerTimer;
  Timer? _countdownTimer;
  bool _showSearchBar = false;
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();

  // ─── WARNA TEMA (Teal/Cyan ala TANIX) ───
  static const Color _teal = Color(0xFF00BCD4);
  static const Color _tealDark = Color(0xFF007B8A);
  static const Color _bgDark = Color(0xFF0A0E1A);
  static const Color _bgCard = Color(0xFF111827);
  static const Color _bgCard2 = Color(0xFF0D1520);

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listPayload = widget.listPayload;
    listDDoS = widget.listDDoS;
    newsList = widget.news;

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _fadeAnimation =
        CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut);
    _fadeController.forward();

    _selectedPage = _buildHomePage();
    _initAndroidIdAndConnect();
    _fetchActivityLogs();
    _initVideoBackground();
    _fetchPrayerTimes();
    _startCountdown();
  }

  Future<void> _initVideoBackground() async {
    // Video replaced with custom painter background — no video init needed
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    if (mounted) setState(() => androidId = deviceInfo.id);
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel =
        WebSocketChannel.connect(Uri.parse('ws://olinncntk.twinofc.my.id:1202'));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));
    channel.sink.add(jsonEncode({"type": "stats"}));
    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }
    });
  }

  Future<void> _fetchActivityLogs() async {
    if (!mounted) return;
    setState(() {
      _isLoadingActivityLogs = true;
      _hasActivityLogsError = false;
    });
    try {
      final response = await http.get(Uri.parse(
          'http://olinncntk.twinofc.my.id:1202/api/user/getActivityLogs?key=$sessionKey'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && data['logs'] != null) {
          if (mounted) {
            setState(() {
              _activityLogs =
                  List<Map<String, dynamic>>.from(data['logs']);
              _isLoadingActivityLogs = false;
            });
          }
        } else {
          if (mounted) setState(() => _isLoadingActivityLogs = false);
        }
      } else {
        if (mounted) setState(() => _isLoadingActivityLogs = false);
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoadingActivityLogs = false;
          _hasActivityLogsError = true;
        });
      }
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: _bgCard,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: _teal.withOpacity(0.4)),
        ),
        title: const Text("⚠️ Session Expired",
            style: TextStyle(color: Colors.white, fontFamily: "Orbitron")),
        content: Text(message,
            style: const TextStyle(
                color: Colors.white70, fontFamily: "ShareTechMono")),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            child: Text("OK", style: TextStyle(color: _teal)),
          ),
        ],
      ),
    );
  }

  void _navigateTo(String page) {
    if (page == 'account') {
      _showAccountMenu();
      return;
    }

    Widget nextWidget = _buildHomePage();

    switch (page) {
      case 'home':
        nextWidget = _buildHomePage();
        break;
      case 'bug':
        nextWidget = BugMenuPage(
          username: username,
          password: password,
          listBug: listBug,
          listPayload: listPayload,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
        break;
      case 'custom_bug':
        nextWidget = CustomAttackPage(
          username: username,
          password: password,
          listPayload: listPayload,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
        break;
      case 'group_bug':
        nextWidget = GroupBugPage(
          username: username,
          password: password,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
        break;
      case 'telegram':
        nextWidget = TelegramSpamPage(sessionKey: sessionKey);
        break;
      case 'ddos':
        nextWidget = AttackPanel(sessionKey: sessionKey, listDDoS: listDDoS);
        break;
      case 'tools':
        nextWidget = ToolsPage(sessionKey: sessionKey, userRole: role);
        break;
      case 'reseller':
        nextWidget = SellerPage(keyToken: sessionKey);
        break;
      case 'admin':
        nextWidget = AdminPage(sessionKey: sessionKey);
        break;
      case 'sender':
        nextWidget = SenderPage(sessionKey: sessionKey);
        break;
      case 'rat':
        List<String> allowedRoles = [
          'dev', 'high admin', 'admin', 'high owner', 'owner'
        ];
        if (!allowedRoles.contains(role.toLowerCase())) return;
        nextWidget = const DeviceDashboardPage();
        break;
      case 'change_password':
        nextWidget = ChangePasswordPage(
          username: username,
          sessionKey: sessionKey,
        );
        break;
      case 'spam_ngl':
        nextWidget = const NglPage();
        break;
      case 'wifi_external':
        nextWidget = WifiInternalPage(sessionKey: sessionKey);
        break;
      case 'wifi_internal':
        nextWidget = const WifiKillerPage();
        break;
      case 'nik_parse':
        nextWidget = const NikParsePage();
        break;
      case 'report_wa':
        nextWidget = ReportWaPage(
          sessionKey: sessionKey,
          username: username,
          role: role,
        );
        break;
      case 'public_chat':
        nextWidget = PublicChatPage(username: username);
        break;
      case 'chat_ws':
        nextWidget = ChatPage(sessionKey: sessionKey);
        break;
      case 'tabungan':
        nextWidget = const TabunganKuPage();
        break;
      case 'tes_func':
        nextWidget = TesFuncPage(
          sessionKey: sessionKey,
          username: username,
          role: role,
        );
        break;
      case 'alquran':
        nextWidget = const AlquranPage();
        break;
      case 'beli_akun':
        nextWidget = const BuyAccountPage();
        break;
      case 'chat_user':
        nextWidget = ChatUserPage(sessionKey: sessionKey, username: username);
        break;
    }

    setState(() {
      _activePage = page;
      _selectedPage = nextWidget;
      _fadeController.reset();
      _fadeController.forward();
    });
  }

  // ─────────────────────────────────────────────
  //  TOP HEADER — mirip TANIX (☀️ cuaca + logo + 🔔 + 👤)
  // ─────────────────────────────────────────────
  Widget _buildTopHeader() {
    return Container(
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 10,
        bottom: 10,
        left: 16,
        right: 16,
      ),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        border: Border(
          bottom: BorderSide(color: _teal.withOpacity(0.2), width: 1),
        ),
      ),
      child: Row(
        children: [
          // ☰ Hamburger
          GestureDetector(
            onTap: () => _scaffoldKey.currentState?.openDrawer(),
            child: const Icon(Icons.menu, color: Colors.white70, size: 26),
          ),
          const SizedBox(width: 10),

          // 🌡️ Cuaca (dekoratif)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: Colors.amber.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.amber.withOpacity(0.3)),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.wb_sunny_rounded,
                    color: Colors.amber, size: 16),
                SizedBox(width: 4),
                Text("32°C",
                    style: TextStyle(
                        color: Colors.amber,
                        fontSize: 13,
                        fontFamily: "ShareTechMono")),
              ],
            ),
          ),

          const Spacer(),

          // Logo tengah
          Image.asset(
            'assets/images/logo.png',
            height: 28,
            errorBuilder: (_, __, ___) =>
                const Icon(Icons.bug_report, color: _teal, size: 28),
          ),

          const Spacer(),

          // 🔍 Search Toggle (FITUR BARU)
          GestureDetector(
            onTap: () => setState(() => _showSearchBar = !_showSearchBar),
            child: Icon(
              _showSearchBar ? Icons.search_off_rounded : Icons.search_rounded,
              color: Colors.white54,
              size: 22,
            ),
          ),
          const SizedBox(width: 8),

          // 🎵 Music icon
          GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MusicPage())),
            child: Icon(Icons.music_note_rounded,
                color: Colors.white54, size: 22),
          ),
          const SizedBox(width: 12),

          // 🔔 Notif
          Stack(
            children: [
              const Icon(Icons.notifications_rounded,
                  color: Colors.white70, size: 24),
              Positioned(
                right: 0,
                top: 0,
                child: Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: _teal,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(width: 12),

          // 👤 Avatar
          GestureDetector(
            onTap: _showAccountMenu,
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: _teal.withOpacity(0.5), width: 1.5),
                color: _bgCard,
              ),
              child:
                  const Icon(Icons.person_rounded, color: Colors.white70, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  // ─────────────────────────────────────────────
  //  HOME PAGE CONTENT
  // ─────────────────────────────────────────────
  Widget _buildHomePage() {
    return RefreshIndicator(
      color: _teal,
      onRefresh: () async {
        await _fetchActivityLogs();
        setState(() {});
      },
      child: CustomScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: SizedBox(
                height: MediaQuery.of(context).padding.top + 70),
          ),
          SliverToBoxAdapter(
            child: Column(
              children: [
                // ── Hero Title "tanix" ──
                _buildHeroTitle(),

                const SizedBox(height: 20),

                // ── Search Bar (FITUR BARU) ──
                if (_showSearchBar) _buildSearchBar(),
                if (_showSearchBar) const SizedBox(height: 16),

                // ── Stats Card (FITUR BARU) ──
                _buildStatsCard(),

                const SizedBox(height: 16),

                // ── User Info Card ──
                _buildUserCard(),

                const SizedBox(height: 16),

                // ── Quick Actions (seperti TANIX) ──
                _buildQuickActionsBar(),

                const SizedBox(height: 20),

                // ── Prayer Time Widget (dekoratif seperti TANIX) ──
                _buildPrayerTimeWidget(),

                const SizedBox(height: 20),

                // ── Berita / News Carousel ──
                _buildNewsSection(),

                const SizedBox(height: 20),

                // ── Connect Section ──
                _buildConnectSection(),

                const SizedBox(height: 20),

                // ── Recent Activity ──
                _buildRecentActivity(),

                const SizedBox(height: 120),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── PRAYER TIME FUNCTIONS ───
  Future<void> _fetchPrayerTimes() async {
    try {
      final city = _selectedCity;
      final now = DateTime.now();
      final date = '${now.year}-${now.month.toString().padLeft(2,"0")}-${now.day.toString().padLeft(2,"0")}';
      final uri = Uri.parse(
        'https://api.aladhan.com/v1/timingsByCity?city=$city&country=Indonesia&method=11&date=$date'
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final timings = data['data']['timings'];
        if (mounted) {
          setState(() {
            _prayerTimes = {
              'SUBUH':   timings['Fajr']    ?? '--:--',
              'DZUHUR':  timings['Dhuhr']   ?? '--:--',
              'ASHAR':   timings['Asr']     ?? '--:--',
              'MAGHRIB': timings['Maghrib'] ?? '--:--',
              'ISYA':    timings['Isha']    ?? '--:--',
            };
          });
          _updateActivePrayer();
        }
      }
    } catch (_) {}
    // Refresh setiap 1 jam
    _prayerTimer?.cancel();
    _prayerTimer = Timer(const Duration(hours: 1), _fetchPrayerTimes);
  }

  void _updateActivePrayer() {
    final now = TimeOfDay.now();
    final nowMinutes = now.hour * 60 + now.minute;
    final keys = ['SUBUH', 'DZUHUR', 'ASHAR', 'MAGHRIB', 'ISYA'];
    final times = keys.map((k) {
      final parts = (_prayerTimes[k] ?? '00:00').split(':');
      if (parts.length < 2) return 0;
      return (int.tryParse(parts[0]) ?? 0) * 60 + (int.tryParse(parts[1]) ?? 0);
    }).toList();

    int activeIdx = 0;
    String nextName = keys[0];
    for (int i = 0; i < times.length; i++) {
      if (nowMinutes >= times[i]) {
        activeIdx = i;
        nextName = i + 1 < keys.length ? keys[i + 1] : keys[0];
      }
    }
    if (mounted) setState(() {
      _activePrayerIndex = activeIdx;
      _nextPrayerName = nextName;
    });
  }

  void _startCountdown() {
    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      _updateActivePrayer();
      final nextKey = _nextPrayerName.isEmpty ? 'DZUHUR' : _nextPrayerName;
      final timeStr = _prayerTimes[nextKey] ?? '00:00';
      final parts = timeStr.split(':');
      if (parts.length < 2) return;
      final now = DateTime.now();
      var target = DateTime(now.year, now.month, now.day,
        int.tryParse(parts[0]) ?? 0, int.tryParse(parts[1]) ?? 0);
      if (target.isBefore(now)) target = target.add(const Duration(days: 1));
      final diff = target.difference(now);
      if (mounted) setState(() {
        _countdownStr = '${diff.inHours.toString().padLeft(2,"0")}:${(diff.inMinutes % 60).toString().padLeft(2,"0")}:${(diff.inSeconds % 60).toString().padLeft(2,"0")}';
      });
    });
  }

  void _showCityPicker() {
    final cities = [
      'Jakarta', 'Surabaya', 'Bandung', 'Medan', 'Semarang',
      'Makassar', 'Palembang', 'Tangerang', 'Depok', 'Bekasi',
      'Yogyakarta', 'Malang', 'Bogor', 'Batam', 'Pekanbaru',
    ];
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF111827),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 12),
          Container(width: 40, height: 4,
            decoration: BoxDecoration(color: Colors.white24,
              borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 12),
          const Text('Pilih Kota', style: TextStyle(color: Colors.white,
            fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 14)),
          const SizedBox(height: 8),
          SizedBox(
            height: 300,
            child: ListView.builder(
              itemCount: cities.length,
              itemBuilder: (ctx, i) => ListTile(
                title: Text(cities[i],
                  style: TextStyle(color: _selectedCity == cities[i]
                    ? const Color(0xFF00E5CC) : Colors.white70)),
                trailing: _selectedCity == cities[i]
                  ? const Icon(Icons.check_rounded, color: Color(0xFF00E5CC))
                  : null,
                onTap: () {
                  setState(() => _selectedCity = cities[i]);
                  Navigator.pop(context);
                  _fetchPrayerTimes();
                },
              ),
            ),
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }

  // ─── FITUR BARU: Search Bar ───
  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        decoration: BoxDecoration(
          color: _bgCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _teal.withOpacity(0.3)),
        ),
        child: TextField(
          controller: _searchController,
          style: const TextStyle(color: Colors.white, fontSize: 14),
          cursorColor: _teal,
          onChanged: (val) => setState(() => _searchQuery = val),
          decoration: InputDecoration(
            prefixIcon: Icon(Icons.search, color: _teal, size: 20),
            suffixIcon: _searchQuery.isNotEmpty
                ? IconButton(
                    icon: Icon(Icons.clear, color: Colors.white38, size: 18),
                    onPressed: () {
                      _searchController.clear();
                      setState(() => _searchQuery = '');
                    },
                  )
                : null,
            hintText: 'Cari fitur...',
            hintStyle: TextStyle(color: Colors.white30, fontSize: 14),
            border: InputBorder.none,
            contentPadding:
                const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
          ),
        ),
      ),
    );
  }

  // ─── FITUR BARU: Stats Card ───
  Widget _buildStatsCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          _miniStatCard('Total Kirim', '$_totalSent',
              Icons.send_rounded, _teal),
          const SizedBox(width: 10),
          _miniStatCard('Bug List', '${listBug.length}',
              Icons.bug_report_rounded, Colors.orange),
          const SizedBox(width: 10),
          _miniStatCard('DDoS List', '${listDDoS.length}',
              Icons.flash_on_rounded, Colors.red),
        ],
      ),
    );
  }

  Widget _miniStatCard(
      String label, String value, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.25)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(height: 6),
            Text(value,
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: 2),
            Text(label,
                style: TextStyle(
                    color: Colors.white38,
                    fontSize: 10,
                    fontFamily: 'ShareTechMono'),
                textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  // ── Hero Title seperti TANIX ──
  Widget _buildHeroTitle() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              colors: [Colors.white, _teal],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ).createShader(bounds),
            child: const Text(
              "tanix",
              style: TextStyle(
                fontSize: 64,
                fontWeight: FontWeight.w900,
                color: Colors.white,
                letterSpacing: -2,
                height: 1,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            "Design By KENZMYDEV • Enjoy TANIX Apps",
            style: TextStyle(
              color: _teal.withOpacity(0.7),
              fontSize: 12,
              fontFamily: "ShareTechMono",
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  // ── User Card mirip TANIX (Ahlan wa Sahlan + username + role + stats) ──
  // ── Quick Actions Bar mirip TANIX ──
  Widget _buildQuickActionsBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: _bgCard.withOpacity(0.85),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _teal.withOpacity(0.2)),
          boxShadow: [
            BoxShadow(
              color: _teal.withOpacity(0.06),
              blurRadius: 16,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Row(
          children: [
            // Icon bolt/lightning
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: const LinearGradient(
                  colors: [Color(0xFF29B6F6), Color(0xFF0288D1)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.blue.withOpacity(0.35),
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: const Icon(Icons.bolt_rounded,
                  color: Colors.white, size: 24),
            ),
            const SizedBox(width: 12),

            // Text
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "QUICK ACTIONS",
                    style: TextStyle(
                      color: Colors.white,
                      fontFamily: "Orbitron",
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                  ),
                  SizedBox(height: 2),
                  Text(
                    "Beberapa Menu Tambahan",
                    style: TextStyle(
                      color: Colors.white54,
                      fontSize: 11,
                      fontFamily: "ShareTechMono",
                    ),
                  ),
                ],
              ),
            ),

            // Toggle switch
            GestureDetector(
              onTap: () {
                setState(() {
                  _quickActionsEnabled = !_quickActionsEnabled;
                });
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: _quickActionsEnabled
                      ? _teal.withOpacity(0.15)
                      : Colors.white.withOpacity(0.07),
                  border: Border.all(
                    color: _quickActionsEnabled
                        ? _teal.withOpacity(0.5)
                        : Colors.white.withOpacity(0.15),
                    width: 1.5,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _quickActionsEnabled
                            ? _teal
                            : Colors.white38,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      "TANIX",
                      style: TextStyle(
                        color: _quickActionsEnabled
                            ? _teal
                            : Colors.white38,
                        fontSize: 11,
                        fontFamily: "ShareTechMono",
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUserCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: _bgCard.withOpacity(0.85),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _teal.withOpacity(0.25)),
          boxShadow: [
            BoxShadow(
              color: _teal.withOpacity(0.08),
              blurRadius: 20,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Column(
          children: [
            Row(
              children: [
                // Avatar circle dengan gradient biru
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [Color(0xFF29B6F6), Color(0xFF0288D1)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.blue.withOpacity(0.4),
                        blurRadius: 12,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.verified_user_rounded,
                      color: Colors.white, size: 28),
                ),
                const SizedBox(width: 14),

                // Info user
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Ahlan Wa Sahlan!!,",
                          style: TextStyle(
                              color: Colors.white54, fontSize: 12)),
                      const SizedBox(height: 2),
                      Text(username,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold)),
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 3),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                              color: Colors.white.withOpacity(0.2)),
                        ),
                        child: Text(role.toUpperCase(),
                            style: TextStyle(
                                color: Colors.white70,
                                fontSize: 11,
                                letterSpacing: 1.5,
                                fontFamily: 'ShareTechMono')),
                      ),
                    ],
                  ),
                ),

                // Timer icon
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: _bgDark,
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: _teal.withOpacity(0.3), width: 1.5),
                  ),
                  child: Icon(Icons.timer_outlined, color: _teal, size: 18),
                ),
              ],
            ),

            const SizedBox(height: 14),

            // TANIX DASHBOARD label
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border:
                    Border.all(color: Colors.white.withOpacity(0.12)),
              ),
              child: Center(
                child: Text("TANIX DASHBOARD",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        letterSpacing: 3,
                        fontFamily: 'Orbitron')),
              ),
            ),

            const SizedBox(height: 16),

            // Stats Row (Online Users, Active Connections, Expiration)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _statCircle(Icons.group_rounded, "0", "Online Users",
                    const Color(0xFF2E7D32)),
                _statCircle(Icons.link_rounded, "0",
                    "Active Connections", const Color(0xFF1565C0)),
                _statCircle(Icons.calendar_today_rounded,
                    expiredDate.split(' ').first, "Expiration",
                    const Color(0xFF8C6D00)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _statCircle(
      IconData icon, String value, String label, Color color) {
    return Column(
      children: [
        Container(
          width: 54,
          height: 54,
          decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.22)),
          child: Icon(icon, color: color, size: 24),
        ),
        const SizedBox(height: 6),
        Text(value,
            style: const TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.bold)),
        const SizedBox(height: 2),
        Text(label,
            style: TextStyle(
                color: Colors.white.withOpacity(0.45), fontSize: 10),
            textAlign: TextAlign.center),
      ],
    );
  }

  // ── Prayer Time Widget - DATA REAL dari API ──
  Widget _buildPrayerTimeWidget() {
    final prayerKeys = ['SUBUH', 'DZUHUR', 'ASHAR', 'MAGHRIB'];
    final prayerIcons = [
      Icons.nights_stay_rounded,
      Icons.wb_sunny_rounded,
      Icons.cloud_outlined,
      Icons.dark_mode_rounded,
    ];
    final prayers = List.generate(prayerKeys.length, (i) => {
      "name": prayerKeys[i],
      "time": _prayerTimes[prayerKeys[i]] ?? '--:--',
      "icon": prayerIcons[i],
    });

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _bgCard2.withOpacity(0.9),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _teal.withOpacity(0.2)),
        ),
        child: Column(
          children: [
            Row(
              children: [
                const Icon(Icons.mosque_rounded, color: _teal, size: 22),
                const SizedBox(width: 10),
                const Text("JADWAL SHOLAT",
                    style: TextStyle(
                        color: Colors.white,
                        fontFamily: "Orbitron",
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1)),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _teal.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                    border:
                        Border.all(color: _teal.withOpacity(0.3)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.timer_rounded,
                          color: _teal, size: 12),
                      const SizedBox(width: 4),
                      Text("MENUJU $_nextPrayerName : $_countdownStr",
                          style: TextStyle(
                              color: _teal,
                              fontSize: 10,
                              fontFamily: "ShareTechMono")),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: List.generate(prayers.length, (i) {
                final isActive = i == _activePrayerIndex && _activePrayerIndex < 4;
                return Expanded(
                  child: Container(
                    margin: EdgeInsets.only(right: i < 3 ? 8 : 0),
                    padding: const EdgeInsets.symmetric(
                        vertical: 12, horizontal: 8),
                    decoration: BoxDecoration(
                      color: isActive
                          ? _teal.withOpacity(0.15)
                          : _bgCard.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: isActive
                              ? _teal.withOpacity(0.5)
                              : Colors.white.withOpacity(0.08)),
                    ),
                    child: Column(
                      children: [
                        Icon(prayers[i]["icon"] as IconData,
                            color: isActive
                                ? _teal
                                : Colors.white38,
                            size: 20),
                        const SizedBox(height: 6),
                        Text(prayers[i]["name"] as String,
                            style: TextStyle(
                                color: isActive
                                    ? _teal
                                    : Colors.white38,
                                fontSize: 9,
                                fontFamily: "ShareTechMono",
                                letterSpacing: 0.5)),
                        const SizedBox(height: 4),
                        Text(prayers[i]["time"] as String,
                            style: TextStyle(
                                color: isActive
                                    ? Colors.white
                                    : Colors.white60,
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                fontFamily: "ShareTechMono")),
                      ],
                    ),
                  ),
                );
              }),
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: _bgCard.withOpacity(0.5),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                    color: Colors.white.withOpacity(0.1)),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.location_on_rounded,
                      color: _teal, size: 16),
                  SizedBox(width: 6),
                  Text("JAKARTA",
                      style: TextStyle(
                          color: Colors.white70,
                          fontFamily: "ShareTechMono",
                          fontSize: 13,
                          letterSpacing: 1)),
                  SizedBox(width: 4),
                  Icon(Icons.keyboard_arrow_down,
                      color: Colors.white54, size: 18),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── News Carousel seperti TANIX (card berwarna dengan icon besar) ──
  Widget _buildNewsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              const Icon(Icons.calendar_view_week_rounded,
                  color: _teal, size: 22),
              const SizedBox(width: 10),
              const Text("BERITA TERKINI",
                  style: TextStyle(
                      color: Colors.white,
                      fontFamily: "Orbitron",
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                      letterSpacing: 1)),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 5),
                decoration: BoxDecoration(
                  color: _teal.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _teal.withOpacity(0.3)),
                ),
                child: Text(
                    "${newsList.length.clamp(0, 9)} Berita",
                    style: TextStyle(
                        color: _teal,
                        fontSize: 12,
                        fontFamily: "ShareTechMono")),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // Fallback cards jika news kosong
        if (newsList.isEmpty)
          ..._buildDefaultNewsCards()
        else
          SizedBox(
            height: 200,
            child: PageView.builder(
              controller: _newsPageController,
              itemCount: newsList.length,
              onPageChanged: (i) =>
                  setState(() => _currentNewsIndex = i),
              itemBuilder: (ctx, i) {
                final item = newsList[i];
                final colors = [
                  [const Color(0xFF1565C0), const Color(0xFF0D47A1)],
                  [const Color(0xFF2E7D32), const Color(0xFF1B5E20)],
                  [const Color(0xFF6A1B9A), const Color(0xFF4A148C)],
                  [const Color(0xFFE65100), const Color(0xFFBF360C)],
                ];
                final c = colors[i % colors.length];
                return _buildNewsCard(
                  item['title'] ?? 'Berita',
                  item['desc'] ?? '',
                  Icons.flash_on_rounded,
                  c[0],
                  c[1],
                );
              },
            ),
          ),

        // Page Dots
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            newsList.isEmpty ? 7 : newsList.length,
            (i) => AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: _currentNewsIndex == i ? 24 : 8,
              height: 6,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: _currentNewsIndex == i
                    ? _teal
                    : Colors.white.withOpacity(0.2),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // Feature cards mirip TANIX (berwarna-warni)
  List<Widget> _buildDefaultNewsCards() {
    final cards = [
      {
        "title": "TabunganKu",
        "desc": "Manage Duit",
        "icon": Icons.account_balance_wallet_rounded,
        "page": "tabungan",
        "c1": const Color(0xFF00C853),
        "c2": const Color(0xFF1B5E20),
      },
      {
        "title": "Manage Bug Sender",
        "desc": "Pairing & Configuration",
        "icon": Icons.bug_report_rounded,
        "page": "bug",
        "c1": const Color(0xFFE53935),
        "c2": const Color(0xFFB71C1C),
      },
      {
        "title": "Telegram Report",
        "desc": "TANIX Report System",
        "icon": FontAwesomeIcons.telegram,
        "page": "telegram",
        "c1": const Color(0xFF0288D1),
        "c2": const Color(0xFF01579B),
      },
      {
        "title": "DDoS Attack",
        "desc": "Serangan DDoS ke target server",
        "icon": Icons.flash_on_rounded,
        "page": "ddos",
        "c1": const Color(0xFFE65100),
        "c2": const Color(0xFFBF360C),
      },
      {
        "title": "Tools",
        "desc": "Beberapa Menu Tambahan",
        "icon": Icons.construction_rounded,
        "page": "tools",
        "c1": const Color(0xFF2E7D32),
        "c2": const Color(0xFF1B5E20),
      },
      {
        "title": "RAT Panel",
        "desc": "Remote Access Control Device",
        "icon": Icons.phone_android_rounded,
        "page": "rat",
        "c1": const Color(0xFF6A1B9A),
        "c2": const Color(0xFF4A148C),
      },
      {
        "title": "Al-Quran",
        "desc": "Alquran Lengkap Beserta Terjemahan",
        "icon": Icons.menu_book_rounded,
        "page": "alquran",
        "c1": const Color(0xFF2E7D32),
        "c2": const Color(0xFF1B5E20),
      },
      {
        "title": "TES FUNC",
        "desc": "Test Function & Message",
        "icon": Icons.code_rounded,
        "page": "tes_func",
        "c1": const Color(0xFF00ACC1),
        "c2": const Color(0xFF006064),
      },
      {
        "title": "Beli Akun",
        "desc": "Member, Reseller & VIP",
        "icon": Icons.shopping_cart_rounded,
        "page": "beli_akun",
        "c1": const Color(0xFF00C853),
        "c2": const Color(0xFF00695C),
      },
    ];

    return [
      SizedBox(
        height: 200,
        child: PageView.builder(
          controller: _newsPageController,
          itemCount: cards.length,
          onPageChanged: (i) =>
              setState(() => _currentNewsIndex = i),
          itemBuilder: (ctx, i) {
            final c = cards[i];
            return _buildNewsCard(
              c['title'] as String,
              c['desc'] as String,
              c['icon'] as IconData,
              c['c1'] as Color,
              c['c2'] as Color,
              page: c['page'] as String,
            );
          },
        ),
      ),
    ];
  }

  Widget _buildNewsCard(
    String title,
    String desc,
    IconData icon,
    Color c1,
    Color c2, {
    String page = "",
  }) {
    return GestureDetector(
      onTap: page.isNotEmpty ? () => _navigateTo(page) : null,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [c1, c2], begin: Alignment.topLeft, end: Alignment.bottomRight),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
                color: c1.withOpacity(0.4),
                blurRadius: 12,
                offset: const Offset(0, 4))
          ],
        ),
        child: Stack(
          children: [
            // Background circles
            Positioned(
              right: -30,
              top: -30,
              child: Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.07),
                ),
              ),
            ),
            Positioned(
              left: -20,
              bottom: -20,
              child: Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.05),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(icon, color: Colors.white, size: 24),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.25),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Text("Tap →",
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontFamily: "ShareTechMono")),
                      ),
                    ],
                  ),
                  const Spacer(),
                  Text(title,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          fontFamily: "Orbitron",
                          letterSpacing: 1)),
                  const SizedBox(height: 4),
                  Text(desc,
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.8),
                          fontSize: 12,
                          fontFamily: "ShareTechMono")),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Connect Section mirip TANIX ──
  Widget _buildConnectSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: _bgCard2.withOpacity(0.9),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _teal.withOpacity(0.15)),
        ),
        child: Column(
          children: [
            Row(
              children: [
                const Icon(Icons.wifi_tethering_rounded,
                    color: _teal, size: 22),
                const SizedBox(width: 10),
                const Text("CONNECT WITH TANIX TEAM",
                    style: TextStyle(
                        color: Colors.white,
                        fontFamily: "Orbitron",
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.5)),
              ],
            ),
            const SizedBox(height: 18),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _socialCircle(FontAwesomeIcons.telegram, "Telegram",
                    const Color(0xFF1565C0), const Color(0xFF0D47A1)),
                _socialCircle(FontAwesomeIcons.youtube, "YouTube",
                    Colors.red.shade800, Colors.red.shade900),
                _socialCircle(FontAwesomeIcons.tiktok, "TikTok",
                    const Color(0xFF212121), const Color(0xFF000000)),
                _socialCircle(Icons.favorite_rounded, "Thanks To",
                    Colors.pink.shade700, Colors.pink.shade900),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              "Selalu nantikan project terbaru dari TEAM TANIX",
              style: TextStyle(
                  color: Colors.white.withOpacity(0.5),
                  fontSize: 12,
                  fontFamily: "ShareTechMono"),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _socialCircle(
      IconData icon, String label, Color c1, Color c2) {
    return Column(
      children: [
        Container(
          width: 54,
          height: 54,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
                colors: [c1, c2],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight),
            boxShadow: [
              BoxShadow(
                  color: c1.withOpacity(0.4),
                  blurRadius: 8,
                  spreadRadius: 1)
            ],
          ),
          child: Icon(icon, color: Colors.white, size: 22),
        ),
        const SizedBox(height: 8),
        Text(label,
            style: TextStyle(
                color: Colors.white.withOpacity(0.7),
                fontSize: 11,
                fontFamily: "ShareTechMono")),
      ],
    );
  }

  // ── Recent Activity ──
  Widget _buildRecentActivity() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.history_rounded, color: _teal, size: 20),
              const SizedBox(width: 8),
              const Text("RECENT ACTIVITY",
                  style: TextStyle(
                      color: _teal,
                      fontFamily: "Orbitron",
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1.5)),
            ],
          ),
          const SizedBox(height: 14),
          if (_isLoadingActivityLogs)
            Container(
              height: 100,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  color: _bgCard),
              child: const Center(
                  child: CircularProgressIndicator(color: _teal)),
            )
          else if (_activityLogs.isEmpty)
            Container(
              height: 80,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  color: _bgCard,
                  border: Border.all(
                      color: Colors.white.withOpacity(0.07))),
              child: Center(
                child: Text("No activity logs available",
                    style: TextStyle(
                        color: Colors.white38,
                        fontFamily: "ShareTechMono")),
              ),
            )
          else
            ..._activityLogs.take(5).map((log) {
              final timestamp =
                  DateTime.tryParse(log['timestamp'] ?? '') ??
                      DateTime.now();
              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 12),
                decoration: BoxDecoration(
                  color: _bgCard,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: Colors.white.withOpacity(0.06)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.history_rounded,
                        color: Colors.white38, size: 16),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        log['activity'] ?? 'Unknown',
                        style: const TextStyle(
                            color: Colors.white70,
                            fontFamily: "ShareTechMono",
                            fontSize: 13),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      _formatDateTime(timestamp),
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.3),
                          fontSize: 11,
                          fontFamily: "ShareTechMono"),
                    ),
                  ],
                ),
              );
            }).toList(),
        ],
      ),
    );
  }

  String _formatDateTime(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inDays > 0) return '${diff.inDays}d ago';
    if (diff.inHours > 0) return '${diff.inHours}h ago';
    if (diff.inMinutes > 0) return '${diff.inMinutes}m ago';
    return 'Just now';
  }

  // ─────────────────────────────────────────────
  //  DRAWER (mirip TANIX sidebar)
  // ─────────────────────────────────────────────

  void _showThemePicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        decoration: const BoxDecoration(
          color: Color(0xFF0D1B2A),
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(4))),
            const SizedBox(height: 20),
            Row(children: [
              Container(width: 42, height: 42, decoration: BoxDecoration(color: _teal.withOpacity(0.15), borderRadius: BorderRadius.circular(12)), child: Icon(Icons.palette_rounded, color: _teal, size: 22)),
              const SizedBox(width: 12),
              const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text("GANTI TEMA", style: TextStyle(color: Color(0xFF00E5CC), fontSize: 11, letterSpacing: 3, fontWeight: FontWeight.bold)),
                Text("Pilih warna tema aplikasi", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
              ]),
            ]),
            const SizedBox(height: 20),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: ThemeManager.themes.map((t) {
                final color = t['primary'] as Color;
                final key = t['key'] as String;
                final name = t['name'] as String;
                final isSelected = ThemeManager().themeKey == key;
                return GestureDetector(
                  onTap: () {
                    ThemeManager().setTheme(key);
                    Navigator.pop(context);
                    setState(() {});
                  },
                  child: Column(
                    children: [
                      Container(
                        width: 52, height: 52,
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.2),
                          shape: BoxShape.circle,
                          border: Border.all(color: isSelected ? color : Colors.white12, width: isSelected ? 3 : 1),
                          boxShadow: isSelected ? [BoxShadow(color: color.withOpacity(0.4), blurRadius: 12)] : [],
                        ),
                        child: isSelected ? Icon(Icons.check_rounded, color: color, size: 24) : null,
                        foregroundDecoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(0.4)),
                      ),
                      const SizedBox(height: 6),
                      Text(name, style: TextStyle(color: isSelected ? color : Colors.white38, fontSize: 10, fontWeight: FontWeight.bold)),
                    ],
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawer() {
    final String r = role.toLowerCase();
    final bool isAdmin = ['dev', 'high admin', 'admin', 'high owner', 'owner'].contains(r);
    final bool isSeller = isAdmin || r == 'reseller';

    return Drawer(
      backgroundColor: _bgDark,
      child: SafeArea(
        child: Column(
          children: [
            // Header drawer
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(
                        color: _teal.withOpacity(0.2), width: 1)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                          colors: [Color(0xFF29B6F6), Color(0xFF0288D1)]),
                    ),
                    child: const Icon(Icons.verified_user_rounded,
                        color: Colors.white, size: 24),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(username,
                          style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 16)),
                      Text(role.toUpperCase(),
                          style: TextStyle(
                              color: _teal,
                              fontSize: 11,
                              fontFamily: "ShareTechMono")),
                    ],
                  ),
                ],
              ),
            ),

            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 8),
                children: [
                  _drawerItem(Icons.home_rounded, "Home", 'home'),
                  _drawerItem(FontAwesomeIcons.whatsapp, "Bug WA", 'bug'),
                  _drawerItem(
                      FontAwesomeIcons.telegram, "Spam", 'telegram'),
                  _drawerItem(Icons.flash_on_rounded, "DDoS", 'ddos'),
                  _drawerItem(Icons.construction_rounded, "Tools", 'tools'),

                  if (isSeller)
                    _drawerItem(Icons.store_rounded, "Seller", 'reseller'),
                  if (isAdmin)
                    _drawerItem(
                        Icons.admin_panel_settings_rounded, "Admin", 'admin'),
                  _drawerItem(
                      FontAwesomeIcons.whatsapp, "Sender", 'sender'),
                  const Divider(color: Colors.white12, height: 20),
                  _drawerItem(Icons.person_rounded, "Account", 'account'),
                  const Divider(color: Colors.white12, height: 20),
                  _drawerItem(Icons.wifi_rounded, "WiFi Tools", 'wifi_external'),
                  _drawerItem(Icons.wifi_off_rounded, "WiFi Killer", 'wifi_internal'),
                  _drawerItem(Icons.message_rounded, "Spam NGL", 'spam_ngl'),
                  _drawerItem(Icons.report_rounded, "Report WA", 'report_wa'),
                  _drawerItem(Icons.code_rounded, "Tes Func", 'tes_func'),
                  _drawerItem(Icons.chat_rounded, "Public Chat", 'public_chat'),
                  _drawerItem(Icons.forum_rounded, "Chat WS", 'chat_ws'),
                  _drawerItem(Icons.people_alt_rounded, "Chat User", 'chat_user'),
                  const Divider(color: Colors.white12, height: 20),
                  ListTile(
                    leading: const Icon(Icons.palette_rounded, color: Colors.white54, size: 20),
                    title: const Text("Ganti Tema", style: TextStyle(color: Colors.white70, fontFamily: "ShareTechMono", fontSize: 14)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    onTap: () { Navigator.pop(context); _showThemePicker(); },
                  ),
                ],
              ),
            ),

            // Logout
            Padding(
              padding: const EdgeInsets.all(16),
              child: GestureDetector(
                onTap: () async {
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.clear();
                  if (!mounted) return;
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
                  );
                },
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    color: Colors.red.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                        color: Colors.red.withOpacity(0.3)),
                  ),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.logout_rounded,
                          color: Colors.red, size: 18),
                      SizedBox(width: 8),
                      Text("LOGOUT",
                          style: TextStyle(
                              color: Colors.red,
                              fontFamily: "Orbitron",
                              fontSize: 13,
                              letterSpacing: 1)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _drawerItem(IconData icon, String label, String page) {
    final bool isActive = _activePage == page;
    return ListTile(
      leading: Icon(icon,
          color: isActive ? _teal : Colors.white54, size: 20),
      title: Text(label,
          style: TextStyle(
              color: isActive ? Colors.white : Colors.white70,
              fontFamily: "ShareTechMono",
              fontSize: 14)),
      tileColor:
          isActive ? _teal.withOpacity(0.08) : Colors.transparent,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10)),
      onTap: () {
        Navigator.pop(context);
        _navigateTo(page);
      },
      trailing: isActive
          ? Container(
              width: 6,
              height: 6,
              decoration: const BoxDecoration(
                  color: _teal, shape: BoxShape.circle))
          : null,
    );
  }

  // ─────────────────────────────────────────────
  //  BOTTOM NAV mirip TANIX
  // ─────────────────────────────────────────────
  // Halaman yang tidak perlu bottom nav
  bool _isFullScreenPage(String page) {
    const fullScreenPages = [
      'public_chat', 'chat_ws', 'rat', 'nik_parse',
      'wifi_internal', 'wifi_external', 'spam_ngl',
      'alquran', 'anime', 'report_wa', 'tes_func',
      'change_password', 'tabungan', 'beli_akun', 'chat_user',
    ];
    return fullScreenPages.contains(page);
  }

  Widget _buildBottomNav() {
    final navItems = [
      {'icon': Icons.home_filled, 'label': 'Home', 'page': 'home'},
      {'icon': Icons.chat_bubble_rounded, 'label': 'Bug', 'page': 'bug'},
      {'icon': Icons.group_rounded, 'label': 'Tools', 'page': 'tools'},
      {'icon': Icons.settings_rounded, 'label': 'More', 'page': 'more'},
    ];

    return Positioned(
      bottom: 20,
      left: 16,
      right: 16,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: BoxDecoration(
          color: _bgCard.withOpacity(0.95),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: _teal.withOpacity(0.2), width: 1.5),
          boxShadow: [
            BoxShadow(
                color: _teal.withOpacity(0.1),
                blurRadius: 20,
                spreadRadius: 2),
            BoxShadow(
                color: Colors.black.withOpacity(0.4),
                blurRadius: 10),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: navItems.map((item) {
            final String page = item['page'] as String;
            final bool isActive = _activePage == page ||
                (page == 'bug' &&
                    (_activePage == 'group_bug' ||
                        _activePage == 'custom_bug'));

            return GestureDetector(
              onTap: () {
                if (page == 'more') {
                  _scaffoldKey.currentState?.openDrawer();
                } else {
                  _navigateTo(page);
                }
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 8),
                decoration: isActive
                    ? BoxDecoration(
                        color: _teal.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: _teal.withOpacity(0.5), width: 1.5),
                      )
                    : null,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(item['icon'] as IconData,
                        color: isActive ? _teal : Colors.white38,
                        size: 22),
                    const SizedBox(height: 4),
                    Text(item['label'] as String,
                        style: TextStyle(
                            color:
                                isActive ? _teal : Colors.white38,
                            fontSize: 10,
                            fontFamily: "ShareTechMono",
                            fontWeight: isActive
                                ? FontWeight.bold
                                : FontWeight.normal)),
                    if (isActive)
                      Container(
                        margin: const EdgeInsets.only(top: 3),
                        width: 16,
                        height: 2,
                        decoration: BoxDecoration(
                            color: _teal,
                            borderRadius:
                                BorderRadius.circular(2)),
                      ),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  // ── Account Menu ──
  void _showAccountMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        decoration: BoxDecoration(
          color: _bgCard,
          borderRadius:
              const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border.all(color: _teal.withOpacity(0.2)),
        ),
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2)),
            ),
            const SizedBox(height: 16),
            const Text("Account Info",
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontFamily: "Orbitron")),
            const SizedBox(height: 16),
            _infoRow(Icons.person_rounded, "Username", username),
            _infoRow(Icons.date_range_rounded, "Expired", expiredDate),
            _infoRow(Icons.security_rounded, "Role", role),
            const SizedBox(height: 16),
            _sheetBtn(Icons.lock_reset_rounded, "Change Password",
                Colors.blue, () {
              Navigator.pop(context);
              _navigateTo('change_password');
            }),
            const SizedBox(height: 8),
            _sheetBtn(Icons.logout_rounded, "Logout", Colors.red,
                () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (!mounted) return;
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (r) => false,
              );
            }),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
          color: _bgDark,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white.withOpacity(0.08))),
      child: Row(
        children: [
          Icon(icon, color: _teal, size: 18),
          const SizedBox(width: 10),
          Text("$label:",
              style: TextStyle(
                  color: Colors.white54,
                  fontFamily: "ShareTechMono")),
          const Spacer(),
          Text(value,
              style: const TextStyle(
                  color: Colors.white, fontFamily: "ShareTechMono")),
        ],
      ),
    );
  }

  Widget _sheetBtn(
      IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 18),
            const SizedBox(width: 8),
            Text(label,
                style: TextStyle(
                    color: color,
                    fontFamily: "ShareTechMono",
                    fontSize: 14)),
          ],
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────
  //  BUILD
  // ─────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _activePage == 'home',
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop && _activePage != 'home') {
          _navigateTo('home');
        }
      },
      child: Scaffold(
        key: _scaffoldKey,
        backgroundColor: _bgDark,
        drawer: _buildDrawer(),
        body: Stack(
          children: [
            // 1. Background — teal circuit/glow style
            SizedBox.expand(
              child: CustomPaint(
                painter: _TanixBgPainter(),
              ),
            ),

            // 2. Subtle overlay
            Container(color: Colors.black.withOpacity(0.35)),

            // 3. Content
            SafeArea(
              top: false,
              bottom: false,
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: _selectedPage,
              ),
            ),

            // 4. Top Header (hanya di home)
            if (_activePage == 'home')
              Positioned(
                top: 0, left: 0, right: 0,
                child: _buildTopHeader(),
              ),

            // 5. Bottom Nav - sembunyikan di halaman full screen
            if (!_isFullScreenPage(_activePage))
              _buildBottomNav(),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _newsPageController.dispose();
    _videoController?.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    _searchController.dispose();
    _prayerTimer?.cancel();
    _countdownTimer?.cancel();
    super.dispose();
  }
}


// ── TANIX Background Painter ──
class _TanixBgPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // Base gradient
    final bgPaint = Paint();
    final bgRect = Rect.fromLTWH(0, 0, size.width, size.height);
    bgPaint.shader = const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xFF060B14), Color(0xFF071520), Color(0xFF060B14)],
    ).createShader(bgRect);
    canvas.drawRect(bgRect, bgPaint);

    final circlePaint = Paint()..style = PaintingStyle.stroke..strokeWidth = 1;
    final glowPaint = Paint()..style = PaintingStyle.fill;

    // Glow circles (teal) - like screenshot
    final glows = [
      [size.width * 0.15, size.height * 0.15, 180.0, 0xFF00BCD4, 0.06],
      [size.width * 0.85, size.height * 0.25, 220.0, 0xFF007B8A, 0.05],
      [size.width * 0.5,  size.height * 0.55, 260.0, 0xFF00BCD4, 0.04],
      [size.width * 0.1,  size.height * 0.75, 150.0, 0xFF007B8A, 0.04],
      [size.width * 0.9,  size.height * 0.85, 180.0, 0xFF00BCD4, 0.05],
    ];

    for (final g in glows) {
      final center = Offset(g[0] as double, g[1] as double);
      final radius = g[2] as double;
      final color = Color(g[3] as int);
      final opacity = g[4] as double;
      glowPaint.shader = RadialGradient(
        colors: [color.withOpacity(opacity), Colors.transparent],
      ).createShader(Rect.fromCircle(center: center, radius: radius));
      canvas.drawCircle(center, radius, glowPaint);
    }

    // Circuit-like lines (horizontal + vertical dotted)
    circlePaint
      ..color = const Color(0xFF00BCD4).withOpacity(0.07)
      ..strokeWidth = 1;

    for (int i = 0; i < 6; i++) {
      final y = size.height * (i + 1) / 7;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), circlePaint);
    }
    for (int i = 0; i < 4; i++) {
      final x = size.width * (i + 1) / 5;
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), circlePaint);
    }

    // Hexagon-like rings
    circlePaint
      ..color = const Color(0xFF00BCD4).withOpacity(0.06)
      ..strokeWidth = 0.8;
    final ringCenters = [
      Offset(size.width * 0.15, size.height * 0.15),
      Offset(size.width * 0.85, size.height * 0.85),
      Offset(size.width * 0.7, size.height * 0.3),
    ];
    for (final c in ringCenters) {
      canvas.drawCircle(c, 60, circlePaint);
      canvas.drawCircle(c, 100, circlePaint..color = const Color(0xFF00BCD4).withOpacity(0.03));
    }
  }

  @override
  bool shouldRepaint(_TanixBgPainter oldDelegate) => false;
}
