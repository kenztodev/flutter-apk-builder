import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class TabunganKuPage extends StatefulWidget {
  const TabunganKuPage({super.key});
  @override
  State<TabunganKuPage> createState() => _TabunganKuPageState();
}

class _TabunganKuPageState extends State<TabunganKuPage> {
  static const Color _teal = Color(0xFF00E5CC);
  static const Color _bg   = Color(0xFF080C14);
  static const Color _card = Color(0xFF0F1520);
  static const Color _green = Color(0xFF00C853);
  static const Color _red   = Color(0xFFE53935);

  int _balance = 0;
  int _totalIn = 0;
  int _totalOut = 0;
  bool _hideBalance = false;
  List<Map<String,dynamic>> _history = [];
  int _selectedTab = 0; // 0=home,1=keuangan,2=kalkulator,3=riwayat,4=profil
  Timer? _clockTimer;
  DateTime _now = DateTime.now();

  // ─── Kalkulator ───
  String _calcDisplay = '0';
  String _calcExpression = '';
  double? _calcLeft;
  String? _calcOp;
  bool _calcNewNum = false;

  @override
  void initState() {
    super.initState();
    _loadData();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('tabungan_history') ?? '[]';
    final list = List<Map<String,dynamic>>.from(jsonDecode(raw));
    int bal = 0, tin = 0, tout = 0;
    for (final e in list) {
      if (e['type'] == 'Pemasukan') { bal += (e['amount'] as int); tin += (e['amount'] as int); }
      else { bal -= (e['amount'] as int); tout += (e['amount'] as int); }
    }
    if (mounted) setState(() {
      _history = list.reversed.toList();
      _balance = bal; _totalIn = tin; _totalOut = tout;
    });
  }

  Future<void> _saveData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('tabungan_history', jsonEncode(_history.reversed.toList()));
  }

  String _fmtRp(int val) {
    String s = val.abs().toString();
    String r = '';
    int cnt = 0;
    for (int i = s.length-1; i >= 0; i--) {
      if (cnt > 0 && cnt % 3 == 0) r = '.$r';
      r = s[i] + r;
      cnt++;
    }
    return 'Rp $r';
  }

  String get _dayName {
    const d = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
    return d[_now.weekday % 7];
  }
  String get _monthName {
    const m = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
    return m[_now.month];
  }
  String get _timeStr => '${_now.hour.toString().padLeft(2,"0")}:${_now.minute.toString().padLeft(2,"0")}:${_now.second.toString().padLeft(2,"0")}';
  String get _dateStr => '$_dayName, ${_now.day} $_monthName ${_now.year}';

  void _showAddSheet(String type) {
    final amtCtrl = TextEditingController();
    final noteCtrl = TextEditingController();
    final cats = type == 'Pemasukan'
      ? ['Gaji','Bisnis','Investasi','Transfer','Lainnya']
      : ['Makan','Transport','Belanja','Tagihan','Hiburan','Lainnya'];
    String selCat = cats[0];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: _card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => StatefulBuilder(
        builder: (ctx, setS) => Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom + 16,
            top: 16, left: 16, right: 16),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 40, height: 4,
              decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)))),
            const SizedBox(height: 14),
            Text(type, style: TextStyle(color: type=='Pemasukan'?_green:_red,
              fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 14),
            // Nominal
            TextField(
              controller: amtCtrl,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.white, fontSize: 18),
              cursorColor: _teal,
              decoration: InputDecoration(
                prefixText: 'Rp ', prefixStyle: TextStyle(color: _teal, fontSize: 18),
                hintText: '0', hintStyle: const TextStyle(color: Colors.white24),
                filled: true, fillColor: Colors.white.withOpacity(0.05),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14)),
            ),
            const SizedBox(height: 12),
            // Kategori
            Wrap(spacing: 8, runSpacing: 8, children: cats.map((cat) =>
              GestureDetector(
                onTap: () => setS(() => selCat = cat),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: selCat == cat ? _teal.withOpacity(0.2) : Colors.white.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: selCat == cat ? _teal : Colors.white.withOpacity(0.1))),
                  child: Text(cat, style: TextStyle(
                    color: selCat == cat ? _teal : Colors.white54, fontSize: 12))),
              )).toList(),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: noteCtrl,
              style: const TextStyle(color: Colors.white),
              cursorColor: _teal,
              decoration: InputDecoration(
                hintText: 'Catatan (opsional)',
                hintStyle: const TextStyle(color: Colors.white30),
                filled: true, fillColor: Colors.white.withOpacity(0.05),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14)),
            ),
            const SizedBox(height: 16),
            GestureDetector(
              onTap: () {
                final amt = int.tryParse(amtCtrl.text.replaceAll('.',''));
                if (amt == null || amt <= 0) return;
                final entry = {'type': type, 'amount': amt, 'category': selCat,
                  'note': noteCtrl.text.trim().isEmpty ? selCat : noteCtrl.text.trim(),
                  'date': DateTime.now().toIso8601String()};
                setState(() {
                  _history.insert(0, entry);
                  if (type == 'Pemasukan') { _balance += amt; _totalIn += amt; }
                  else { _balance -= amt; _totalOut += amt; }
                });
                _saveData();
                Navigator.pop(context);
              },
              child: Container(
                width: double.infinity, height: 52,
                decoration: BoxDecoration(
                  color: type == 'Pemasukan' ? _green : _red,
                  borderRadius: BorderRadius.circular(14)),
                child: Center(child: Text('SIMPAN ${type.toUpperCase()}',
                  style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold, letterSpacing: 1.5)))),
            ),
          ]),
        ),
      ),
    );
  }

  // ─── Kalkulator logic ───
  void _calcInput(String val) {
    setState(() {
      if (val == 'AC') {
        _calcDisplay = '0'; _calcExpression = ''; _calcLeft = null; _calcOp = null; _calcNewNum = false;
      } else if (val == 'C') {
        _calcDisplay = _calcDisplay.length > 1 ? _calcDisplay.substring(0, _calcDisplay.length-1) : '0';
      } else if (val == '+/-') {
        _calcDisplay = _calcDisplay.startsWith('-') ? _calcDisplay.substring(1) : '-$_calcDisplay';
      } else if (val == '%') {
        _calcDisplay = ((double.tryParse(_calcDisplay) ?? 0) / 100).toString();
      } else if (['+', '-', '×', '÷'].contains(val)) {
        _calcLeft = double.tryParse(_calcDisplay); _calcOp = val; _calcNewNum = true;
        _calcExpression = '$_calcDisplay $val';
      } else if (val == '=') {
        if (_calcLeft != null && _calcOp != null) {
          final right = double.tryParse(_calcDisplay) ?? 0;
          double res;
          if (_calcOp == '+') res = _calcLeft! + right;
          else if (_calcOp == '-') res = _calcLeft! - right;
          else if (_calcOp == '×') res = _calcLeft! * right;
          else res = right == 0 ? 0 : _calcLeft! / right;
          _calcDisplay = res == res.toInt() ? res.toInt().toString() : res.toStringAsFixed(2);
          _calcLeft = null; _calcOp = null; _calcNewNum = false; _calcExpression = '';
        }
      } else if (val == ',') {
        if (!_calcDisplay.contains('.')) _calcDisplay += '.';
      } else {
        if (_calcNewNum || _calcDisplay == '0') { _calcDisplay = val; _calcNewNum = false; }
        else _calcDisplay += val;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(child: Column(children: [
        // ─── TOP BAR ───
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: const Icon(Icons.arrow_back_ios_rounded, color: Colors.white70, size: 18)),
            const SizedBox(width: 12),
            const Text('Tabunganku', style: TextStyle(color: Colors.white,
              fontSize: 18, fontWeight: FontWeight.bold)),
            const Spacer(),
            Text(_timeStr, style: TextStyle(
              color: _teal, fontFamily: 'ShareTechMono', fontSize: 18)),
            const SizedBox(width: 12),
            Icon(Icons.notifications_outlined, color: Colors.white54),
          ]),
        ),
        Text(_dateStr, style: TextStyle(color: _teal, fontSize: 12,
          fontFamily: 'ShareTechMono'), textAlign: TextAlign.left),

        // ─── CONTENT ───
        Expanded(child: _buildTabContent()),

        // ─── BOTTOM NAV ───
        _buildBottomNav(),
      ])),
    );
  }

  Widget _buildTabContent() {
    switch (_selectedTab) {
      case 0: return _buildHomeTab();
      case 1: return _buildKeuanganTab();
      case 2: return _buildKalkulatorTab();
      case 3: return _buildRiwayatTab();
      case 4: return _buildProfilTab();
      default: return _buildHomeTab();
    }
  }

  Widget _buildHomeTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        // ─── Saldo Card ───
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [const Color(0xFF0D1E2A), const Color(0xFF0A1520)],
              begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white.withOpacity(0.08)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('TOTAL SALDO TERKUMPUL', style: TextStyle(
              color: Colors.white.withOpacity(0.4), fontSize: 11,
              fontFamily: 'ShareTechMono', letterSpacing: 2)),
            const SizedBox(height: 12),
            Row(children: [
              Text(_hideBalance ? 'Rp ••••••' : _fmtRp(_balance),
                style: const TextStyle(color: Colors.white,
                  fontSize: 32, fontWeight: FontWeight.bold)),
              const SizedBox(width: 12),
              GestureDetector(
                onTap: () => setState(() => _hideBalance = !_hideBalance),
                child: Icon(_hideBalance ? Icons.visibility_off_outlined
                  : Icons.visibility_outlined,
                  color: Colors.white38, size: 22)),
            ]),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(20)),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.trending_up_rounded, color: _teal, size: 14),
                const SizedBox(width: 6),
                Text('Estimasi Bulan Ini: ${_fmtRp(_totalIn)}',
                  style: TextStyle(color: Colors.white54, fontSize: 12)),
              ]),
            ),
            Divider(color: Colors.white.withOpacity(0.08), height: 24),
            Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('PEMASUKAN', style: TextStyle(color: Colors.white38,
                  fontSize: 11, fontFamily: 'ShareTechMono')),
                const SizedBox(height: 4),
                Text(_fmtRp(_totalIn), style: TextStyle(color: _green,
                  fontSize: 16, fontWeight: FontWeight.bold)),
              ])),
              Container(width: 1, height: 36, color: Colors.white.withOpacity(0.1)),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
                Text('PENGELUARAN', style: TextStyle(color: Colors.white38,
                  fontSize: 11, fontFamily: 'ShareTechMono')),
                const SizedBox(height: 4),
                Text(_fmtRp(_totalOut), style: TextStyle(color: _red,
                  fontSize: 16, fontWeight: FontWeight.bold)),
              ])),
            ]),
          ]),
        ),
        const SizedBox(height: 20),

        // ─── Quick Actions Grid ───
        GridView.count(
          crossAxisCount: 4, shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 12, mainAxisSpacing: 16,
          children: [
            _actionBtn(Icons.add_circle_rounded, 'Pemasukan', _green,
              () => _showAddSheet('Pemasukan')),
            _actionBtn(Icons.remove_circle_rounded, 'Pengeluaran', _red,
              () => _showAddSheet('Pengeluaran')),
            _actionBtn(Icons.wallet_rounded, 'Budget', const Color(0xFF00ACC1), () {}),
            _actionBtn(Icons.menu_book_rounded, 'Pinjaman', Colors.orange, () {}),
            _actionBtn(Icons.people_rounded, 'Keluarga', const Color(0xFF3949AB), () {}),
            _actionBtn(Icons.shopping_cart_rounded, 'Belanja', const Color(0xFF7B1FA2), () {}),
            _actionBtn(Icons.track_changes_rounded, 'Target Saya', const Color(0xFF00B8A9), () {}),
            _actionBtn(Icons.grid_view_rounded, 'Lainnya', Colors.grey, () {}),
          ],
        ),
        const SizedBox(height: 20),

        // ─── Target Pembelian ───
        Align(alignment: Alignment.centerLeft,
          child: Text('Target Pembelian Saya', style: TextStyle(
            color: Colors.white54, fontSize: 13))),
        const SizedBox(height: 10),
        Container(
          width: double.infinity, height: 80,
          decoration: BoxDecoration(
            color: _card, borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.white.withOpacity(0.06))),
          child: Center(child: Text('Belum ada target',
            style: TextStyle(color: Colors.white24, fontFamily: 'ShareTechMono')))),
      ]),
    );
  }

  Widget _actionBtn(IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(children: [
        Container(width: 52, height: 52,
          decoration: BoxDecoration(
            color: color.withOpacity(0.15),
            borderRadius: BorderRadius.circular(14)),
          child: Icon(icon, color: color, size: 24)),
        const SizedBox(height: 6),
        Text(label, style: TextStyle(color: Colors.white54, fontSize: 10),
          textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis),
      ]),
    );
  }

  Widget _buildKeuanganTab() {
    return const Center(child: Text('Keuangan', style: TextStyle(color: Colors.white54)));
  }

  Widget _buildKalkulatorTab() {
    return Column(children: [
      // Display
      Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          if (_calcExpression.isNotEmpty)
            Text(_calcExpression, style: TextStyle(color: Colors.white38, fontSize: 16)),
          Text(_calcDisplay, style: const TextStyle(color: Colors.white,
            fontSize: 52, fontWeight: FontWeight.w300)),
        ]),
      ),
      const Divider(color: Colors.white12),
      // Buttons
      Expanded(child: GridView.count(
        crossAxisCount: 4, padding: const EdgeInsets.all(12),
        crossAxisSpacing: 10, mainAxisSpacing: 10,
        children: [
          _calcBtn('AC', Colors.white70, const Color(0xFF1A2030)),
          _calcBtn('+/-', Colors.white70, const Color(0xFF1A2030)),
          _calcBtn('%', Colors.white70, const Color(0xFF1A2030)),
          _calcBtn('÷', Colors.white, const Color(0xFF0D3030)),
          _calcBtn('7'), _calcBtn('8'), _calcBtn('9'),
          _calcBtn('×', Colors.white, const Color(0xFF0D3030)),
          _calcBtn('4'), _calcBtn('5'), _calcBtn('6'),
          _calcBtn('-', Colors.white, const Color(0xFF0D3030)),
          _calcBtn('1'), _calcBtn('2'), _calcBtn('3'),
          _calcBtn('+', Colors.white, const Color(0xFF0D3030)),
          _calcBtn('C'), _calcBtn('0'), _calcBtn(','),
          _calcBtn('=', Colors.black, _teal),
        ],
      )),
    ]);
  }

  Widget _calcBtn(String label, [Color? textColor, Color? bgColor]) {
    return GestureDetector(
      onTap: () => _calcInput(label),
      child: Container(
        decoration: BoxDecoration(
          color: bgColor ?? const Color(0xFF141E2A),
          borderRadius: BorderRadius.circular(14)),
        child: Center(child: Text(label,
          style: TextStyle(color: textColor ?? Colors.white,
            fontSize: 22, fontWeight: FontWeight.w400))),
      ),
    );
  }

  Widget _buildRiwayatTab() {
    return _history.isEmpty
      ? const Center(child: Text('Belum ada transaksi',
          style: TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono')))
      : ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: _history.length,
          itemBuilder: (ctx, i) {
            final e = _history[i];
            final isIn = e['type'] == 'Pemasukan';
            final dt = DateTime.tryParse(e['date'] ?? '') ?? DateTime.now();
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _card, borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white.withOpacity(0.06))),
              child: Row(children: [
                Container(width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: (isIn ? _green : _red).withOpacity(0.15),
                    shape: BoxShape.circle),
                  child: Icon(isIn ? Icons.arrow_upward_rounded : Icons.arrow_downward_rounded,
                    color: isIn ? _green : _red, size: 20)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(e['note'] ?? '-', style: const TextStyle(color: Colors.white, fontSize: 14)),
                  Text('${dt.day}/${dt.month}/${dt.year}  ${e['category'] ?? ''}',
                    style: const TextStyle(color: Colors.white38, fontSize: 11)),
                ])),
                Text('${isIn ? '+' : '-'}${_fmtRp(e['amount'] as int)}',
                  style: TextStyle(color: isIn ? _green : _red,
                    fontWeight: FontWeight.bold, fontSize: 14)),
              ]),
            );
          });
  }

  Widget _buildProfilTab() {
    return const Center(child: Text('Profil', style: TextStyle(color: Colors.white54)));
  }

  Widget _buildBottomNav() {
    final items = [
      {'icon': Icons.home_rounded, 'label': 'Tabunganku'},
      {'icon': Icons.wallet_rounded, 'label': 'Keuangan'},
      {'icon': Icons.calculate_rounded, 'label': 'Kalkulator'},
      {'icon': Icons.receipt_long_rounded, 'label': 'Riwayat'},
      {'icon': Icons.person_rounded, 'label': 'Profil'},
    ];
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: _card,
        border: Border(top: BorderSide(color: Colors.white.withOpacity(0.06)))),
      child: Row(children: List.generate(items.length, (i) {
        final active = _selectedTab == i;
        final isCalc = i == 2;
        return Expanded(child: GestureDetector(
          onTap: () => setState(() => _selectedTab = i),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: isCalc ? 52 : 36,
              height: isCalc ? 52 : 36,
              decoration: BoxDecoration(
                color: isCalc
                  ? _teal
                  : active ? _teal.withOpacity(0.15) : Colors.transparent,
                shape: BoxShape.circle),
              child: Icon(items[i]['icon'] as IconData,
                color: isCalc ? Colors.black
                  : active ? _teal : Colors.white38,
                size: isCalc ? 26 : 20)),
            const SizedBox(height: 4),
            Text(items[i]['label'] as String,
              style: TextStyle(
                color: active ? _teal : Colors.white38,
                fontSize: 10,
                fontFamily: 'ShareTechMono')),
          ]),
        ));
      })),
    );
  }
}
