import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:video_player/video_player.dart';
import 'dart:ui';
import 'maintenance_page.dart';

const String baseUrl = "http://olinncntk.twinofc.my.id:1202";

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  bool isLoading = false;
  String? androidId;
  bool _isObscure = true;

  // ─── FITUR BARU: Remember me ───
  bool _rememberMe = false;

  late VideoPlayerController _videoController;
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // ─── WARNA TEMA ───
  final Color tealPrimary = const Color(0xFF00E5CC);
  final Color darkBg = const Color(0xFF0A0E1A);
  final Color cardBg = const Color(0xFF131929);

  @override
  void initState() {
    super.initState();
    initLogin();

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _slideController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic),
    );

    _fadeController.forward();
    _slideController.forward();

    _videoController = VideoPlayerController.asset('assets/videos/login.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController.setLooping(true);
        _videoController.play();
        _videoController.setVolume(0);
      });

    // ─── FITUR BARU: Load saved remember me preference ───
    _loadRememberMe();
  }

  Future<void> _loadRememberMe() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _rememberMe = prefs.getBool('remember_me') ?? false;
      if (_rememberMe) {
        userController.text = prefs.getString('saved_username') ?? '';
      }
    });
  }

  @override
  void dispose() {
    _videoController.dispose();
    _fadeController.dispose();
    _slideController.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  Future<void> initLogin() async {
    androidId = await getAndroidId();

    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
        "$baseUrl/api/auth/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey",
      );
      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);

        if (data['valid'] == true) {
          Navigator.pushReplacementNamed(
            context,
            '/splash',
            arguments: {
              'username': savedUser,
              'password': savedPass,
              'role': data['role'],
              'key': data['key'],
              'expiredDate': data['expiredDate'],
              'listBug': data['listBug'] ?? [],
              'listPayload': data['listPayload'] ?? [],
              'listDDoS': data['listDDoS'] ?? [],
              'news': data['news'] ?? [],
            },
          );
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id ?? "unknown_device";
  }

  Future<void> login() async {
    final username = userController.text.trim();
    final password = passController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      _showAlert("⚠️ Error", "Username and password are required.");
      return;
    }

    setState(() => isLoading = true);

    // ─── CEK MAINTENANCE ───
    final maintenance = await MaintenanceChecker.check();
    if (maintenance['isMaintenance'] == true) {
      setState(() => isLoading = false);
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => MaintenancePage(
              message: maintenance['message'] ?? '',
              estimatedTime: maintenance['estimatedTime'] ?? '',
              onRetry: () => Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => const LoginPage()),
              ),
            ),
          ),
        );
      }
      return;
    }

    try {
      final validate = await http.post(
        Uri.parse("$baseUrl/api/auth/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      );

      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        _showAlert("⛔ Access Expired",
            "Your access has expired.\nPlease renew it.",
            showContact: true);
      } else if (validData['valid'] != true) {
        _showAlert("🚫 Login Failed",
            "Invalid username or password.",
            showContact: true);
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);

        // ─── FITUR BARU: Save remember me ───
        if (_rememberMe) {
          prefs.setBool('remember_me', true);
          prefs.setString('saved_username', username);
        } else {
          prefs.remove('remember_me');
          prefs.remove('saved_username');
        }

        Navigator.pushNamed(
          context,
          '/splash',
          arguments: {
            'username': username,
            'password': password,
            'role': validData['role'],
            'key': validData['key'],
            'expiredDate': validData['expiredDate'],
            'listBug': validData['listBug'] ?? [],
            'listPayload': validData['listPayload'] ?? [],
            'listDDoS': validData['listDDoS'] ?? [],
            'news': validData['news'] ?? [],
          },
        );
      }
    } catch (_) {
      _showAlert("🌐 Connection Error", "Failed to connect to the server.");
    }

    setState(() => isLoading = false);
  }

  void _showAlert(String title, String msg, {bool showContact = false}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1E1E1E),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                title.contains("Error") || title.contains("Failed")
                    ? Icons.error_outline
                    : title.contains("Expired")
                        ? Icons.timer_off
                        : Icons.info_outline,
                color: title.contains("Error") || title.contains("Failed")
                    ? Colors.redAccent
                    : title.contains("Expired")
                        ? Colors.amber
                        : const Color(0xFF00E5CC),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
            ),
          ],
        ),
        content: Text(
          msg,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 14,
            fontFamily: 'ShareTechMono',
          ),
        ),
        actions: [
          if (showContact)
            TextButton.icon(
              onPressed: () async {
                final uri = Uri.parse("tg://resolve?domain=RaldzzXyz");
                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri,
                      mode: LaunchMode.externalApplication);
                } else {
                  await launchUrl(Uri.parse("https://t.me/mizukisnji"),
                      mode: LaunchMode.externalApplication);
                }
              },
              icon: const Icon(Icons.message, size: 18),
              label: const Text(
                "Contact Admin",
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                ),
              ),
              style: TextButton.styleFrom(
                backgroundColor:
                    const Color(0xFF00E5CC).withOpacity(0.2),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8)),
              ),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              backgroundColor: Colors.white.withOpacity(0.1),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
            ),
            child: const Text(
              "CLOSE",
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: darkBg,
      body: Stack(
        children: [
          // ─── BACKGROUND ───
          Positioned.fill(
            child: CustomPaint(painter: _LoginBgPainter()),
          ),
          // ─── GLOW CIRCLES ───
          Positioned(
              top: -100,
              left: -60,
              child: Container(
                  width: 300,
                  height: 300,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(colors: [
                        tealPrimary.withOpacity(0.06),
                        Colors.transparent
                      ])))),
          Positioned(
              bottom: -120,
              right: -80,
              child: Container(
                  width: 340,
                  height: 340,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(colors: [
                        tealPrimary.withOpacity(0.05),
                        Colors.transparent
                      ])))),
          // ─── MAIN CONTENT ───
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
                child: FadeTransition(
                  opacity: _fadeAnimation,
                  child: SlideTransition(
                    position: _slideAnimation,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // ─── LOGO ───
                        Container(
                          width: 100,
                          height: 100,
                          decoration: BoxDecoration(
                            color: const Color(0xFF1A1F2E),
                            shape: BoxShape.circle,
                            border: Border.all(
                                color: tealPrimary.withOpacity(0.3), width: 2),
                            boxShadow: [
                              BoxShadow(
                                color: tealPrimary.withOpacity(0.15),
                                blurRadius: 20,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: ClipOval(
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Image.asset('assets/images/logo.png',
                                  fit: BoxFit.contain),
                            ),
                          ),
                        ),
                        const SizedBox(height: 22),
                        ShaderMask(
                          shaderCallback: (bounds) => LinearGradient(
                                  colors: [Colors.white, tealPrimary])
                              .createShader(bounds),
                          child: const Text("TANIX",
                              style: TextStyle(
                                  fontSize: 32,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 6,
                                  color: Colors.white,
                                  fontFamily: 'Orbitron')),
                        ),
                        const SizedBox(height: 8),
                        Text("Silahkan Login",
                            style: TextStyle(
                                color: Colors.white.withOpacity(0.45),
                                fontSize: 13,
                                letterSpacing: 3,
                                fontFamily: 'ShareTechMono')),
                        const SizedBox(height: 36),
                        // ─── LOGIN CARD ───
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(
                                color: Colors.white.withOpacity(0.07)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text("Welcome back",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 4),
                              Text("Masukkan Akunmu",
                                  style: TextStyle(
                                      color: Colors.white.withOpacity(0.45),
                                      fontSize: 13)),
                              const SizedBox(height: 24),
                              _neonInput("Username", userController,
                                  Icons.person_outline_rounded),
                              const SizedBox(height: 14),
                              _neonInput("Password", passController,
                                  Icons.lock_outline_rounded,
                                  isPassword: true),
                              const SizedBox(height: 12),
                              // ─── FITUR BARU: Remember Me Toggle ───
                              Row(
                                children: [
                                  GestureDetector(
                                    onTap: () => setState(
                                        () => _rememberMe = !_rememberMe),
                                    child: Container(
                                      width: 20,
                                      height: 20,
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(5),
                                        border: Border.all(
                                          color: _rememberMe
                                              ? tealPrimary
                                              : Colors.white30,
                                          width: 1.5,
                                        ),
                                        color: _rememberMe
                                            ? tealPrimary.withOpacity(0.2)
                                            : Colors.transparent,
                                      ),
                                      child: _rememberMe
                                          ? Icon(Icons.check,
                                              color: tealPrimary, size: 14)
                                          : null,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    "Remember me",
                                    style: TextStyle(
                                      color: Colors.white.withOpacity(0.5),
                                      fontSize: 13,
                                      fontFamily: 'ShareTechMono',
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 20),
                              // ─── SIGN IN BUTTON ───
                              GestureDetector(
                                onTap: isLoading ? null : login,
                                child: Container(
                                  width: double.infinity,
                                  height: 54,
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                        color: tealPrimary, width: 1.5),
                                    borderRadius: BorderRadius.circular(14),
                                    gradient: LinearGradient(
                                      colors: [
                                        tealPrimary.withOpacity(0.15),
                                        tealPrimary.withOpacity(0.05),
                                      ],
                                    ),
                                  ),
                                  child: Center(
                                    child: isLoading
                                        ? SizedBox(
                                            width: 22,
                                            height: 22,
                                            child: CircularProgressIndicator(
                                                color: tealPrimary,
                                                strokeWidth: 2.5))
                                        : Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Text("SIGN IN",
                                                  style: TextStyle(
                                                      color: tealPrimary,
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      letterSpacing: 3,
                                                      fontFamily:
                                                          'Orbitron')),
                                              const SizedBox(width: 10),
                                              Icon(
                                                  Icons
                                                      .arrow_forward_rounded,
                                                  color: tealPrimary,
                                                  size: 18),
                                            ],
                                          ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        // ── Beli Akun Button ──
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            onPressed: () async {
                              final url = Uri.parse('https://t.me/RaldzzXyzo');
                              if (await canLaunchUrl(url)) {
                                await launchUrl(url, mode: LaunchMode.externalApplication);
                              } else {
                                await launchUrl(Uri.parse('https://t.me/RaldzzXyzo'), mode: LaunchMode.platformDefault);
                              }
                            },
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(0xFF00E5CC),
                              side: const BorderSide(color: Color(0xFF00E5CC), width: 1.5),
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                              backgroundColor: const Color(0xFF00E5CC).withOpacity(0.05),
                            ),
                            icon: const Icon(Icons.shopping_cart_rounded, size: 18),
                            label: const Text("BELI AKUN",
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 3,
                              )),
                          ),
                        ),
                        const SizedBox(height: 24),
                        Row(
                          children: [
                            Expanded(
                                child: Divider(
                                    color: Colors.white.withOpacity(0.12))),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 14),
                              child: Text("TANIX TEAM",
                                  style: TextStyle(
                                      color: Colors.white.withOpacity(0.3),
                                      fontSize: 11,
                                      letterSpacing: 2,
                                      fontFamily: 'ShareTechMono')),
                            ),
                            Expanded(
                                child: Divider(
                                    color: Colors.white.withOpacity(0.12))),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Text("v2.0.13 | © 2026",
                            style: TextStyle(
                                color: Colors.white.withOpacity(0.25),
                                fontSize: 12,
                                letterSpacing: 1)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _neonInput(String hint, TextEditingController controller, IconData icon,
      {bool isPassword = false}) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF0D1321),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: TextField(
        controller: controller,
        obscureText: isPassword ? _isObscure : false,
        style: const TextStyle(color: Colors.white, fontSize: 15),
        cursorColor: const Color(0xFF00E5CC),
        decoration: InputDecoration(
          prefixIcon: Icon(icon,
              color: Colors.white.withOpacity(0.45), size: 20),
          suffixIcon: isPassword
              ? IconButton(
                  icon: Icon(
                      _isObscure
                          ? Icons.visibility_off_outlined
                          : Icons.visibility_outlined,
                      color: Colors.white.withOpacity(0.35),
                      size: 20),
                  onPressed: () => setState(() => _isObscure = !_isObscure),
                )
              : null,
          hintText: hint,
          hintStyle:
              TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 14),
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(13),
              borderSide: BorderSide.none),
          focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(13),
              borderSide: BorderSide(
                  color: tealPrimary.withOpacity(0.4), width: 1)),
          contentPadding:
              const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
        ),
      ),
    );
  }
}


// ── TANIX Login Background Painter ──
class _LoginBgPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final bgPaint = Paint();
    final bgRect = Rect.fromLTWH(0, 0, size.width, size.height);
    bgPaint.shader = const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xFF060B14), Color(0xFF071520), Color(0xFF060B14)],
    ).createShader(bgRect);
    canvas.drawRect(bgRect, bgPaint);

    final glowPaint = Paint()..style = PaintingStyle.fill;
    final linePaint = Paint()..style = PaintingStyle.stroke..strokeWidth = 1;

    final glows = [
      [size.width * 0.1,  size.height * 0.1,  200.0, 0xFF00BCD4, 0.08],
      [size.width * 0.9,  size.height * 0.3,  240.0, 0xFF007B8A, 0.06],
      [size.width * 0.5,  size.height * 0.6,  280.0, 0xFF00BCD4, 0.05],
      [size.width * 0.15, size.height * 0.85, 160.0, 0xFF007B8A, 0.06],
      [size.width * 0.85, size.height * 0.9,  200.0, 0xFF00BCD4, 0.07],
    ];
    for (final g in glows) {
      final center = Offset(g[0] as double, g[1] as double);
      final radius = g[2] as double;
      final color = Color(g[3] as int);
      glowPaint.shader = RadialGradient(
        colors: [color.withOpacity(g[4] as double), Colors.transparent],
      ).createShader(Rect.fromCircle(center: center, radius: radius));
      canvas.drawCircle(center, radius, glowPaint);
    }

    linePaint.color = const Color(0xFF00BCD4).withOpacity(0.06);
    for (int i = 0; i < 7; i++) {
      canvas.drawLine(Offset(0, size.height * i / 6), Offset(size.width, size.height * i / 6), linePaint);
    }
    for (int i = 0; i < 5; i++) {
      canvas.drawLine(Offset(size.width * i / 4, 0), Offset(size.width * i / 4, size.height), linePaint);
    }
  }
  @override
  bool shouldRepaint(_LoginBgPainter old) => false;
}
