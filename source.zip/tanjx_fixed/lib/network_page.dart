import 'package:flutter/material.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'spam_ngl.dart';

class NetworkMenuPage extends StatelessWidget {
  final String sessionKey;
  const NetworkMenuPage({super.key, required this.sessionKey});

  static const Color _bg = Color(0xFF060B14);
  static const Color _card = Color(0xFF0D1B2A);
  static const Color _cyan = Color(0xFF00E5CC);
  static const Color _border = Color(0xFF1A2E3A);

  @override
  Widget build(BuildContext context) {
    final tools = [
      {'label': 'WiFi Info', 'desc': 'Scan jaringan WiFi sekitar', 'icon': Icons.wifi_find_rounded, 'color': const Color(0xFF00B8A9)},
      {'label': 'WiFi Killer', 'desc': 'Disconnect device dari WiFi', 'icon': Icons.wifi_off_rounded, 'color': const Color(0xFFFF5722)},
      {'label': 'Spam NGL', 'desc': 'Spam anonymous NGL link', 'icon': Icons.send_rounded, 'color': const Color(0xFF9C27B0)},
    ];
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white), onPressed: () => Navigator.pop(context)),
        title: const Text('NETWORK', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 2)),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(color: _border, height: 1)),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: tools.length,
        itemBuilder: (ctx, i) {
          final t = tools[i];
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _border)),
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              leading: Container(
                width: 48, height: 48,
                decoration: BoxDecoration(color: (t['color'] as Color).withAlpha(30), borderRadius: BorderRadius.circular(12)),
                child: Icon(t['icon'] as IconData, color: t['color'] as Color, size: 24),
              ),
              title: Text(t['label'] as String, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              subtitle: Text(t['desc'] as String, style: TextStyle(color: Colors.white.withAlpha(120), fontSize: 12)),
              trailing: const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white38, size: 14),
              onTap: () {
                Widget page;
                switch (t['label']) {
                  case 'WiFi Info': page = WifiInternalPage(sessionKey: sessionKey); break;
                  case 'WiFi Killer': page = const WifiKillerPage(); break;
                  case 'Spam NGL': page = const NglPage(); break;
                  default: return;
                }
                Navigator.push(context, MaterialPageRoute(builder: (_) => page));
              },
            ),
          );
        },
      ),
    );
  }
}
