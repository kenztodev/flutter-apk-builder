import 'package:flutter/material.dart';
import 'nik_check_page.dart';
import 'phone_lookup.dart';
import 'subdomain_finder_page.dart';
import 'nik_parse.dart';

class OsintMenuPage extends StatelessWidget {
  final String sessionKey;
  const OsintMenuPage({super.key, required this.sessionKey});

  static const Color _bg = Color(0xFF060B14);
  static const Color _card = Color(0xFF0D1B2A);
  static const Color _border = Color(0xFF1A2E3A);

  @override
  Widget build(BuildContext context) {
    final tools = [
      {'label': 'NIK Check', 'desc': 'Cek data NIK KTP', 'icon': Icons.badge_rounded, 'color': const Color(0xFF00B8A9)},
      {'label': 'NIK Parse', 'desc': 'Parse informasi dari NIK', 'icon': Icons.manage_search_rounded, 'color': const Color(0xFF795548)},
      {'label': 'Phone Lookup', 'desc': 'Cek informasi nomor telepon', 'icon': Icons.phone_rounded, 'color': const Color(0xFF4CAF50)},
      {'label': 'Subdomain', 'desc': 'Cari subdomain dari domain', 'icon': Icons.language_rounded, 'color': const Color(0xFF9C27B0)},
    ];
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white), onPressed: () => Navigator.pop(context)),
        title: const Text('OSINT', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 2)),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(color: _border, height: 1)),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: tools.length,
        itemBuilder: (ctx, i) {
          final t = tools[i];
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _border)),
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              leading: Container(
                width: 48, height: 48,
                decoration: BoxDecoration(color: (t['color'] as Color).withAlpha(30), borderRadius: BorderRadius.circular(12)),
                child: Icon(t['icon'] as IconData, color: t['color'] as Color, size: 24),
              ),
              title: Text(t['label'] as String, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              subtitle: Text(t['desc'] as String, style: TextStyle(color: Colors.white.withAlpha(120), fontSize: 12)),
              trailing: const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white38, size: 14),
              onTap: () {
                Widget page;
                switch (t['label']) {
                  case 'NIK Check': page = NIKCheckPage(sessionKey: sessionKey); break;
                  case 'NIK Parse': page = const NikParsePage(); break;
                  case 'Phone Lookup': page = PhoneLookupPage(sessionKey: sessionKey); break;
                  case 'Subdomain': page = SubdomainFinderPage(sessionKey: sessionKey); break;
                  default: return;
                }
                Navigator.push(context, MaterialPageRoute(builder: (_) => page));
              },
            ),
          );
        },
      ),
    );
  }
}
