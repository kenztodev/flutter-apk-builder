import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:web_socket_channel/io.dart';

class ChatPage extends StatefulWidget {
  final String sessionKey;
  const ChatPage({super.key, required this.sessionKey});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> with TickerProviderStateMixin {
  static const Color _bg = Color(0xFF0A0D1A);
  static const Color _card = Color(0xFF141828);
  static const Color _card2 = Color(0xFF1A2035);
  static const Color _teal = Color(0xFF00BCD4);
  static const Color _border = Color(0xFF1E2540);
  static const Color _bubbleSelf = Color(0xFF1A3040);
  static const Color _bubbleOther = Color(0xFF13192B);

  late IOWebSocketChannel channel;
  List<String> chatUsers = [];
  String? selectedUser;
  List<Map<String, dynamic>> messages = [];
  final TextEditingController messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  Map<String, dynamic>? _replyTo;
  bool _showEmojiPicker = false;
  bool _isConnected = false;

  late AnimationController _fadeController;
  late Animation<double> _fadeAnim;

  final List<String> _quickEmojis = [
    '😀','😁','😂','🤣','😊','😍',
    '😎','🤔','😢','😮','🥳','😡',
    '🔥','✨','🎉','❤️','👍','🙏',
    '👏','🍞','💯','☕','🌙','💀',
  ];

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _fadeAnim = CurvedAnimation(parent: _fadeController, curve: Curves.easeIn);
    _fadeController.forward();
    _connectWs();
  }

  void _connectWs() {
    try {
      channel = IOWebSocketChannel.connect('wss://ws.nullxteam.fun');
      channel.sink.add(jsonEncode({"type": "auth", "key": widget.sessionKey}));
      setState(() => _isConnected = true);
      channel.stream.listen((event) {
        final data = jsonDecode(event);
        switch (data['type']) {
          case 'chatList':
            setState(() => chatUsers = List<String>.from(data['users']));
            break;
          case 'chat':
            if (selectedUser == data['message']['from'] || selectedUser == data['message']['to']) {
              setState(() => messages.add(Map<String, dynamic>.from(data['message'])));
              _scrollToBottom();
            }
            break;
          case 'messages':
            setState(() => messages = List<Map<String, dynamic>>.from(data['messages']));
            _scrollToBottom();
            break;
        }
      }, onError: (_) => setState(() => _isConnected = false));
    } catch (_) {
      setState(() => _isConnected = false);
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _loadMessages(String user) {
    setState(() { selectedUser = user; messages.clear(); _replyTo = null; });
    channel.sink.add(jsonEncode({"type": "getMessages", "with": user}));
  }

  void _sendMessage([String? override]) {
    final msg = override ?? messageController.text.trim();
    if (msg.isEmpty || selectedUser == null) return;
    final payload = <String, dynamic>{"type": "chat", "to": selectedUser, "message": msg};
    if (_replyTo != null) payload['reply'] = _replyTo;
    channel.sink.add(jsonEncode(payload));
    messageController.clear();
    setState(() { _replyTo = null; _showEmojiPicker = false; });
  }

  void _startNewChat() {
    String newUser = '';
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text("Chat Baru", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        content: TextField(
          onChanged: (v) => newUser = v,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: "Masukkan username...",
            hintStyle: const TextStyle(color: Colors.white38),
            filled: true,
            fillColor: _card2,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Batal", style: TextStyle(color: Colors.white38))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: _teal, foregroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () {
              Navigator.pop(context);
              if (newUser.trim().isNotEmpty && !chatUsers.contains(newUser.trim())) {
                setState(() => chatUsers.add(newUser.trim()));
              }
              _loadMessages(newUser.trim());
            },
            child: const Text("Mulai", style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    channel.sink.close();
    messageController.dispose();
    _scrollController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fadeAnim,
      child: Scaffold(
        backgroundColor: _bg,
        body: selectedUser == null ? _buildChatList() : _buildChatScreen(),
      ),
    );
  }

  Widget _buildChatList() {
    return Column(
      children: [
        _buildListHeader(),
        Expanded(
          child: chatUsers.isEmpty
              ? _buildEmptyState()
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  itemCount: chatUsers.length,
                  itemBuilder: (ctx, i) {
                    final user = chatUsers[i];
                    final initials = user.isNotEmpty ? user[0].toUpperCase() : '?';
                    final colors = [_teal, const Color(0xFF9C27B0), const Color(0xFF4CAF50), const Color(0xFFFF5722)];
                    final col = colors[user.hashCode % colors.length];
                    return GestureDetector(
                      onTap: () => _loadMessages(user),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        decoration: BoxDecoration(
                          color: _card,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: _border),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 46, height: 46,
                              decoration: BoxDecoration(color: col.withOpacity(0.2), borderRadius: BorderRadius.circular(14), border: Border.all(color: col.withOpacity(0.5))),
                              child: Center(child: Text(initials, style: TextStyle(color: col, fontWeight: FontWeight.bold, fontSize: 18))),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(user, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                                const SizedBox(height: 3),
                                const Text("Tap untuk membuka chat", style: TextStyle(color: Colors.white38, fontSize: 12)),
                              ]),
                            ),
                            const Icon(Icons.chevron_right_rounded, color: Colors.white24),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildListHeader() {
    return Container(
      padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 12, left: 16, right: 16, bottom: 12),
      decoration: BoxDecoration(color: _card, border: Border(bottom: BorderSide(color: _border))),
      child: Row(
        children: [
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(color: _teal.withOpacity(0.15), borderRadius: BorderRadius.circular(12), border: Border.all(color: _teal.withOpacity(0.3))),
            child: const Icon(Icons.forum_rounded, color: _teal, size: 22),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text("Room Nongkrong", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
              Text("Chat dengan sesama user", style: TextStyle(color: Colors.white38, fontSize: 12)),
            ]),
          ),
          Row(
            children: [
              Container(
                width: 8, height: 8,
                decoration: BoxDecoration(
                  color: _isConnected ? Colors.greenAccent : Colors.redAccent,
                  shape: BoxShape.circle,
                  boxShadow: [BoxShadow(color: (_isConnected ? Colors.greenAccent : Colors.redAccent).withOpacity(0.5), blurRadius: 6)],
                ),
              ),
              const SizedBox(width: 12),
              GestureDetector(
                onTap: _startNewChat,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(color: _teal.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
                  child: const Icon(Icons.add_comment_rounded, color: _teal, size: 20),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80, height: 80,
            decoration: BoxDecoration(color: _teal.withOpacity(0.1), shape: BoxShape.circle, border: Border.all(color: _teal.withOpacity(0.2))),
            child: const Icon(Icons.chat_bubble_outline_rounded, color: _teal, size: 36),
          ),
          const SizedBox(height: 16),
          const Text("Belum ada chat", style: TextStyle(color: Colors.white70, fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          const Text("Tap + untuk mulai chat baru", style: TextStyle(color: Colors.white38, fontSize: 13)),
        ],
      ),
    );
  }

  Widget _buildChatScreen() {
    return Column(
      children: [
        _buildChatHeader(),
        Expanded(child: _buildMessageList()),
        if (_replyTo != null) _buildReplyPreview(),
        if (_showEmojiPicker) _buildEmojiPicker(),
        _buildInputBar(),
      ],
    );
  }

  Widget _buildChatHeader() {
    final initials = selectedUser!.isNotEmpty ? selectedUser![0].toUpperCase() : '?';
    return Container(
      padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 8, left: 8, right: 16, bottom: 10),
      decoration: BoxDecoration(
        color: _card,
        border: Border(bottom: BorderSide(color: _border)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 2))],
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 18),
            onPressed: () => setState(() { selectedUser = null; messages.clear(); _replyTo = null; }),
          ),
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(color: _teal.withOpacity(0.2), borderRadius: BorderRadius.circular(12), border: Border.all(color: _teal.withOpacity(0.4))),
            child: Center(child: Text(initials, style: const TextStyle(color: _teal, fontWeight: FontWeight.bold, fontSize: 18))),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(selectedUser!, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
              Text("Halo, ${selectedUser!.split('').first.toUpperCase()}${selectedUser!.substring(1)}!", style: const TextStyle(color: _teal, fontSize: 11)),
            ]),
          ),
          GestureDetector(
            onTap: () => showDialog(
              context: context,
              builder: (_) => AlertDialog(
                backgroundColor: _card,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                title: Text(selectedUser!, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                content: Text("Total pesan: ${messages.length}", style: const TextStyle(color: Colors.white60)),
                actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text("Tutup", style: TextStyle(color: _teal)))],
              ),
            ),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: _card2, borderRadius: BorderRadius.circular(10), border: Border.all(color: _border)),
              child: const Icon(Icons.info_outline_rounded, color: Colors.white54, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageList() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF080C18), Color(0xFF0A0D1A)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: ListView.builder(
        controller: _scrollController,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        itemCount: messages.length,
        itemBuilder: (ctx, i) {
          final msg = messages[i];
          final isMine = msg['from'] == 'me' || msg['self'] == true;
          return _buildBubble(msg, isMine, i);
        },
      ),
    );
  }

  Widget _buildBubble(Map<String, dynamic> msg, bool isMine, int index) {
    final prevMsg = index > 0 ? messages[index - 1] : null;
    final prevSender = prevMsg?['from'];
    final showName = !isMine && msg['from'] != prevSender;

    return GestureDetector(
      onLongPress: () {
        HapticFeedback.mediumImpact();
        setState(() => _replyTo = msg);
      },
      child: Align(
        alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          margin: EdgeInsets.only(bottom: 6, top: showName ? 10 : 2),
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              if (!isMine) ...[
                Container(
                  width: 32, height: 32,
                  margin: const EdgeInsets.only(right: 8),
                  decoration: BoxDecoration(color: _teal.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
                  child: Center(child: Text(
                    (msg['from'] ?? '?')[0].toUpperCase(),
                    style: const TextStyle(color: _teal, fontWeight: FontWeight.bold, fontSize: 13),
                  )),
                ),
              ],
              Flexible(
                child: Column(
                  crossAxisAlignment: isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                  children: [
                    if (showName && !isMine)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 4, left: 4),
                        child: Text(msg['from'] ?? '', style: const TextStyle(color: _teal, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                      ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: isMine ? _bubbleSelf : _bubbleOther,
                        borderRadius: BorderRadius.only(
                          topLeft: const Radius.circular(18),
                          topRight: const Radius.circular(18),
                          bottomLeft: Radius.circular(isMine ? 18 : 4),
                          bottomRight: Radius.circular(isMine ? 4 : 18),
                        ),
                        border: Border.all(color: isMine ? _teal.withOpacity(0.2) : _border),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (msg['reply'] != null)
                            Container(
                              margin: const EdgeInsets.only(bottom: 8),
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.05),
                                borderRadius: BorderRadius.circular(8),
                                border: const Border(left: BorderSide(color: _teal, width: 3)),
                              ),
                              child: Text(
                                msg['reply']['message'] ?? '',
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(color: Colors.white54, fontSize: 11),
                              ),
                            ),
                          Text(msg['message'] ?? '', style: const TextStyle(color: Colors.white, fontSize: 13, height: 1.4)),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 3, left: 4, right: 4),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.reply_rounded, color: Colors.white24, size: 12),
                          const SizedBox(width: 4),
                          Text(msg['time'] ?? '', style: const TextStyle(color: Colors.white30, fontSize: 10)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildReplyPreview() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(color: _card2, border: Border(top: BorderSide(color: _border))),
      child: Row(
        children: [
          Container(width: 3, height: 36, color: _teal, margin: const EdgeInsets.only(right: 10)),
          const Icon(Icons.reply_rounded, color: _teal, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text("Membalas pesan", style: TextStyle(color: _teal, fontSize: 11, fontWeight: FontWeight.bold)),
              Text(_replyTo!['message'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white60, fontSize: 12)),
            ]),
          ),
          GestureDetector(
            onTap: () => setState(() => _replyTo = null),
            child: const Icon(Icons.close_rounded, color: Colors.white38, size: 20),
          ),
        ],
      ),
    );
  }

  Widget _buildEmojiPicker() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        border: Border(top: BorderSide(color: _border)),
      ),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: _quickEmojis.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 6, mainAxisSpacing: 6, crossAxisSpacing: 6, childAspectRatio: 1),
        itemBuilder: (ctx, i) => GestureDetector(
          onTap: () => _sendMessage(_quickEmojis[i]),
          child: Container(
            decoration: BoxDecoration(color: _card2, borderRadius: BorderRadius.circular(12)),
            child: Center(child: Text(_quickEmojis[i], style: const TextStyle(fontSize: 22))),
          ),
        ),
      ),
    );
  }

  Widget _buildInputBar() {
    return Container(
      padding: EdgeInsets.only(left: 12, right: 12, top: 10, bottom: MediaQuery.of(context).padding.bottom + 10),
      decoration: BoxDecoration(
        color: _card,
        border: Border(top: BorderSide(color: _border)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, -2))],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => setState(() => _showEmojiPicker = !_showEmojiPicker),
            child: Container(
              width: 40, height: 40,
              decoration: BoxDecoration(color: _card2, borderRadius: BorderRadius.circular(12), border: Border.all(color: _border)),
              child: Icon(_showEmojiPicker ? Icons.keyboard_rounded : Icons.sentiment_satisfied_alt_rounded, color: Colors.white54, size: 20),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () {},
            child: Container(
              width: 40, height: 40,
              decoration: BoxDecoration(color: _card2, borderRadius: BorderRadius.circular(12), border: Border.all(color: _border)),
              child: const Icon(Icons.image_rounded, color: Colors.white54, size: 20),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Container(
              decoration: BoxDecoration(color: _card2, borderRadius: BorderRadius.circular(24), border: Border.all(color: _border)),
              child: TextField(
                controller: messageController,
                style: const TextStyle(color: Colors.white, fontSize: 14),
                maxLines: null,
                maxLength: 500,
                onTap: () => setState(() => _showEmojiPicker = false),
                decoration: const InputDecoration(
                  counterText: '',
                  hintText: "Kirim Pesan....",
                  hintStyle: TextStyle(color: Colors.white30),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                ),
                onSubmitted: (_) => _sendMessage(),
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: _sendMessage,
            child: Container(
              width: 46, height: 46,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF0288D1), _teal]),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [BoxShadow(color: _teal.withOpacity(0.4), blurRadius: 10, offset: const Offset(0, 3))],
              ),
              child: const Icon(Icons.mic_rounded, color: Colors.white, size: 22),
            ),
          ),
        ],
      ),
    );
  }
}
