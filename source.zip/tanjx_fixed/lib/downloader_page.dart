import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class DownloaderPage extends StatefulWidget {
  final String sessionKey;
  const DownloaderPage({super.key, required this.sessionKey});

  @override
  State<DownloaderPage> createState() => _DownloaderPageState();
}

class _DownloaderPageState extends State<DownloaderPage> {
  static const Color _bg = Color(0xFF060B14);
  static const Color _card = Color(0xFF0D1B2A);
  static const Color _cyan = Color(0xFF00E5CC);
  static const Color _border = Color(0xFF1A2E3A);

  final _urlController = TextEditingController();
  String _selectedPlatform = 'TikTok';
  bool _isLoading = false;
  String? _resultUrl;
  String? _error;

  final _platforms = ['TikTok', 'Instagram'];

  Future<void> _download() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) return;
    setState(() { _isLoading = true; _resultUrl = null; _error = null; });
    try {
      final res = await http.post(
        Uri.parse('https://api.tanix.web.id/api/downloader'),
        headers: {'Content-Type': 'application/json', 'x-session-key': widget.sessionKey},
        body: jsonEncode({'url': url, 'platform': _selectedPlatform.toLowerCase()}),
      ).timeout(const Duration(seconds: 20));
      final data = jsonDecode(res.body);
      if (res.statusCode == 200 && data['status'] == true) {
        setState(() { _resultUrl = data['data']?['download_url'] ?? data['data']?['url']; });
      } else {
        setState(() { _error = data['message'] ?? 'Gagal mengunduh'; });
      }
    } catch (e) {
      setState(() { _error = 'Error: $e'; });
    }
    setState(() { _isLoading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white), onPressed: () => Navigator.pop(context)),
        title: const Text('DOWNLOADER', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 2)),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(color: _border, height: 1)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _border)),
            child: Row(children: [
              Container(width: 48, height: 48, decoration: BoxDecoration(color: _cyan.withAlpha(30), borderRadius: BorderRadius.circular(12)), child: Icon(Icons.download_rounded, color: _cyan, size: 24)),
              const SizedBox(width: 12),
              const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Downloader', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                Text('TikTok & Instagram tanpa watermark', style: TextStyle(color: Colors.white54, fontSize: 12)),
              ])
            ]),
          ),
          const SizedBox(height: 24),
          const Text('Platform', style: TextStyle(color: Colors.white70, fontSize: 13, letterSpacing: 1)),
          const SizedBox(height: 8),
          Row(children: _platforms.map((p) {
            final sel = p == _selectedPlatform;
            return Padding(
              padding: const EdgeInsets.only(right: 10),
              child: GestureDetector(
                onTap: () => setState(() => _selectedPlatform = p),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: BoxDecoration(
                    color: sel ? _cyan : _card,
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: sel ? _cyan : _border),
                  ),
                  child: Text(p, style: TextStyle(color: sel ? Colors.black : Colors.white, fontWeight: FontWeight.bold)),
                ),
              ),
            );
          }).toList()),
          const SizedBox(height: 20),
          const Text('URL', style: TextStyle(color: Colors.white70, fontSize: 13, letterSpacing: 1)),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(12), border: Border.all(color: _border)),
            child: TextField(
              controller: _urlController,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                hintText: 'Paste URL TikTok/Instagram...',
                hintStyle: TextStyle(color: Colors.white38),
                prefixIcon: Icon(Icons.link_rounded, color: Colors.white38),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              ),
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _isLoading ? null : _download,
              style: ElevatedButton.styleFrom(backgroundColor: _cyan, foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              icon: _isLoading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black)) : const Icon(Icons.download_rounded),
              label: Text(_isLoading ? 'Processing...' : 'DOWNLOAD', style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2)),
            ),
          ),
          if (_error != null) ...[
            const SizedBox(height: 16),
            Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.red.withAlpha(20), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.red.withAlpha(60))),
              child: Row(children: [const Icon(Icons.error_outline_rounded, color: Colors.red, size: 18), const SizedBox(width: 8), Expanded(child: Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 13)))]),
            ),
          ],
          if (_resultUrl != null) ...[
            const SizedBox(height: 16),
            Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.green.withAlpha(20), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.green.withAlpha(60))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Row(children: [Icon(Icons.check_circle_rounded, color: Colors.green, size: 18), SizedBox(width: 8), Text('Link berhasil didapat!', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold))]),
                const SizedBox(height: 10),
                GestureDetector(
                  onTap: () { Clipboard.setData(ClipboardData(text: _resultUrl!)); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('URL disalin!'))); },
                  child: Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(8)),
                    child: Row(children: [Expanded(child: Text(_resultUrl!, style: const TextStyle(color: Colors.white70, fontSize: 11))), const Icon(Icons.copy_rounded, color: Colors.white38, size: 16)]),
                  ),
                ),
              ]),
            ),
          ],
        ]),
      ),
    );
  }
}
