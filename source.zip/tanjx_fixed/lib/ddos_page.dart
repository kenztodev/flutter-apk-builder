// tools_page.dart

import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart'; // Ditambahkan untuk VideoPlayer Background
import 'chat_ai_page.dart';
import 'nik_check_page.dart';
import 'spam_ngl.dart';
import 'wifi_external.dart';
import 'wifi_internal.dart';
import 'nik_parse.dart';
import 'spams_page.dart';
import 'chat_page.dart';
import 'public_page.dart';
import 'tabungan_page.dart';
import 'ddos_panel.dart';
import 'phone_lookup.dart'; // Tambahkan import untuk PhoneLookupPage
import 'subdomain_finder_page.dart';
import 'anime.dart';
import 'network_page.dart';
import 'osint_menu_page.dart';
import 'downloader_page.dart';
import 'mantarat_page.dart';
import 'generator_page.dart';
import 'apk_builder_page.dart';
import 'device_dashboard.dart';
import 'manage_server.dart';
import 'buy_account.dart';

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late AnimationController _headerController;
  late AnimationController _listController;
  late Animation<double> _headerAnimation;
  late List<Animation<double>> _itemAnimations;

  // --- NEW: Controller untuk Video Background ---
  late VideoPlayerController _videoController;

  // Definisi Warna Tema Baru (Glowing Grey/Silver) -> Disimpan untuk referensi lama
  static const Color primaryColor = Color(0xFFE0E0E0); // Abu-abu menyala (Silver)

  @override
  void initState() {
    super.initState();
    
    // --- NEW: Inisialisasi Video Background ---
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        _videoController.setLooping(true);
        _videoController.setVolume(0.0); // Mute video background
        _videoController.play();
        setState(() {}); // Refresh UI saat video siap
      });

    _headerController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _listController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _headerAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _headerController, curve: Curves.easeOutBack),
    );

    _itemAnimations = List.generate(
      20, // Cukup untuk semua tools
      (index) => Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(
          parent: _listController,
          curve: Interval(
            (index * 0.05).clamp(0.0, 0.8),
            (0.3 + (index * 0.05)).clamp(0.1, 1.0),
            curve: Curves.easeOutBack,
          ),
        ),
      ),
    );

    _headerController.forward();
    _listController.forward();
  }

  @override
  void dispose() {
    _headerController.dispose();
    _listController.dispose();
    _videoController.dispose(); // --- NEW: Hancurkan controller video ---
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          /* --- KODE LAMA BACKGROUND SAYA KOMENTARI ---
          Container(
            decoration: const BoxDecoration(
              color: Colors.black,
            ),
          ),
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _headerController,
              builder: (context, child) {
                return Opacity(
                  opacity: _headerAnimation.value * 0.05,
                  child: CustomPaint(
                    painter: GridPatternPainter(),
                  ),
                );
              },
            ),
          ),
          ------------------------------------------ */

          // --- NEW: Video Background ---
          SizedBox.expand(
            child: _videoController.value.isInitialized
                ? FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _videoController.value.size.width,
                      height: _videoController.value.size.height,
                      child: VideoPlayer(_videoController),
                    ),
                  )
                : Container(color: Colors.black), // Hitam saat loading
          ),
          
          // Layer gelap semi-transparan agar grid menu tetap terbaca jelas
          Container(
            color: Colors.black.withOpacity(0.5), 
          ),

          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // _buildAnimatedHeader(), // --- KODE LAMA HEADER SAYA KOMENTARI ---
                _buildNewHeader(), // --- NEW HEADER ---
                const SizedBox(height: 10),
                // Expanded(child: _buildToolsList()), // --- KODE LAMA LIST SAYA KOMENTARI ---
                Expanded(child: _buildNewGridList()), // --- NEW GRID LIST ---
              ],
            ),
          ),
        ],
      ),
    );
  }

  // --- NEW HEADER BERJALAN (MARQUEE) ---
  Widget _buildNewHeader() {
    return Padding(
      padding: const EdgeInsets.only(left: 16, right: 16, top: 16, bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Info Card sesuai screenshot ──
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF0D1B2A),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF00E5CC).withOpacity(0.25)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 52, height: 52,
                      decoration: BoxDecoration(
                        color: const Color(0xFF00E5CC).withOpacity(0.12),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: const Color(0xFF00E5CC).withOpacity(0.3)),
                      ),
                      child: const Icon(Icons.apps_rounded, color: Color(0xFF00E5CC), size: 26),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("TANIX TOOLS",
                            style: TextStyle(color: Color(0xFF00E5CC), fontSize: 11, letterSpacing: 2, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 2),
                          const Text("Menu Tanix",
                            style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: const Color(0xFF9C27B0).withOpacity(0.15),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: const Color(0xFF9C27B0).withOpacity(0.4)),
                      ),
                      child: Text(
                        widget.userRole.toUpperCase(),
                        style: const TextStyle(color: Color(0xFF9C27B0), fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                const Text(
                  "Pusat akses berbagai menu aplikasi Tanix untuk kebutuhan harian Anda.",
                  style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.4),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          // ── Stats bar ──
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: const Color(0xFF0D1B2A),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFF1A2E3A)),
            ),
            child: Row(
              children: [
                _statCell("ROLE", widget.userRole.toUpperCase(), const Color(0xFF9C27B0)),
                _divider(),
                _statCell("JUMLAH MENU", "12 TOOLS", const Color(0xFF9C27B0)),
                _divider(),
                _statCell("SESSION", "READY", const Color(0xFF00E5CC), icon: Icons.phone_android_rounded),
              ],
            ),
          ),
          const SizedBox(height: 10),
          // ── Kategori header ──
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("KATEGORI MENU", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16, letterSpacing: 1)),
                  Text("Pilih kategori menu yang Anda butuhkan.", style: TextStyle(color: Colors.white38, fontSize: 11)),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(color: const Color(0xFF0D2A3A), borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFF1A2E3A))),
                child: const Text("12 Modules", style: TextStyle(color: Color(0xFF00E5CC), fontSize: 11, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
          const SizedBox(height: 4),
        ],
      ),
    );
  }

  Widget _statCell(String label, String value, Color valueColor, {IconData? icon}) {
    return Expanded(
      child: Column(
        children: [
          Text(label, style: const TextStyle(color: Colors.white30, fontSize: 9, letterSpacing: 1)),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[Icon(icon, color: valueColor, size: 10), const SizedBox(width: 3)],
              Text(value, style: TextStyle(color: valueColor, fontSize: 11, fontWeight: FontWeight.bold)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _divider() {
    return Container(width: 1, height: 28, color: const Color(0xFF1A2E3A));
  }

  // --- TOOLS GRID SESUAI SCREENSHOT ---
  Widget _buildNewGridList() {
    final newTools = [
      // Row 1
      {'icon': Icons.account_balance_wallet_rounded, 'label': 'TabunganKu', 'description': 'Finance Manager PRO', 'color': const Color(0xFF00C853)},
      {'icon': Icons.cloud_rounded, 'label': 'Hosting Tools', 'description': 'Manajemen server', 'color': const Color(0xFF00B8A9)},
      // Row 2
      {'icon': Icons.sports_esports_rounded, 'label': 'Games', 'description': 'Pacman, ular, dll', 'color': const Color(0xFF9C27B0)},
      {'icon': Icons.smart_toy_rounded, 'label': 'Ai Tools', 'description': 'Asisten, Code Fixer', 'color': const Color(0xFF00B8A9)},
      // Row 3
      {'icon': Icons.bolt_rounded, 'label': 'DDoS', 'description': 'Stress test', 'color': const Color(0xFFFF5722)},
      {'icon': Icons.wifi_rounded, 'label': 'Network', 'description': 'WiFi, spam', 'color': const Color(0xFF00B8A9)},
      // Row 4 (scroll lebih)
      {'icon': Icons.search_rounded, 'label': 'OSINT', 'description': 'NiK, domain, telepon', 'color': const Color(0xFF795548)},
      {'icon': Icons.download_rounded, 'label': 'Downloader', 'description': 'TikTok, instagram', 'color': const Color(0xFF00B8A9)},
      // Row 5
      {'icon': Icons.build_rounded, 'label': 'TANIXRAT', 'description': 'Rat Malware', 'color': const Color(0xFFFF5722)},
      {'icon': Icons.rocket_launch_rounded, 'label': 'Generator', 'description': 'Quote, fake story', 'color': const Color(0xFF9C27B0)},
      // Row 6
      {'icon': Icons.auto_awesome_rounded, 'label': 'Anime', 'description': 'Streaming, 18+', 'color': const Color(0xFF00B8A9)},
      // Row 7
      {'icon': Icons.shopping_cart_rounded, 'label': 'Beli Akun', 'description': 'Member, Reseller, VIP', 'color': const Color(0xFF4CAF50)},
    ];

    return GridView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        childAspectRatio: 0.95, // Rasio agar proporsional mirip foto
      ),
      itemCount: newTools.length,
      itemBuilder: (context, index) {
        final tool = newTools[index];
        return _buildAnimatedToolItem(
          icon: tool['icon'] as IconData,
          label: tool['label'] as String,
          description: tool['description'] as String,
          animation: _itemAnimations[index],
          color: tool['color'] as Color? ?? const Color(0xFF00E5CC),
          onTap: () => _navigateToTool(tool['label'] as String),
        );
      },
    );
  }

  // --- KODE LAMA HEADER & LIST SAYA KOMENTARI TAPI TIDAK DIHAPUS ---
  /*
  Widget _buildAnimatedHeader() {
    return AnimatedBuilder(
      animation: _headerAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, (1 - _headerAnimation.value) * 30),
          child: Opacity(
            opacity: _headerAnimation.value,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                color: Colors.black,
                border: Border.all(
                  color: primaryColor.withOpacity(0.3), // Silver opacity
                  width: 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: primaryColor.withOpacity(0.1),
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: primaryColor.withOpacity(0.15), // Silver opacity
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: primaryColor.withOpacity(0.2)),
                        ),
                        child: const Icon(Icons.apps, color: primaryColor, size: 24), // Silver
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        "Digital Tools",
                        style: TextStyle(
                          color: primaryColor, // Silver
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                          shadows: [
                            Shadow(
                              color: primaryColor,
                              blurRadius: 8,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Select a tool to begin",
                    style: TextStyle(
                      color: primaryColor.withOpacity(0.7), // Silver opacity
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildToolsList() {
    final tools = [
      {'icon': Icons.chat, 'label': 'Chat AI', 'description': 'AI-powered conversation assistant'},
      {'icon': Icons.badge, 'label': 'NIK Check', 'description': 'Validate Indonesian identity numbers'},
      {'icon': Icons.phone, 'label': 'Phone Lookup', 'description': 'Find information about phone numbers'},
      {'icon': Icons.language, 'label': 'Subdomain Finder', 'description': 'Discover subdomains of any domain'},
      {'icon': Icons.movie_filter_outlined, 'label': 'Anime', 'description': 'Tempat Nya Para Wibu Marathon Anime'},
      {'icon': Icons.wifi_rounded, 'label': 'WiFi Info', 'description': 'Cek IP Publik, VPN, dan ASN kamu'},
      {'icon': Icons.wifi_off_rounded, 'label': 'WiFi Killer', 'description': 'Scan dan putus device di WiFi lokal'},
      {'icon': Icons.message_rounded, 'label': 'Spam NGL', 'description': 'Kirim spam anonim ke username NGL'},
      {'icon': Icons.report_rounded, 'label': 'Report WA', 'description': 'Spam report WA via sender'},
      {'icon': Icons.badge, 'label': 'NIK Parse', 'description': 'Parse data dari NIK KTP (offline)'},
      {'icon': Icons.forum_rounded, 'label': 'Chat WS', 'description': 'Realtime chat via WebSocket'},
    ];

    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: tools.length,
      itemBuilder: (context, index) {
        final tool = tools[index];
        return _buildAnimatedToolItem(
          icon: tool['icon'] as IconData,
          label: tool['label'] as String,
          description: tool['description'] as String,
          animation: _itemAnimations[index],
          color: tool['color'] as Color? ?? const Color(0xFF00E5CC),
          onTap: () => _navigateToTool(tool['label'] as String),
        );
      },
    );
  }
  */

  void _navigateToTool(String toolName) {
    Widget page;
    switch (toolName) {
      case 'Chat AI':
        page = ChatAIPage(sessionKey: widget.sessionKey);
        break;
      case 'NIK Check':
        page = NIKCheckPage(sessionKey: widget.sessionKey);
        break;
      case 'Phone Lookup':
        page = PhoneLookupPage(sessionKey: widget.sessionKey);
        break;
      case 'Anime':
        page = HomeAnimePage();
        break;
      case 'Subdomain Finder':
      case 'Subdomain':
        page = SubdomainFinderPage(sessionKey: widget.sessionKey);
        break;
      case 'WiFi Info':
        page = WifiInternalPage(sessionKey: widget.sessionKey);
        break;
      case 'WiFi Killer':
        page = const WifiKillerPage();
        break;
      case 'Spam NGL':
        page = const NglPage();
        break;
      case 'Report WA':
        page = ReportWaPage(
          sessionKey: widget.sessionKey,
          username: '',
          role: widget.userRole,
        );
        break;
      case 'NIK Parse':
        page = const NikParsePage();
        break;
      case 'Chat WS':
        page = ChatPage(sessionKey: widget.sessionKey);
        break;
      case 'DDoS':
        page = AttackPanel(sessionKey: widget.sessionKey, listDDoS: const []);
        break;
      case 'Network':
        page = NetworkMenuPage(sessionKey: widget.sessionKey);
        break;
      case 'OSINT':
        page = OsintMenuPage(sessionKey: widget.sessionKey);
        break;
      case 'Downloader':
        page = DownloaderPage(sessionKey: widget.sessionKey);
        break;
      case 'TANIXRAT':
        showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.transparent,
          builder: (_) => _MantaratSheet(sessionKey: widget.sessionKey),
        );
        return;
      case 'Generator':
        showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.transparent,
          builder: (_) => _GeneratorSheet(sessionKey: widget.sessionKey),
        );
        return;
      case 'TabunganKu':
        page = const TabunganKuPage();
        break;
      case 'Games':
        page = const GamesPage();
        break;
      case 'Ai Tools':
        page = ChatAIPage(sessionKey: widget.sessionKey);
        break;
      case 'Hosting Tools':
        page = ManageServerPage(sessionKey: widget.sessionKey);
        break;
      case 'Beli Akun':
      case 'Buy Account':
        page = const BuyAccountPage();
        break;
      default:
        return;
    }

    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => page,
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          const begin = Offset(1.0, 0.0);
          const end = Offset.zero;
          const curve = Curves.easeInOut;
          var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
          return SlideTransition(position: animation.drive(tween), child: child);
        },
        transitionDuration: const Duration(milliseconds: 300),
      ),
    );
  }

  // --- Ini dimodifikasi padding-nya sedikit agar sesuai bentuk Grid ---
  Widget _buildAnimatedToolItem({
    required IconData icon,
    required String label,
    required String description,
    required Animation<double> animation,
    required VoidCallback onTap,
    Color color = const Color(0xFF00E5CC),
  }) {
    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, (1 - animation.value) * 50),
          child: Opacity(
            opacity: animation.value,
            child: _InteractiveToolItem(
              icon: icon, label: label,
              description: description,
              onTap: onTap, color: color),
          ),
        );
      },
    );
  }
}

// --- NEW MARQUEE TEXT WIDGET UNTUK TEKS BERJALAN ---
class MarqueeText extends StatefulWidget {
  final String text;
  final TextStyle style;
  
  const MarqueeText({super.key, required this.text, required this.style});

  @override
  State<MarqueeText> createState() => _MarqueeTextState();
}

class _MarqueeTextState extends State<MarqueeText> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    // Durasi animasi menentukan kecepatan teks berjalan
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 8))..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return ClipRect(
          child: AnimatedBuilder(
            animation: _controller,
            builder: (context, child) {
              // Menghitung pergerakan dari kanan ke kiri
              final width = MediaQuery.of(context).size.width;
              final dx = width - (_controller.value * (width + 300)); 
              return Transform.translate(
                offset: Offset(dx, 0),
                child: child,
              );
            },
            child: Text(
              widget.text,
              style: widget.style,
              maxLines: 1,
              overflow: TextOverflow.visible,
            ),
          ),
        );
      },
    );
  }
}

class _InteractiveToolItem extends StatefulWidget {
  final IconData icon;
  final String label;
  final String description;
  final VoidCallback onTap;
  final Color color;

  const _InteractiveToolItem({
    required this.icon,
    required this.label,
    required this.description,
    required this.onTap,
    this.color = const Color(0xFF00E5CC),
  });

  @override
  State<_InteractiveToolItem> createState() => _InteractiveToolItemState();
}

class _InteractiveToolItemState extends State<_InteractiveToolItem> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  bool _isPressed = false;

  // Definisi Warna (Silver) -> Disimpan untuk referensi lama
  static const Color primaryColor = Color(0xFFE0E0E0);

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(duration: const Duration(milliseconds: 200), vsync: this);
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) {
        setState(() => _isPressed = true);
        _controller.forward();
      },
      onTapUp: (_) {
        setState(() => _isPressed = false);
        _controller.reverse();
        widget.onTap();
      },
      onTapCancel: () {
        setState(() => _isPressed = false);
        _controller.reverse();
      },
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            child: Container(
              padding: const EdgeInsets.all(0),
              decoration: BoxDecoration(
                color: const Color(0xFF0A0E1A),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(
                  color: _isPressed
                      ? widget.color.withOpacity(0.5)
                      : Colors.white.withOpacity(0.07),
                  width: 1.5,
                ),
                boxShadow: _isPressed
                    ? [
                        BoxShadow(
                          color: widget.color.withOpacity(0.15),
                          blurRadius: 15,
                          spreadRadius: 1,
                        )
                      ]
                    : [],
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // ─── Icon Box (persis screenshot) ───
                    Container(
                      width: 52, height: 52,
                      decoration: BoxDecoration(
                        color: widget.color.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Icon(widget.icon, color: widget.color, size: 26),
                    ),
                    const Spacer(),
                    Text(
                      widget.label,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      widget.description,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.4),
                        fontSize: 11,
                        fontFamily: "ShareTechMono",
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            /* --- KODE LAMA TAMPILAN CARD SAYA KOMENTARI ---
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _isPressed
                      ? primaryColor.withOpacity(0.6) // Silver lebih terang saat ditekan
                      : primaryColor.withOpacity(0.2), // Silver normal
                  width: 1,
                ),
                boxShadow: _isPressed
                    ? [
                  BoxShadow(
                    color: primaryColor.withOpacity(0.1),
                    blurRadius: 15,
                    spreadRadius: 1,
                  )
                ]
                    : [],
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: primaryColor.withOpacity(0.1), // Silver opacity
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: primaryColor.withOpacity(0.2)),
                    ),
                    child: Icon(widget.icon, color: primaryColor, size: 24), // Silver
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.label,
                          style: const TextStyle(
                            color: primaryColor, // Silver
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            shadows: [
                              Shadow(
                                color: primaryColor,
                                blurRadius: 4,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          widget.description,
                          style: TextStyle(
                              color: primaryColor.withOpacity(0.6), // Silver opacity
                              fontSize: 12
                          ),
                        ),
                      ],
                    ),
                  ),
                  Icon(
                    Icons.arrow_forward_ios,
                    color: primaryColor.withOpacity(0.4), // Silver opacity
                    size: 16,
                  ),
                ],
              ),
            ),
            ------------------------------------------------ */
          );
        },
      ),
    );
  }
}

class GridPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFE0E0E0) // Silver/Abu-abu menyala
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.5;
    const gridSize = 30.0;
    for (double x = 0; x < size.width; x += gridSize) canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    for (double y = 0; y < size.height; y += gridSize) canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
// ─── Games Page Placeholder ───
class GamesPage extends StatelessWidget {
  const GamesPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E1A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A0E1A),
        title: const Text('Games', style: TextStyle(color: Colors.white, fontFamily: 'Orbitron')),
        iconTheme: const IconThemeData(color: Colors.white70),
      ),
      body: const Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.sports_esports_rounded, color: Color(0xFF9C27B0), size: 80),
          SizedBox(height: 16),
          Text('COMING SOON', style: TextStyle(
            color: Colors.white, fontFamily: 'Orbitron',
            fontSize: 20, letterSpacing: 3)),
          SizedBox(height: 8),
          Text('Pacman, Snake, dll', style: TextStyle(
            color: Colors.white38, fontFamily: 'ShareTechMono')),
        ]),
      ),
    );
  }
}


// ══════════════════════════════════════════════════════════
//  MANTARAT BOTTOM SHEET
// ══════════════════════════════════════════════════════════
class _MantaratSheet extends StatelessWidget {
  final String sessionKey;
  const _MantaratSheet({required this.sessionKey});

  static const Color _bg = Color(0xFF0D1B2A);
  static const Color _cyan = Color(0xFF00E5CC);
  static const Color _orange = Color(0xFFFF5722);
  static const Color _border = Color(0xFF1A2E3A);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0D1B2A),
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle bar
          Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(4))),
          const SizedBox(height: 20),
          // Header
          Row(children: [
            Container(
              width: 52, height: 52,
              decoration: BoxDecoration(color: _orange.withOpacity(0.15), borderRadius: BorderRadius.circular(14)),
              child: const Icon(Icons.build_rounded, color: _orange, size: 24),
            ),
            const SizedBox(width: 14),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text("TANIXRAT", style: TextStyle(color: Color(0xFF00E5CC), fontSize: 11, letterSpacing: 3, fontWeight: FontWeight.bold)),
              const Text("Konfigurasi Menu", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            ]),
            const Spacer(),
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(width: 32, height: 32, decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(8)),
                child: const Icon(Icons.close_rounded, color: Colors.white38, size: 16)),
            ),
          ]),
          const SizedBox(height: 6),
          Divider(color: Colors.white.withOpacity(0.07)),
          const SizedBox(height: 6),
          // Menu items
          _sheetItem(context, Icons.badge_rounded, "RAT Controll", "Remote control perangkat target",
            () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => const DeviceDashboardPage())); }),
          const SizedBox(height: 10),
          _sheetItem(context, Icons.android_rounded, "Auto Modifikasi Aplikasi", "Inject & modifikasi APK otomatis",
            () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => ApkBuilderPage(sessionKey: sessionKey))); }),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _sheetItem(BuildContext context, IconData icon, String title, String subtitle, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: const Color(0xFF111D2C),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _border),
        ),
        child: Row(children: [
          Container(width: 40, height: 40, decoration: BoxDecoration(color: _cyan.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: _cyan, size: 20)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 14)),
            Text(subtitle, style: const TextStyle(color: Colors.white38, fontSize: 11)),
          ])),
          const Icon(Icons.chevron_right_rounded, color: Colors.white24, size: 20),
        ]),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════
//  GENERATOR BOTTOM SHEET
// ══════════════════════════════════════════════════════════
class _GeneratorSheet extends StatelessWidget {
  final String sessionKey;
  const _GeneratorSheet({required this.sessionKey});

  static const Color _bg = Color(0xFF0D1B2A);
  static const Color _cyan = Color(0xFF00E5CC);
  static const Color _purple = Color(0xFF9C27B0);
  static const Color _border = Color(0xFF1A2E3A);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0D1B2A),
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(4))),
          const SizedBox(height: 20),
          Row(children: [
            Container(width: 52, height: 52,
              decoration: BoxDecoration(color: _purple.withOpacity(0.15), borderRadius: BorderRadius.circular(14)),
              child: const Icon(Icons.auto_awesome_rounded, color: _purple, size: 24)),
            const SizedBox(width: 14),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text("GENERATOR", style: TextStyle(color: Color(0xFF9C27B0), fontSize: 11, letterSpacing: 3, fontWeight: FontWeight.bold)),
              const Text("Konfigurasi Menu", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            ]),
            const Spacer(),
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(width: 32, height: 32, decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(8)),
                child: const Icon(Icons.close_rounded, color: Colors.white38, size: 16)),
            ),
          ]),
          const SizedBox(height: 6),
          Divider(color: Colors.white.withOpacity(0.07)),
          const SizedBox(height: 6),
          _sheetItem(context, Icons.phone_iphone_rounded, "iPhone Quote", "Buat screenshot quote gaya iPhone",
            () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => GeneratorPage(sessionKey: sessionKey, initialType: 'Quote'))); }),
          const SizedBox(height: 10),
          _sheetItem(context, Icons.menu_book_rounded, "Fake Story", "Generate cerita palsu viral",
            () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => GeneratorPage(sessionKey: sessionKey, initialType: 'Fake Story'))); }),
          const SizedBox(height: 10),
          _sheetItem(context, Icons.person_outline_rounded, "Fake Tweet", "Buat tweet palsu",
            () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => GeneratorPage(sessionKey: sessionKey, initialType: 'Fake Tweet'))); }),
          const SizedBox(height: 10),
          _sheetItem(context, Icons.cloud_upload_rounded, "To Url", "Upload konten ke URL",
            () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => GeneratorPage(sessionKey: sessionKey, initialType: 'To Url'))); }),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _sheetItem(BuildContext context, IconData icon, String title, String subtitle, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: const Color(0xFF111D2C),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _border),
        ),
        child: Row(children: [
          Container(width: 40, height: 40, decoration: BoxDecoration(color: _cyan.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: _cyan, size: 20)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 14)),
            Text(subtitle, style: const TextStyle(color: Colors.white38, fontSize: 11)),
          ])),
          const Icon(Icons.chevron_right_rounded, color: Colors.white24, size: 20),
        ]),
      ),
    );
  }
}
